/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

class MSHX$2$1
implements oVJh {
    final /* synthetic */ MSHX$2 KxVE;

    MSHX$2$1(MSHX$2 var1_1) {
        this.KxVE = var1_1;
    }

    @Override
    public void yJLS(BuLd buLd, long l, long l2, double d) {
    }

    @Override
    public void yJLS(BuLd buLd, mrHN mrHN2, mrHN mrHN3) {
    }

    @Override
    public void yJLS(BuLd buLd) {
    }

    @Override
    public void UtIU(BuLd buLd) {
        MSHX$2$1.vG(mrFx$WjFM.d("\ub065\udecd\ube14\u364c\u50a5\u2e42\u0e06\ubde3\ufd79\u5191\u1a66\u9c8a\u7e30\ue9cf\u856c\u9810\ucf39\u40d8\u8bfb\u6d94\ubc9d\u4c69\u0fe4\u78fd\uff9e"));
        MSHX$2$1.vG(MSHX$2$1.vG((MSHX$2)o.a(this, 906713505)));
    }

    @Override
    public void biLo(BuLd buLd) {
    }

    private static Object vG(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

