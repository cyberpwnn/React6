/*
 * Decompiled with CFR 0_123.
 */
public interface xyxr {
    public String getName();

    public mrIy FViO();

    public long yIwi();

    public void biLo(UQqm var1);

    public double getMax();

    public void dfaE(double var1);
}

