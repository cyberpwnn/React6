/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 */
import net.md_5.bungee.api.ChatColor;

class psKX$11
extends psKX {
    psKX$11(String string2, int n2, char c, int n3, boolean bl) {
    }

    @Override
    public ChatColor asBungee() {
        return (ChatColor)o.k(1328757400);
    }
}

