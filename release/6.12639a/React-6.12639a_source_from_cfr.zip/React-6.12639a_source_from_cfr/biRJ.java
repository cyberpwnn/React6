/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class biRJ
extends Enum<biRJ> {
    public static final /* enum */ biRJ ejbL;
    public static final /* enum */ biRJ tDJQ;
    public static final /* enum */ biRJ MJjT;
    public static final /* enum */ biRJ lgGC;
    public static final /* enum */ biRJ RslK;
    public static final /* enum */ biRJ qvVM;
    public static final /* enum */ biRJ RtLr;
    public static final /* enum */ biRJ LOxA;
    public static final /* enum */ biRJ UJQs;
    public static final /* enum */ biRJ fBqS;
    public static final /* enum */ biRJ xOth;
    public static final /* enum */ biRJ psQx;
    public static final /* enum */ biRJ UReO;
    public static final /* enum */ biRJ CWBj;
    public static final /* enum */ biRJ tenm;
    public static final /* enum */ biRJ QEwq;
    public static final /* enum */ biRJ sRKe;
    public static final /* enum */ biRJ BlpV;
    public static final /* enum */ biRJ JAeA;
    public static final /* enum */ biRJ FOKU;
    public static final /* enum */ biRJ JSGT;
    public static final /* enum */ biRJ afhy;
    public static final /* enum */ biRJ JIuS;
    public static final /* enum */ biRJ Ihrv;
    public static final /* enum */ biRJ twQB;
    public static final /* enum */ biRJ vktP;
    public static final /* enum */ biRJ IGPw;
    public static final /* enum */ biRJ rgxU;
    public static final /* enum */ biRJ ertN;
    public static final /* enum */ biRJ VUgK;
    public static final /* enum */ biRJ vIqD;
    public static final /* enum */ biRJ CpSy;
    public static final /* enum */ biRJ agJB;
    public static final /* enum */ biRJ miis;
    public static final /* enum */ biRJ WYLH;
    public static final /* enum */ biRJ PvYq;
    private String imyy;
    private static final /* synthetic */ biRJ[] BmRK;

    static {
        o.w(-1282846078, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e40\ubc3b\ud1b2\u0cb7\u7723\u6c9c\u4b20\u8b18\u6523\u9069\u4bc2\u5bed\u6845"), 0, (String)o.k(-236039661)));
        o.w(-768322944, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10e1\uda13\u3e4c\ubc30\ud1bf\u0ca1\u773a\u6c90\u4b32\u8b11\u6533\u9066\u4bc6"), 1, (String)o.k(-1977658751)));
        o.w(781996670, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e40\ubc3b\ud1b2\u0cb7\u7723\u6c9c\u4b20\u8b18"), 2, (String)o.k(-2009574785)));
        o.w(652628604, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10e1\uda13\u3e4c\ubc30\ud1bf\u0ca1\u773a\u6c90"), 3, (String)o.k(-1258139011)));
        o.w(998789642, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e40\ubc3b\ud1b2\u0cb7\u7733\u6c87\u4b22\u8b0d\u6528\u906c\u4bce\u5be5"), 4, (String)o.k(1259754107)));
        o.w(1119769096, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10e1\uda13\u3e4c\ubc30\ud1af\u0cba\u7738\u6c85\u4b39\u8b14\u653f\u906e"), 5, (String)o.k(2115326473)));
        o.w(-2017111546, (Object)new biRJ(FMkR$WjFM.a("\u401b\u10ed\uda1b\u3e5a\ubc3b\ud1a4\u0ca6\u7732\u6c8a\u4b39\u8b14\u653f\u906e\u4bd2\u5bfb\u685d\uc2a6\u876a\uaa93"), 6, (String)o.k(1148015111)));
        o.w(1614828036, (Object)new biRJ(FMkR$WjFM.a("\u401b\u10ed\uda1b\u3e5a\ubc3b\ud1a4\u0ca6\u7732\u6c8a\u4b39\u8b14\u653f\u906e"), 7, (String)o.k(-1511894523)));
        o.w(2002014962, (Object)new biRJ(FMkR$WjFM.a("\u401b\u10ed\uda1b\u3e5a\ubc3b\ud1a4\u0ca6\u7732\u6c8a\u4b3e\u8b18\u653f\u906a\u4bc3\u5bea"), 8, (String)o.k(-839626237)));
        o.w(-1952623888, (Object)new biRJ(FMkR$WjFM.a("\u401b\u10ed\uda1b\u3e5a\ubc3b\ud1a4\u0ca6\u7732\u6c8a\u4b39\u8b14\u6531\u9060"), 9, (String)o.k(-1433382159)));
        o.w(1728991982, (Object)new biRJ(FMkR$WjFM.a("\u4001\u10e7\uda0f\u3e59\ubc2a\ud1b9\u0cb7\u7723\u6c9c\u4b2e\u8b16\u6523\u9070\u4bde\u5bef\u6849\uc2a2"), 10, (String)o.k(-2064035089)));
        o.w(265835244, (Object)new biRJ(FMkR$WjFM.a("\u4001\u10e7\uda0f\u3e59\ubc2a\ud1b9\u0cb7\u7723\u6c9c\u4b2e\u8b16"), 11, (String)o.k(-1967303955)));
        o.w(1838109434, (Object)new biRJ(FMkR$WjFM.a("\u4001\u10e7\uda0f\u3e59\ubc2a\ud1b9\u0cb7\u7724\u6c90\u4b2e\u8b12\u6532\u9061"), 12, (String)o.k(1008423659)));
        o.w(-529313032, (Object)new biRJ(FMkR$WjFM.a("\u4001\u10e7\uda0f\u3e59\ubc2a\ud1b9\u0cb7\u7723\u6c9c\u4b20\u8b18"), 13, (String)o.k(1103581945)));
        o.w(-1708961034, (Object)new biRJ(FMkR$WjFM.a("\u400f\u10e4\uda0a\u3e40\ubc2b\ud1b4\u0cbc\u773e\u6c96\u4b26\u8b02\u6529\u9076\u4bcc\u5be9\u684b"), 14, (String)o.k(89281271)));
        o.w(910316276, (Object)new biRJ(FMkR$WjFM.a("\u400f\u10e4\uda0a\u3e40\ubc2b\ud1b4\u0cbc\u773e\u6c96\u4b26"), 15, (String)o.k(360993525)));
        o.w(113332962, (Object)new biRJ(FMkR$WjFM.a("\u400f\u10e4\uda0a\u3e40\ubc2b\ud1b4\u0cbb\u7732\u6c96\u4b22\u8b13\u6538"), 16, (String)o.k(-608349453)));
        o.w(459035360, (Object)new biRJ(FMkR$WjFM.a("\u400f\u10e4\uda0a\u3e40\ubc2b\ud1b4\u0cbc\u773e\u6c98\u4b28"), 17, (String)o.k(772428513)));
        o.w(-1955441954, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10f8\uda0c"), 18, (String)o.k(-2024844577)));
        o.w(711152348, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10e1\uda1c\u3e42"), 19, (String)o.k(735793885)));
        o.w(-1235725590, (Object)new biRJ(FMkR$WjFM.a("\u401d\u10e1\uda0a"), 20, (String)o.k(1659261659)));
        o.w(737891048, (Object)new biRJ(FMkR$WjFM.a("\u4004\u10ed\uda12"), 21, (String)o.k(-228830487)));
        o.w(-1842457882, (Object)new biRJ(FMkR$WjFM.a("\u400f\u10fa\uda1a\u3e4c\ubc22\ud1ae\u0ca5"), 22, (String)o.k(2003718887)));
        o.w(-1905241372, (Object)new biRJ(FMkR$WjFM.a("\u4004\u10e9\uda07\u3e44\ubc2a\ud1a6"), 23, (String)o.k(1498698469)));
        o.w(-51227950, (Object)new biRJ(FMkR$WjFM.a("\u4008\u10e4\uda13\u3e46\ubc2c\ud1a6\u0cad\u773a"), 24, (String)o.k(-1087614237)));
        o.w(-659533104, (Object)new biRJ(FMkR$WjFM.a("\u4004\u10e9\uda17\u3e5a"), 25, (String)o.k(1724928721)));
        o.w(-1092463922, (Object)new biRJ(FMkR$WjFM.a("\u400a\u10e0\uda14\u3e56\ubc3b\ud1a2\u0ca5\u7732"), 26, (String)o.k(-580496689)));
        o.w(1264538316, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10f0\uda0f\u3e45\ubc20\ud1b8\u0ca1\u7738\u6c9b\u4b32\u8b09\u6535\u9068\u4bc8"), 27, (String)o.k(2110870221)));
        o.w(-864726310, (Object)new biRJ(FMkR$WjFM.a("\u400a\u10e0\uda14"), 28, (String)o.k(-258452789)));
        o.w(1032082136, (Object)new biRJ(FMkR$WjFM.a("\u4008\u10fc\uda1e\u3e5a\ubc24"), 29, (String)o.k(414274265)));
        o.w(-917482794, (Object)new biRJ(FMkR$WjFM.a("\u401a\u10fc\uda1e\u3e5a\ubc24"), 30, (String)o.k(-277196073)));
        o.w(603673300, (Object)new biRJ(FMkR$WjFM.a("\u400a\u10e0\uda14\u3e5a"), 31, (String)o.k(792416981)));
        o.w(-200322494, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b"), 32, (String)o.k(-1441246509)));
        o.w(1642156608, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e45\ubc26\ud1bd"), 33, (String)o.k(629690945)));
        o.w(-567520706, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e4d\ubc3d\ud1a4\u0cb8"), 34, (String)o.k(476074559)));
        o.w(1030509116, (Object)new biRJ(FMkR$WjFM.a("\u400c\u10e6\uda0b\u3e5d\ubc26\ud1a7\u0cad"), 35, (String)o.k(2081903165)));
        o.w(-1868344773, new biRJ[]{(biRJ)((Object)o.k(-1282846078)), (biRJ)((Object)o.k(-768322944)), (biRJ)((Object)o.k(781996670)), (biRJ)((Object)o.k(652628604)), (biRJ)((Object)o.k(998789642)), (biRJ)((Object)o.k(1119769096)), (biRJ)((Object)o.k(-2017111546)), (biRJ)((Object)o.k(1614828036)), (biRJ)((Object)o.k(2002014962)), (biRJ)((Object)o.k(-1952623888)), (biRJ)((Object)o.k(1728991982)), (biRJ)((Object)o.k(265835244)), (biRJ)((Object)o.k(1838109434)), (biRJ)((Object)o.k(-529313032)), (biRJ)((Object)o.k(-1708961034)), (biRJ)((Object)o.k(910316276)), (biRJ)((Object)o.k(113332962)), (biRJ)((Object)o.k(459035360)), (biRJ)((Object)o.k(-1955441954)), (biRJ)((Object)o.k(711152348)), (biRJ)((Object)o.k(-1235725590)), (biRJ)((Object)o.k(737891048)), (biRJ)((Object)o.k(-1842457882)), (biRJ)((Object)o.k(-1905241372)), (biRJ)((Object)o.k(-51227950)), (biRJ)((Object)o.k(-659533104)), (biRJ)((Object)o.k(-1092463922)), (biRJ)((Object)o.k(1264538316)), (biRJ)((Object)o.k(-864726310)), (biRJ)((Object)o.k(1032082136)), (biRJ)((Object)o.k(-917482794)), (biRJ)((Object)o.k(603673300)), (biRJ)((Object)o.k(-200322494)), (biRJ)((Object)o.k(1642156608)), (biRJ)((Object)o.k(-567520706)), (biRJ)((Object)o.k(1030509116))});
    }

    public NwfF CgHM() {
        return biRJ.SC((FWER)o.a((TEqA)o.k(911295720), 1286751627), this.toString());
    }

    public String toString() {
        return (String)o.a((Object)this, -1302375735);
    }

    private biRJ(String string2, int n2, String string3) {
        try {
            this.imyy = string2;
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public String aeiw() {
        return (String)o.a((Object)this, -1302375735);
    }

    public static biRJ[] values() {
        biRJ[] arrbiRJ = (biRJ[])o.k(-1868344773);
        int n = arrbiRJ.length;
        biRJ[] arrbiRJ2 = new biRJ[n];
        biRJ.SC(arrbiRJ, false, arrbiRJ2, false, n);
        return arrbiRJ2;
    }

    public static biRJ valueOf(String string) {
        return (biRJ)((Object)biRJ.SC(biRJ.class, string));
    }

    private static Object SC(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

