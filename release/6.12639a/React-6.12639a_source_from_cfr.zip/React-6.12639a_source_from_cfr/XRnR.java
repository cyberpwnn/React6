/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public interface XRnR {
    public Mtpq biLo(File var1);
}

