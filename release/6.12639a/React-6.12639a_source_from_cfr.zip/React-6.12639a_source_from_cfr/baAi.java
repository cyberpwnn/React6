/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import org.bukkit.command.CommandSender;

@BtuM(value=0)
public class baAi
extends miQG {
    public baAi() {
        this.command = (String)o.k(939348577);
        this.aliases = new String[]{(String)o.k(52187744), (String)o.k(290607711)};
        String[] arrstring = new String[1];
        arrstring[0] = baAi.Nq((aeiw)((Object)o.k(673269243)));
        this.Pdrw = arrstring;
        this.cJgR = (String)o.k(1877955166);
        this.description = (String)o.k(932336221);
        this.vImB = (EJip)((Object)o.k(319771278));
    }

    @Override
    public void yJLS(CommandSender commandSender, String[] arrstring) {
        Object object = baAi.Nq((feCR)o.k(122111242));
        while (object.hasNext()) {
            JIWX jIWX = (JIWX)object.next();
            if (baAi.Nq(jIWX) != false) {
                Object object2 = "";
                if (baAi.Nq(baAi.Nq(jIWX), (eHVp)((Object)o.k(1702118664))) == false) {
                    object2 = baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder((String)baAi.Nq(object2)), mrFx$WjFM.d("\u6971")), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u693c\u9c60\ucd4d")), (psKX)((Object)o.k(-857517477))), baAi.Nq(baAi.Nq(jIWX))), (psKX)((Object)o.k(-23312902))));
                }
                if (baAi.Nq(jIWX) != null) {
                    object2 = baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder((String)baAi.Nq(object2)), mrFx$WjFM.d("\u6971")), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6921\u9c6f\ucd18\u860e\u5306\u394b\u67a2")), (psKX)((Object)o.k(-1868409976))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))));
                }
                if (baAi.Nq(baAi.Nq(jIWX), (jxuv)((Object)o.k(1410811145))) == false) {
                    object2 = baAi.Nq(baAi.Nq(jIWX), (jxuv)((Object)o.k(1629046141))) != false ? baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder((String)baAi.Nq(object2)), mrFx$WjFM.d("\u6971")), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6937\u9c6f\ucd0c\u861f\u5300\u3957\u67a2")), (psKX)((Object)o.k(-1118678018))), mrFx$WjFM.d("\u6902\u9c73\ucd04\u860e\u5300\u3951\u67ad\u4664\uce35\uc6fa\ub55e\u77ce\ud06b\ue413\u2e2f\u66aa\ud7f1\ue86c")), (psKX)((Object)o.k(-23312902)))) : baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder((String)baAi.Nq(object2)), mrFx$WjFM.d("\u6971")), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6937\u9c6f\ucd0c\u861f\u5300\u3957\u67a2")), (psKX)((Object)o.k(-1118678018))), baAi.Nq(baAi.Nq(jIWX))), (psKX)((Object)o.k(-23312902))));
                }
                baAi.Nq(commandSender, baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder(), (psKX)((Object)o.k(-1880078855))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6979")), baAi.Nq(object2, true)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6978"))));
                continue;
            }
            if (baAi.Nq(jIWX) == false) {
                baAi.Nq(commandSender, baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder(), (psKX)((Object)o.k(568215020))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6971\u9c2b\ucd1f\u860c\u531e\u3950\u67eb\u4646\uce31\uc6f9\ub51b")), (psKX)((Object)o.k(-1880078855))), baAi.Nq(baAi.Nq(jIWX))), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6978"))));
                continue;
            }
            if (baAi.Nq(jIWX) == false) {
                baAi.Nq(commandSender, baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder(), (psKX)((Object)o.k(568215020))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6971\u9c2b\ucd1f\u860c\u531e\u3950\u67eb\u4646\uce31\uc6f9\ub51b")), (psKX)((Object)o.k(-1880078855))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6978"))));
                continue;
            }
            if (baAi.Nq(jIWX) != false) continue;
            baAi.Nq(commandSender, baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(baAi.Nq(new StringBuilder(), (psKX)((Object)o.k(568215020))), baAi.Nq(jIWX)), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6971\u9c2b\ucd1f\u860c\u531e\u3950\u67eb\u4646\uce31\uc6f9\ub51b")), (psKX)((Object)o.k(-1880078855))), baAi.Nq(baAi.Nq(jIWX))), mrFx$WjFM.d("\u697a")), (psKX)((Object)o.k(-23312902))), mrFx$WjFM.d("\u6978"))));
        }
    }

    private static Object Nq(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

