/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public interface NDol {
    public void yJLS(Mtpq var1, File var2);
}

