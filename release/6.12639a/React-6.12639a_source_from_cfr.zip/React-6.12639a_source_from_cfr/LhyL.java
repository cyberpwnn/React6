/*
 * Decompiled with CFR 0_123.
 */
public interface LhyL {
    public feCR<kAOQ> VLkD();

    public void tick();

    public void yJLS(kAOQ var1);

    public feCR<hHgD> ggmf();

    public void yJLS(hHgD var1);

    public feCR<xynF> paft();
}

