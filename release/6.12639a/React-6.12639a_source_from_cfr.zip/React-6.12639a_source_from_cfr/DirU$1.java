/*
 * Decompiled with CFR 0_123.
 */
class DirU$1
extends xGOy {
    final /* synthetic */ DirU MSrF;
    private final /* synthetic */ kAOQ CEqo;

    DirU$1(DirU dirU, kAOQ kAOQ2) {
        this.MSrF = dirU;
        this.CEqo = kAOQ2;
    }

    @Override
    public void run() {
        ((kAOQ)o.a(this, 1566398443)).aTvv();
    }
}

