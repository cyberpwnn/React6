/*
 * Decompiled with CFR 0_123.
 */
public interface xynF {
    public void UtIU(String var1);

    public void biLo(String var1);

    public void VwLY(String var1);

    public void TEqA(String var1);
}

