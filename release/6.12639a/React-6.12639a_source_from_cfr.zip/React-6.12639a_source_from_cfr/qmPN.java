/*
 * Decompiled with CFR 0_123.
 */
public class qmPN {
    public static long iUXR;
    public static long WsHj;

    static {
        o.w(-619556004, 0);
        o.w(2037595655, 0);
    }
}

