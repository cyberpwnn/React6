/*
 * Decompiled with CFR 0_123.
 */
public interface LrIE {
    public int getPort();

    public mrFx nuLT();

    public JROj VwLY(JROj var1);
}

