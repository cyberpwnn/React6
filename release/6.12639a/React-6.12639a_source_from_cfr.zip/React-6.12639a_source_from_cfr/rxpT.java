/*
 * Decompiled with CFR 0_123.
 */
public class rxpT {
    private double CXRx;

    public rxpT(double d) {
        this.CXRx = d;
    }

    public int imyy() {
        return (int)((Double)o.a(this, -374981643) / 2.0);
    }

    public double Xljg() {
        return (Double)o.a(this, -374981643) / 2.0;
    }

    public double XlkH() {
        return (Double)o.a(this, -374981643);
    }

    public int LjJH() {
        return (int)((Double)o.a(this, -374981643)).doubleValue();
    }
}

