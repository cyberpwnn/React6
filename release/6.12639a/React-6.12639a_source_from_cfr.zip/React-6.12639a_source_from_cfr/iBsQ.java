/*
 * Decompiled with CFR 0_123.
 */
public interface iBsQ<T, B> {
    public void yJLS(int var1, String var2, String var3, T var4);

    public void yJLS(int var1, String var2, T var3);

    public T get(String var1);

    public void eYJe();

    public eHVp IEpg();
}

