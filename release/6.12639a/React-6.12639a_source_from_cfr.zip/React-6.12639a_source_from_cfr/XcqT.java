/*
 * Decompiled with CFR 0_123.
 */
public interface XcqT {
    public int getId();

    public void run();

    public boolean XKDx();

    public String getName();

    public double FNbH();

    public double lnpk();

    public double iLTq();

    public boolean VfbL();
}

