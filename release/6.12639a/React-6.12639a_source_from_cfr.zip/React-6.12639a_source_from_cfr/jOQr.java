/*
 * Decompiled with CFR 0_123.
 */
public class jOQr<T>
implements NVRU<T> {
    private WaLc EoDT;
    private T axWj;

    protected jOQr(WaLc waLc, T t) {
        this.EoDT = waLc;
        this.set(t);
    }

    @Override
    public WaLc wMJq() {
        return (WaLc)((Object)o.a(this, 1684753584));
    }

    @Override
    public void set(T t) {
        o.v(this, -766423889, t);
    }

    @Override
    public T get() {
        return (T)o.a(this, -766423889);
    }
}

