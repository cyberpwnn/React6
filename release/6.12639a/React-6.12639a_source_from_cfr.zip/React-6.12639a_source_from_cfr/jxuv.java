/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class jxuv
extends Enum<jxuv> {
    public static final /* enum */ jxuv gxtQ;
    public static final /* enum */ jxuv RIUW;
    public static final /* enum */ jxuv psQb;
    public static final /* enum */ jxuv scHl;
    public static final /* enum */ jxuv VxHQ;
    public static final /* enum */ jxuv nRwg;
    public static final /* enum */ jxuv jGMI;
    public static final /* enum */ jxuv ekAa;
    public static final /* enum */ jxuv uiNt;
    public static final /* enum */ jxuv KVFH;
    public static final /* enum */ jxuv gVsd;
    private static final /* synthetic */ jxuv[] OrsF;

    static {
        o.w(1410811145, (Object)new jxuv(nJPf$sILv.G("\u8ce6\ud623\ufed4"), 0));
        o.w(1977828788, (Object)new jxuv(nJPf$sILv.G("\u8cf4\ud62c\ufecb\u2add\u956b\ud61d\uc080\u19ff\ucf1c"), 1));
        o.w(-195017293, (Object)new jxuv(nJPf$sILv.G("\u8ce4\ud63f\ufecc\u2ade\u9560\ud60f\uc08d\u19ee\ucf12\u4f3a\uc8e6\ud092"), 2));
        o.w(-1910815326, (Object)new jxuv(nJPf$sILv.G("\u8ce5\ud638\ufec6\u2ad3\u957d\ud604"), 3));
        o.w(1329415585, (Object)new jxuv(nJPf$sILv.G("\u8cf4\ud63d\ufec4\u2adf\u957b\ud604"), 4));
        o.w(1629046141, (Object)new jxuv(nJPf$sILv.G("\u8cf4\ud622\ufeca\u2adf\u956d\ud60f\uc09c\u19eb\ucf10\u4f36\uc8e0\ud092"), 5));
        o.w(1072121248, (Object)new jxuv(nJPf$sILv.G("\u8cf7\ud62c\ufedd\u2add\u9566\ud60f\uc09c\u19eb\ucf10\u4f36\uc8e0\ud092"), 6));
        o.w(1372276127, (Object)new jxuv(nJPf$sILv.G("\u8cf3\ud62c\ufece\u2ad7\u956b\ud603\uc09f\u19f2\ucf1e\u4f3e\uc8fb"), 7));
        o.w(231163294, (Object)new jxuv(nJPf$sILv.G("\u8cf3\ud622\ufedf\u2adb\u957c\ud60f\uc09c\u19eb\ucf10\u4f36\uc8e0\ud092"), 8));
        o.w(923551133, (Object)new jxuv(nJPf$sILv.G("\u8ce1\ud622\ufedf\u2adf\u9571\ud60f\uc087\u19fa\ucf1a\u4f3a"), 9));
        o.w(-170310244, (Object)new jxuv(nJPf$sILv.G("\u8cf4\ud63d\ufec2\u2ad6\u9573\ud615\uc090\u19f3\ucf18\u4f32\uc8e4"), 10));
        o.w(-1232058981, new jxuv[]{(jxuv)((Object)o.k(1410811145)), (jxuv)((Object)o.k(1977828788)), (jxuv)((Object)o.k(-195017293)), (jxuv)((Object)o.k(-1910815326)), (jxuv)((Object)o.k(1329415585)), (jxuv)((Object)o.k(1629046141)), (jxuv)((Object)o.k(1072121248)), (jxuv)((Object)o.k(1372276127)), (jxuv)((Object)o.k(231163294)), (jxuv)((Object)o.k(923551133)), (jxuv)((Object)o.k(-170310244))});
    }

    private jxuv(String string2, int n2) {
    }

    public static jxuv Ywen() {
        Object object = jxuv.DP(jxuv.DP());
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de7\u2308\u83d0\u4a51\u1bd3\u70e2\u3c60\ue2a0\ubc4f\u0c2e\ua0b0")) != false) {
            return (jxuv)((Object)o.k(1072121248));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de3\u2308\u83c3\u4a5b")) != false) {
            return (jxuv)((Object)o.k(1372276127));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de3\u2306\u83d2\u4a57\u1bc9")) != false) {
            return (jxuv)((Object)o.k(231163294));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de3\u2301\u83c5\u4a46\u1bcc\u70fe\u3c63")) != false) {
            return (jxuv)((Object)o.k(923551133));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9df4\u2308\u83d5\u4a58\u1bc5\u70e3\u3c7f\ue2a7")) != false) {
            return (jxuv)((Object)o.k(923551133));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de4\u2319\u83cf\u4a5a\u1bc6\u70f4")) != false) {
            return (jxuv)((Object)o.k(-170310244));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9de4\u2319\u83c9\u4a53\u1bce\u70e5")) != false) {
            return (jxuv)((Object)o.k(1329415585));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9df4\u231b\u83c1\u4a52\u1bd5\u70f3\u3c65\ue2a2\ubc43\u0c28\ua0b0")) != false) {
            return (jxuv)((Object)o.k(-195017293));
        }
        if (jxuv.DP(object, FMkR$WjFM.a("\u9df5\u231c\u83cb\u4a5f\u1bc8\u70e5")) != false) {
            return (jxuv)((Object)o.k(-1910815326));
        }
        return (jxuv)((Object)o.k(1977828788));
    }

    public boolean yJLS(jxuv jxuv2) {
        if (jxuv2.equals((Object)((jxuv)((Object)o.k(1629046141)))) && (jxuv.Ywen().equals((Object)((jxuv)((Object)o.k(1072121248)))) || jxuv.Ywen().equals((Object)((jxuv)((Object)o.k(1329415585)))))) {
            return true;
        }
        if (!jxuv.Ywen().equals((Object)jxuv2) && !jxuv2.equals((Object)((jxuv)((Object)o.k(1410811145))))) {
            return false;
        }
        return true;
    }

    public String UAGQ() {
        return jxuv.DP(jxuv.DP(jxuv.DP(this.name(), FMkR$WjFM.a("\u2865"), FMkR$WjFM.a("\u281a"))));
    }

    public static jxuv[] values() {
        jxuv[] arrjxuv = (jxuv[])o.k(-1232058981);
        int n = arrjxuv.length;
        jxuv[] arrjxuv2 = new jxuv[n];
        jxuv.DP(arrjxuv, false, arrjxuv2, false, n);
        return arrjxuv2;
    }

    public static jxuv valueOf(String string) {
        return (jxuv)((Object)jxuv.DP(jxuv.class, string));
    }

    private static Object DP(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

