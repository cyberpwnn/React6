/*
 * Decompiled with CFR 0_123.
 */
public class JYyP
extends AFmj {
    private static final long serialVersionUID = 7755514107832808772L;

    public JYyP(String string) {
        super(string);
    }
}

