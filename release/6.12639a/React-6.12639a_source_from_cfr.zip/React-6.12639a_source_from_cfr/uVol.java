/*
 * Decompiled with CFR 0_123.
 */
public class uVol
extends dfaE {
    private static final long serialVersionUID = 5218899708941491030L;
}

