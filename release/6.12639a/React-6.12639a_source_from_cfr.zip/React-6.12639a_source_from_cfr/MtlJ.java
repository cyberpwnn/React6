/*
 * Decompiled with CFR 0_123.
 */
import java.io.Serializable;

public class MtlJ<A, B>
implements Serializable {
    private static final long serialVersionUID = 1;
    private A ejpp;
    private B rOUV;

    public MtlJ(A a, B b) {
        this.ejpp = a;
        this.rOUV = b;
    }

    public A ntkf() {
        return (A)o.a(this, 1708608574);
    }

    public void ktHX(A a) {
        o.v(this, 1708608574, a);
    }

    public B XAhy() {
        return (B)o.a(this, 772033597);
    }

    public void HeSD(B b) {
        o.v(this, 772033597, b);
    }
}

