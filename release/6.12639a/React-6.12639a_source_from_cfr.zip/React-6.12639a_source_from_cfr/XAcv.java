/*
 * Decompiled with CFR 0_123.
 */
public class XAcv<T>
implements Runnable {
    private T axWj;

    public void yJLS(T t) {
        o.v(this, 2068860116, t);
        this.run();
    }

    @Override
    public void run() {
    }

    public T get() {
        return (T)o.a(this, 2068860116);
    }
}

