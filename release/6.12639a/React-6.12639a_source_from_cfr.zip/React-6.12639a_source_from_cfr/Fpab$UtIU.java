/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 */
import org.bukkit.Material;

public final class Fpab$UtIU
extends Fpab$GPlk {
    public Fpab$UtIU(Material material, byte by) {
        super(material, by);
    }
}

