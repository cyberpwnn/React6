/*
 * Decompiled with CFR 0_123.
 */
public interface nceQ<V> {
    public V get();
}

