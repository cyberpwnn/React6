/*
 * Decompiled with CFR 0_123.
 */
class rMpA$2
extends Smoy {
    final /* synthetic */ rMpA eIMQ;

    rMpA$2(rMpA rMpA2, int n) throws Nwmj {
        this.eIMQ = rMpA2;
        super(n);
    }

    @Override
    public DXtE CEKe() {
        return new oxLO();
    }

    @Override
    public cAiw TNku() {
        return new KwVE();
    }
}

