/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class eirM {
    /*
     * Enabled aggressive block sorting
     */
    private static Object yJLS(Rjkm rjkm, boolean bl, JRRx jRRx) throws gggG {
        String string = null;
        JRRx jRRx2 = null;
        vbpi vbpi2 = null;
        String string2 = null;
        do {
            Object object;
            block40 : {
                block38 : {
                    block35 : {
                        block39 : {
                            block36 : {
                                block37 : {
                                    if (eirM.ls(rjkm) == false) {
                                        throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a13\u3608\ud8f7\ue0f9\u2de1\u6e9e\u6b8e"));
                                    }
                                    object = eirM.ls(rjkm);
                                    if (object != (Character)o.k(-441827215)) break block35;
                                    object = eirM.ls(rjkm);
                                    if (!(object instanceof Character)) break block36;
                                    if (object == (Character)o.k(1588609135)) {
                                        object = eirM.ls(rjkm);
                                        if (!(object instanceof String)) {
                                            throw new gggG((String)eirM.ls(eirM.ls(eirM.ls(new StringBuilder(FMkR$WjFM.a("\u2a14\u3611\ud8e3\ue0bc\u2dda\u6ea7\u6ba7\u406a\u2696\u2bbe\u27f9\udc5e\u9e4a\u894c\ub9f2\u9fe1\u7573\u465d\u740a\ua0c0\u5a79\u2ff3\u3798\uc1fd\ub65e\uecfbn\u7df7\u5db1\ua25b\u8c69\ud316\u15b0\ua667\u8ea8\ue894")), object), FMkR$WjFM.a("\u2a76\u3647"))));
                                        }
                                        if (eirM.ls(rjkm) != (Character)o.k(1974878318)) {
                                            throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd1\u6eb2\u6bb2\u406b\u26d2\u2bff\u27ba\udc51\u9e49\u8950\ub9e4\u9fa8\u7569\u465b\u744d"));
                                        }
                                        return object;
                                    }
                                    if (object != (Character)o.k(31080557)) break block37;
                                    Object object2 = eirM.ls(rjkm);
                                    if (object2 == 45) {
                                        if (eirM.ls(rjkm) == 45) {
                                            eirM.ls(rjkm, FMkR$WjFM.a("\u2a7c\u3644\ud8ad"));
                                            continue;
                                        }
                                        eirM.ls(rjkm);
                                        continue;
                                    }
                                    if (object2 == 91) {
                                        object = eirM.ls(rjkm);
                                        if (eirM.ls(object, FMkR$WjFM.a("\u2a12\u362d\ud8d2\ue08d\u2df8")) != false) {
                                            if (eirM.ls(rjkm) == 91) {
                                                if (jRRx == null) continue;
                                                eirM.ls(jRRx, eirM.ls(rjkm));
                                                continue;
                                            }
                                        }
                                        throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a14\u3611\ud8e3\ue0bc\u2dda\u6ea7\u6ba7\u406a\u2696\u2bf8\u279a\udc79\u9e67\u8977\ub9c0\u9fd3\u753a"));
                                    }
                                    break block38;
                                }
                                if (object != (Character)o.k(-1910488969)) {
                                    throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd1\u6eb2\u6bb2\u406b\u26d2\u2bff\u27ad\udc5c\u9e41"));
                                }
                                eirM.ls(rjkm, FMkR$WjFM.a("\u2a6e\u3657"));
                                continue;
                            }
                            if (!(object instanceof String)) {
                                throw eirM.ls(rjkm, eirM.ls(eirM.ls(eirM.ls(new StringBuilder(FMkR$WjFM.a("\u2a13\u3608\ud8f7\ue0f9\u2dcd\u6eb2\u6ba5\u4040\u26d7\u2bb2\u27bc\udc1d\u9e01")), object), FMkR$WjFM.a("\u2a76\u3647"))));
                            }
                            string2 = (String)object;
                            jRRx2 = new JRRx();
                            vbpi2 = new vbpi();
                            if (!bl) break block39;
                            eirM.ls(jRRx2, string2);
                            if (jRRx != null) {
                                eirM.ls(jRRx, jRRx2);
                            }
                            break block40;
                        }
                        eirM.ls(vbpi2, FMkR$WjFM.a("\u2a25\u3608\ud8f4\ue097\u2dd8\u6ebe\u6ba7"), string2);
                        if (jRRx == null) break block40;
                        eirM.ls(jRRx, vbpi2);
                        break block40;
                    }
                    if (jRRx == null) continue;
                    eirM.ls(jRRx, object instanceof String ? eirM.ls((String)object) : object);
                    continue;
                }
                int n = 1;
                do {
                    if ((object = eirM.ls(rjkm)) == null) {
                        throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd0\u6ebd\u6ba5\u402e\u2691\u2be1\u27fe\udc1d\u9e47\u8945\ub9f5\u9fed\u756f\u461a\u740d\ua092\u5a39\u2fb9\u37d3"));
                    }
                    if (object == (Character)o.k(-441827215)) {
                        ++n;
                        continue;
                    }
                    if (object != (Character)o.k(1974878318)) continue;
                    --n;
                } while (n > 0);
                continue;
            }
            object = null;
            do {
                String string3;
                block41 : {
                    block42 : {
                        if (object == null) {
                            object = eirM.ls(rjkm);
                        }
                        if (object == null) {
                            throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd1\u6eb2\u6bb2\u406b\u26d2\u2bff\u27ad\udc5c\u9e41"));
                        }
                        if (!(object instanceof String)) break;
                        string3 = (String)object;
                        if (bl) break block41;
                        if (eirM.ls(FMkR$WjFM.a("\u2a25\u3608\ud8f4\ue097\u2dd8\u6ebe\u6ba7"), string3) != false) break block42;
                        if (eirM.ls(FMkR$WjFM.a("\u2a32\u3601\ud8fa\ue0b5\u2ddd\u6e9d\u6bad\u406a\u26d3"), string3) == false) break block41;
                    }
                    throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a03\u360c\ud8e0\ue0bc\u2dcb\u6ea5\u6ba7\u406a\u2696\u2bbe\u27ad\udc49\u9e54\u894a\ub9e3\u9ffd\u7569\u465f\u7404"));
                }
                if ((object = eirM.ls(rjkm)) == (Character)o.k(1374634102)) {
                    object = eirM.ls(rjkm);
                    if (!(object instanceof String)) {
                        throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd0\u6ebd\u6ba5\u402e\u26c0\u2bbe\u27b5\udc48\u9e43"));
                    }
                    eirM.ls(vbpi2, string3, eirM.ls((String)object));
                    object = null;
                    continue;
                }
                eirM.ls(vbpi2, string3, "");
            } while (true);
            if (bl) {
                if (eirM.ls(vbpi2) > 0) {
                    eirM.ls(jRRx2, vbpi2);
                }
            }
            if (object == (Character)o.k(1588609135)) {
                if (eirM.ls(rjkm) != (Character)o.k(1974878318)) {
                    throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd1\u6eb2\u6bb2\u406b\u26d2\u2bff\u27ad\udc5c\u9e41"));
                }
                if (jRRx != null) continue;
                if (bl) {
                    return jRRx2;
                }
                return vbpi2;
            }
            if (object != (Character)o.k(1974878318)) {
                throw eirM.ls(rjkm, FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0aa\u2dd1\u6eb2\u6bb2\u406b\u26d2\u2bff\u27ad\udc5c\u9e41"));
            }
            string = (String)eirM.yJLS(rjkm, bl, jRRx2);
            if (string == null) continue;
            if (eirM.ls(string, string2) == false) {
                throw eirM.ls(rjkm, eirM.ls(eirM.ls(eirM.ls(eirM.ls(eirM.ls(new StringBuilder(FMkR$WjFM.a("\u2a1c\u3600\ud8e0\ue0b4\u2dd8\u6ea7\u6ba1\u4066\u26d3\u2bbb\u27f9\udc1a")), string2), FMkR$WjFM.a("\u2a76\u3649\ud8f2\ue0b7\u2ddd\u6ef3\u6be5")), string), FMkR$WjFM.a("\u2a76"))));
            }
            string2 = null;
            if (!bl) {
                if (eirM.ls(jRRx2) > 0) {
                    eirM.ls(vbpi2, FMkR$WjFM.a("\u2a32\u3601\ud8fa\ue0b5\u2ddd\u6e9d\u6bad\u406a\u26d3\u2bac"), jRRx2);
                }
            }
            if (jRRx == null) break;
        } while (true);
        if (bl) {
            return jRRx2;
        }
        return vbpi2;
    }

    public static JRRx IpeM(String string) throws gggG {
        return eirM.yJLS(new Rjkm(string));
    }

    public static JRRx yJLS(Rjkm rjkm) throws gggG {
        return (JRRx)eirM.yJLS(rjkm, true, null);
    }

    public static vbpi UtIU(Rjkm rjkm) throws gggG {
        return (vbpi)eirM.yJLS(rjkm, false, null);
    }

    public static vbpi bhkI(String string) throws gggG {
        return eirM.UtIU(new Rjkm(string));
    }

    public static String UtIU(JRRx jRRx) throws gggG {
        int n;
        StringBuilder stringBuilder = new StringBuilder();
        Object object = eirM.ls(jRRx, false);
        eirM.ls(object);
        object = eirM.ls(object);
        eirM.ls(stringBuilder, 60);
        eirM.ls(stringBuilder, object);
        Object object2 = eirM.ls(jRRx, true);
        if (object2 instanceof vbpi) {
            n = 2;
            vbpi vbpi2 = (vbpi)object2;
            Object object3 = eirM.ls(vbpi2);
            while (object3.hasNext()) {
                String string = (String)object3.next();
                eirM.ls(string);
                Object object4 = eirM.ls(vbpi2, string);
                if (object4 == null) continue;
                eirM.ls(stringBuilder, 32);
                eirM.ls(stringBuilder, eirM.ls(string));
                eirM.ls(stringBuilder, 61);
                eirM.ls(stringBuilder, 34);
                eirM.ls(stringBuilder, eirM.ls(object4));
                eirM.ls(stringBuilder, 34);
            }
        } else {
            n = 1;
        }
        Object object5 = eirM.ls(jRRx);
        if (n >= object5) {
            eirM.ls(stringBuilder, 47);
            eirM.ls(stringBuilder, 62);
        } else {
            eirM.ls(stringBuilder, 62);
            do {
                object2 = eirM.ls(jRRx, n);
                ++n;
                if (object2 == null) continue;
                if (object2 instanceof String) {
                    eirM.ls(stringBuilder, eirM.ls(eirM.ls(object2)));
                    continue;
                }
                if (object2 instanceof vbpi) {
                    eirM.ls(stringBuilder, eirM.UtIU((vbpi)object2));
                    continue;
                }
                if (object2 instanceof JRRx) {
                    eirM.ls(stringBuilder, eirM.UtIU((JRRx)object2));
                    continue;
                }
                eirM.ls(stringBuilder, eirM.ls(object2));
            } while (n < object5);
            eirM.ls(stringBuilder, 60);
            eirM.ls(stringBuilder, 47);
            eirM.ls(stringBuilder, object);
            eirM.ls(stringBuilder, 62);
        }
        return eirM.ls(stringBuilder);
    }

    public static String UtIU(vbpi vbpi2) throws gggG {
        StringBuilder stringBuilder = new StringBuilder();
        Object object = eirM.ls(vbpi2, nJPf$sILv.G("\uc7ff\u2383\ue0ea\u6cf0\u407c\uc8ed\ue18e"));
        if (object == null) {
            return eirM.ls(eirM.ls(vbpi2));
        }
        eirM.ls(object);
        object = eirM.ls(object);
        eirM.ls(stringBuilder, 60);
        eirM.ls(stringBuilder, object);
        Object object2 = eirM.ls(vbpi2);
        while (object2.hasNext()) {
            String string = (String)object2.next();
            if (eirM.ls(nJPf$sILv.G("\uc7ff\u2383\ue0ea\u6cf0\u407c\uc8ed\ue18e"), string) != false) continue;
            if (eirM.ls(nJPf$sILv.G("\uc7e8\u238a\ue0e4\u6cd2\u4079\uc8ce\ue184\u229f\uffdb\u223c"), string) != false) continue;
            eirM.ls(string);
            Object object3 = eirM.ls(vbpi2, string);
            if (object3 == null) continue;
            eirM.ls(stringBuilder, 32);
            eirM.ls(stringBuilder, eirM.ls(string));
            eirM.ls(stringBuilder, 61);
            eirM.ls(stringBuilder, 34);
            eirM.ls(stringBuilder, eirM.ls(object3));
            eirM.ls(stringBuilder, 34);
        }
        Object object4 = eirM.ls(vbpi2, nJPf$sILv.G("\uc7e8\u238a\ue0e4\u6cd2\u4079\uc8ce\ue184\u229f\uffdb\u223c"));
        if (object4 == null) {
            eirM.ls(stringBuilder, 47);
            eirM.ls(stringBuilder, 62);
        } else {
            eirM.ls(stringBuilder, 62);
            Object object5 = eirM.ls(object4);
            int n = 0;
            while (n < object5) {
                Object object6 = eirM.ls(object4, n);
                if (object6 != null) {
                    if (object6 instanceof String) {
                        eirM.ls(stringBuilder, eirM.ls(eirM.ls(object6)));
                    } else if (object6 instanceof vbpi) {
                        eirM.ls(stringBuilder, eirM.UtIU((vbpi)object6));
                    } else if (object6 instanceof JRRx) {
                        eirM.ls(stringBuilder, eirM.UtIU((JRRx)object6));
                    } else {
                        eirM.ls(stringBuilder, eirM.ls(object6));
                    }
                }
                ++n;
            }
            eirM.ls(stringBuilder, 60);
            eirM.ls(stringBuilder, 47);
            eirM.ls(stringBuilder, object);
            eirM.ls(stringBuilder, 62);
        }
        return eirM.ls(stringBuilder);
    }

    private static Object ls(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

