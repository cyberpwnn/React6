/*
 * Decompiled with CFR 0_123.
 */
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public interface yBDo<I extends InputStream, O extends OutputStream> {
    public I yJLS(InputStream var1) throws IOException;

    public O yJLS(OutputStream var1) throws IOException;
}

