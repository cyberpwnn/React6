/*
 * Decompiled with CFR 0_123.
 */
public class BBRC {
    private double TiqN = 0.0;
    private double xPwr = 0.0;
    private double tVJn;

    public double iLTq() {
        return (Double)o.a(this, 395267542);
    }

    public void WOYg(double d) {
        o.v(this, 395267542, d);
    }

    public double BJdg() {
        return (Double)o.a(this, 793857493);
    }

    public void IEpg(double d) {
        o.v(this, 793857493, d);
    }

    public double FNbH() {
        return (Double)o.a(this, 873156052);
    }

    public void PKGC(double d) {
        o.v(this, 873156052, d);
    }
}

