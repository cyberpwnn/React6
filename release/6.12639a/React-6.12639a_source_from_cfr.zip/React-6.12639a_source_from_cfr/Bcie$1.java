/*
 * Decompiled with CFR 0_123.
 */
class Bcie$1
extends JJHM {
    final /* synthetic */ Bcie WQFh;

    Bcie$1(Bcie bcie, String string) {
        this.WQFh = bcie;
        super(string);
    }

    @Override
    public void run() {
        new Bcie$1$1(this);
    }
}

