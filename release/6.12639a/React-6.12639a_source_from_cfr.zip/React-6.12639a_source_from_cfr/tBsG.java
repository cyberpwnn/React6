/*
 * Decompiled with CFR 0_123.
 */
public class tBsG {
    private double numA;

    public tBsG(double d) {
        this.numA = d;
    }

    public double get() {
        return (Double)o.a(this, -1142928173);
    }

    public void set(double d) {
        o.v(this, -1142928173, d);
    }

    public void add(double d) {
        tBsG tBsG2 = this;
        o.v(tBsG2, -1142928173, (Double)o.a(tBsG2, -1142928173) + d);
    }

    public void xykf(double d) {
        tBsG tBsG2 = this;
        o.v(tBsG2, -1142928173, (Double)o.a(tBsG2, -1142928173) - d);
    }
}

