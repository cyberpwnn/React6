/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
import org.bukkit.entity.Player;

public interface XSNy {
    public void Vnil();

    public void setName(String var1);

    public String getName();

    public feCR<String> URWm();

    public void UtIU(int var1, String var2);

    public void CoVI(feCR<String> var1);

    public String get(int var1);

    public void bhkI(Player var1);

    public void aLXV(String var1);

    public void fvLG();

    public void ooQj(Player var1);

    public feCR<Player> BtuM();

    public boolean IpeM(Player var1);

    public void update();
}

