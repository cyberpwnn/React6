/*
 * Decompiled with CFR 0_123.
 */
final class vbpi$yJLS {
    private vbpi$yJLS() {
    }

    protected final Object clone() {
        return this;
    }

    public boolean equals(Object object) {
        if (object != null && object != this) {
            return false;
        }
        return true;
    }

    public String toString() {
        return mrFx$WjFM.d("\ue090\ub47e\ueb3e\u9733");
    }

    /* synthetic */ vbpi$yJLS(vbpi$yJLS vbpi$yJLS) {
        this();
    }
}

