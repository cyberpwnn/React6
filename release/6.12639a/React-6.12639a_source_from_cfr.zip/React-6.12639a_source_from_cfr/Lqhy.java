/*
 * Decompiled with CFR 0_123.
 */
import java.io.IOException;

public interface Lqhy {
    public int getPort();

    public String getAddress();

    public JROj yJLS(JROj var1) throws IOException, Exception;

    public mrFx nuLT();
}

