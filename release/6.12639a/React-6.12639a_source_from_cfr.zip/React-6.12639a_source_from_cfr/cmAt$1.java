/*
 * Decompiled with CFR 0_123.
 */
class cmAt$1
implements Runnable {
    cmAt$1() {
    }

    @Override
    public void run() {
    }
}

