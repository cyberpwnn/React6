/*
 * Decompiled with CFR 0_123.
 */
public class OYNC {
    private long bjYX;

    public OYNC(long l) {
        this.bjYX = l;
    }

    public long get() {
        return (Long)o.a(this, -1615311808);
    }

    public void set(long l) {
        o.v(this, -1615311808, l);
    }

    public void add(long l) {
        OYNC oYNC = this;
        o.v(oYNC, -1615311808, (Long)o.a(oYNC, -1615311808) + l);
    }

    public void UQfI(long l) {
        OYNC oYNC = this;
        o.v(oYNC, -1615311808, (Long)o.a(oYNC, -1615311808) - l);
    }
}

