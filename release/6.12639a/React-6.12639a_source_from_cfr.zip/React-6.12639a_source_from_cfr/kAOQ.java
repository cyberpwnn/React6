/*
 * Decompiled with CFR 0_123.
 */
public interface kAOQ {
    public feCR<kAOQ> SvcY();

    public void aTvv();

    public void NxWm();

    public String getTag();

    public feCR<kAOQ> owua();

    public boolean klJY();

    public boolean OPgL();

    public void update();

    public void yJLS(kAOQ var1);
}

