/*
 * Decompiled with CFR 0_123.
 */
public class JIjX
extends Exception {
    private static final long serialVersionUID = 1;

    public JIjX(String string) {
        super(string);
    }
}

