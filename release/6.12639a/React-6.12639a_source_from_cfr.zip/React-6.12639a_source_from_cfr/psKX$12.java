/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 */
import net.md_5.bungee.api.ChatColor;

class psKX$12
extends psKX {
    psKX$12(String string2, int n2, char c, int n3) {
    }

    @Override
    public ChatColor asBungee() {
        return (ChatColor)o.k(2108504727);
    }
}

