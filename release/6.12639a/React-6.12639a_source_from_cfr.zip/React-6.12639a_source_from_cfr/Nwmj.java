/*
 * Decompiled with CFR 0_123.
 */
public class Nwmj
extends tSvi {
    private static final long serialVersionUID = 1122;

    public Nwmj(String string) {
        super(string);
    }
}

