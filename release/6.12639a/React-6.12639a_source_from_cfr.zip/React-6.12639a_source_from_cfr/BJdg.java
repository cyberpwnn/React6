/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 *  org.bukkit.command.ConsoleCommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.java.JavaPlugin
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.ArrayList;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public class BJdg {
    public static final String WJQN;
    public static final String NGgJ;
    public static final String Acbf;
    public static final String VyrC;
    public static final String QkDB;
    public static final String YGeC;
    public static final String xImM;
    public static final String YGeE;
    public static final String QbPl;
    public static final String Mfds;
    public static final String HEsb;
    public static final String Rutf;
    public static final String eRwf;
    public static final String jtJE;
    public static final String MffI;
    public static final String vfKJ;
    public static final String grop;
    private static final String oaXw;
    private static final String GTVK;
    private static final String FYcU;
    private static final String cMTu;
    private static final String MUgB;
    private static final String KaBp;
    private static final String SgyQ;
    private static final String MEFV;
    private static final String KWqX;
    private static final String hTTI;
    private static final String KPBT;
    private static final String ngFr;
    private static final String thXR;
    private static final String AAbF;
    private ArrayList<vbpi> LJTR = new ArrayList();

    public BJdg JYyP(String string) {
        return this.TEqA(string, mrFx$WjFM.d("\uad0b\u3dfd\u4ede\uc31c"));
    }

    public BJdg TEqA(String string, String string2) {
        return this.yJLS(string, string2, false, false, false, false, false);
    }

    public BJdg yJLS(String string, String string2, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        try {
            vbpi vbpi2 = new vbpi();
            BJdg.xg(vbpi2, mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), string);
            if (BJdg.xg(string2, mrFx$WjFM.d("\uf26f\ua9fc\ua9fb\ufeed")) == false) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf262\ua9fc\ua9f9\ufee7\u3e5d"), string2);
            }
            if (bl) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf263\ua9fc\ua9f9\ufeec"), true);
            }
            if (bl2) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf268\ua9e7\ua9f4\ufee4\u3e46\u7cb0"), true);
            }
            if (bl3) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf274\ua9fd\ua9f1\ufeed\u3e5d\u7cbf\u2e4e\u30cb\u30b0\u561c"), true);
            }
            if (bl4) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf272\ua9e7\ua9e7\ufee1\u3e44\u7cb6\u2e53\u30cd\u30a7\u5617\u8168\u3344\ua9c4"), true);
            }
            if (bl5) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf26e\ua9f1\ua9f3\ufefd\u3e5c\u7cb0\u2e46\u30d1\u30b0\u561c"), true);
            }
            BJdg.xg((ArrayList)o.a(this, 328354860), vbpi2);
        }
        catch (gggG gggG2) {
            gggG gggG3 = gggG2;
            BJdg.xg(gggG2);
        }
        return this;
    }

    public BJdg yJLS(String string, String string2, String string3) {
        return this.yJLS(string, string2, string3, false, false, false, false, false);
    }

    public BJdg yJLS(String string, String string2, String string3, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        try {
            vbpi vbpi2 = new vbpi();
            BJdg.xg(vbpi2, nJPf$sILv.G("\uf0e9\u0c8d\u5e48\u27e4"), string);
            if (BJdg.xg(string2, nJPf$sILv.G("\uf0f3\u0c87\u5e5e\u27f5")) == false) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0fe\u0c87\u5e5c\u27ff\u334a"), string2);
            }
            if (bl) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0ff\u0c87\u5e5c\u27f4"), true);
            }
            if (bl2) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0f4\u0c9c\u5e51\u27fc\u3351\ua41c"), true);
            }
            if (bl3) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0e8\u0c86\u5e54\u27f5\u334a\ua413\ufe9e\u166f\ueeb5\ub89d"), true);
            }
            if (bl4) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0ee\u0c9c\u5e42\u27f9\u3353\ua41a\ufe83\u1669\ueea2\ub896\u34ed\ucad3\ua946"), true);
            }
            if (bl5) {
                BJdg.xg(vbpi2, nJPf$sILv.G("\uf0f2\u0c8a\u5e56\u27e5\u334b\ua41c\ufe96\u1675\ueeb5\ub89d"), true);
            }
            BJdg.xg(vbpi2, nJPf$sILv.G("\uf0fe\u0c84\u5e59\u27f3\u3353\ua43a\ufe81\u1664\ueebe\ub88d"), BJdg.xg(BJdg.xg(new vbpi(), nJPf$sILv.G("\uf0fc\u0c8b\u5e44\u27f9\u3357\ua411"), nJPf$sILv.G("\uf0ef\u0c9d\u5e5e\u27cf\u335b\ua410\ufe9a\u166c\ueeb1\ub897\u34fc")), nJPf$sILv.G("\uf0eb\u0c89\u5e5c\u27e5\u335d"), string3));
            BJdg.xg((ArrayList)o.a(this, 328354860), vbpi2);
        }
        catch (gggG gggG2) {
            gggG gggG3 = gggG2;
            BJdg.xg(gggG2);
        }
        return this;
    }

    public BJdg yJLS(String string, String string2, String string3, String string4) {
        return this.yJLS(string, string2, string3, string4, false, false, false, false, false);
    }

    public BJdg yJLS(String string, String string2, String string3, String string4, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        try {
            vbpi vbpi2 = new vbpi();
            BJdg.xg(vbpi2, mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), string);
            if (BJdg.xg(string2, mrFx$WjFM.d("\uf26f\ua9fc\ua9fb\ufeed")) == false) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf262\ua9fc\ua9f9\ufee7\u3e5d"), string2);
            }
            if (bl) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf263\ua9fc\ua9f9\ufeec"), true);
            }
            if (bl2) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf268\ua9e7\ua9f4\ufee4\u3e46\u7cb0"), true);
            }
            if (bl3) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf274\ua9fd\ua9f1\ufeed\u3e5d\u7cbf\u2e4e\u30cb\u30b0\u561c"), true);
            }
            if (bl4) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf272\ua9e7\ua9e7\ufee1\u3e44\u7cb6\u2e53\u30cd\u30a7\u5617\u8168\u3344\ua9c4"), true);
            }
            if (bl5) {
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf26e\ua9f1\ua9f3\ufefd\u3e5c\u7cb0\u2e46\u30d1\u30b0\u561c"), true);
            }
            vbpi[] arrvbpi = new vbpi[1];
            if (BJdg.xg(string4, mrFx$WjFM.d("\uf26f\ua9fc\ua9fb\ufeed")) == false) {
                arrvbpi[0] = BJdg.xg(BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), string3), mrFx$WjFM.d("\uf262\ua9fc\ua9f9\ufee7\u3e5d"), string4);
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf269\ua9fc\ua9e3\ufeed\u3e5d\u7c96\u2e51\u30c0\u30bb\u560c"), BJdg.xg(BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf260\ua9f0\ua9e1\ufee1\u3e40\u7cbd"), mrFx$WjFM.d("\uf272\ua9fb\ua9fa\ufeff\u3e70\u7ca7\u2e42\u30dd\u30a1")), mrFx$WjFM.d("\uf277\ua9f2\ua9f9\ufefd\u3e4a"), BJdg.xg(BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), ""), mrFx$WjFM.d("\uf264\ua9eb\ua9e1\ufefa\u3e4e"), arrvbpi)));
            } else {
                arrvbpi[0] = BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), string3);
                BJdg.xg(vbpi2, mrFx$WjFM.d("\uf269\ua9fc\ua9e3\ufeed\u3e5d\u7c96\u2e51\u30c0\u30bb\u560c"), BJdg.xg(BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf260\ua9f0\ua9e1\ufee1\u3e40\u7cbd"), mrFx$WjFM.d("\uf272\ua9fb\ua9fa\ufeff\u3e70\u7ca7\u2e42\u30dd\u30a1")), mrFx$WjFM.d("\uf277\ua9f2\ua9f9\ufefd\u3e4a"), BJdg.xg(BJdg.xg(new vbpi(), mrFx$WjFM.d("\uf275\ua9f6\ua9ed\ufefc"), ""), mrFx$WjFM.d("\uf264\ua9eb\ua9e1\ufefa\u3e4e"), arrvbpi)));
            }
            BJdg.xg((ArrayList)o.a(this, 328354860), vbpi2);
        }
        catch (gggG gggG2) {
            gggG gggG3 = gggG2;
            BJdg.xg(gggG2);
        }
        return this;
    }

    public BJdg yJLS(String string, String string2, String string3, String string4, String string5) {
        return this.yJLS(string, string2, string3, string4, string5, false, false, false, false, false);
    }

    public BJdg yJLS(String string, String string2, String string3, String string4, String string5, boolean bl, boolean bl2, boolean bl3, boolean bl4, boolean bl5) {
        try {
            vbpi vbpi2 = new vbpi();
            BJdg.xg(vbpi2, FMkR$WjFM.a("\u092c\u2771\u580a\u1c4b"), string);
            if (BJdg.xg(string2, FMkR$WjFM.a("\u0936\u277b\u581c\u1c5a")) == false) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u093b\u277b\u581e\u1c50\ubc31"), string2);
            }
            if (bl) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u093a\u277b\u581e\u1c5b"), true);
            }
            if (bl2) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u0931\u2760\u5813\u1c53\ubc2a\u5b61"), true);
            }
            if (bl3) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u092d\u277a\u5816\u1c5a\ubc31\u5b6e\u0edc\ue08e\ud1cc\u1222"), true);
            }
            if (bl4) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u092b\u2760\u5800\u1c56\ubc28\u5b67\u0ec1\ue088\ud1db\u1229\u7e26\u60fd\u04a4"), true);
            }
            if (bl5) {
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u0937\u2776\u5814\u1c4a\ubc30\u5b61\u0ed4\ue094\ud1cc\u1222"), true);
            }
            BJdg.xg(vbpi2, FMkR$WjFM.a("\u093b\u2778\u581b\u1c5c\ubc28\u5b47\u0ec3\ue085\ud1c7\u1232"), BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u0939\u2777\u5806\u1c56\ubc2c\u5b6c"), FMkR$WjFM.a("\u092a\u2761\u581c\u1c60\ubc20\u5b6d\u0ed8\ue08d\ud1c8\u1228\u7e37")), FMkR$WjFM.a("\u092e\u2775\u581e\u1c4a\ubc26"), string3));
            vbpi[] arrvbpi = new vbpi[1];
            if (BJdg.xg(string5, FMkR$WjFM.a("\u0936\u277b\u581c\u1c5a")) == false) {
                arrvbpi[0] = BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u092c\u2771\u580a\u1c4b"), string4), FMkR$WjFM.a("\u093b\u277b\u581e\u1c50\ubc31"), string5);
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u0930\u277b\u5804\u1c5a\ubc31\u5b47\u0ec3\ue085\ud1c7\u1232"), BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u0939\u2777\u5806\u1c56\ubc2c\u5b6c"), FMkR$WjFM.a("\u092b\u277c\u581d\u1c48\ubc1c\u5b76\u0ed0\ue098\ud1dd")), FMkR$WjFM.a("\u092e\u2775\u581e\u1c4a\ubc26"), BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u092c\u2771\u580a\u1c4b"), ""), FMkR$WjFM.a("\u093d\u276c\u5806\u1c4d\ubc22"), arrvbpi)));
            } else {
                arrvbpi[0] = BJdg.xg(new vbpi(), FMkR$WjFM.a("\u092c\u2771\u580a\u1c4b"), string4);
                BJdg.xg(vbpi2, FMkR$WjFM.a("\u0930\u277b\u5804\u1c5a\ubc31\u5b47\u0ec3\ue085\ud1c7\u1232"), BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u0939\u2777\u5806\u1c56\ubc2c\u5b6c"), FMkR$WjFM.a("\u092b\u277c\u581d\u1c48\ubc1c\u5b76\u0ed0\ue098\ud1dd")), FMkR$WjFM.a("\u092e\u2775\u581e\u1c4a\ubc26"), BJdg.xg(BJdg.xg(new vbpi(), FMkR$WjFM.a("\u092c\u2771\u580a\u1c4b"), ""), FMkR$WjFM.a("\u093d\u276c\u5806\u1c4d\ubc22"), arrvbpi)));
            }
            BJdg.xg((ArrayList)o.a(this, 328354860), vbpi2);
        }
        catch (gggG gggG2) {
            gggG gggG3 = gggG2;
            BJdg.xg(gggG2);
        }
        return this;
    }

    public String vktP() {
        Object object = FMkR$WjFM.a("\u4722\u379e\ue599");
        Object object2 = BJdg.xg((ArrayList)o.a(this, 328354860));
        while (object2.hasNext()) {
            vbpi vbpi2 = (vbpi)object2.next();
            object = BJdg.xg(BJdg.xg(BJdg.xg(new StringBuilder((String)BJdg.xg(object)), FMkR$WjFM.a("\u4755")), BJdg.xg(vbpi2)));
        }
        return BJdg.xg(BJdg.xg(new StringBuilder((String)BJdg.xg(object)), FMkR$WjFM.a("\u4724")));
    }

    public void yJLS(JavaPlugin javaPlugin, Player player) {
        BJdg.xg(javaPlugin).dispatchCommand((CommandSender)BJdg.xg(javaPlugin).getConsoleSender(), (String)BJdg.xg(BJdg.xg(BJdg.xg(BJdg.xg(new StringBuilder(nJPf$sILv.G("\uf0e9\u0c8d\u5e5c\u27fc\u334a\ua41e\ufe80\u1621")), player.getName()), nJPf$sILv.G("\uf0bd")), this.vktP())));
    }

    private static Object xg(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }

    static {
        oaXw = nJPf$sILv.G("\u1c95\u9a7c\u637f\ueb15");
        GTVK = nJPf$sILv.G("\u1c82\u9a76\u636b\ueb0e\ufc6b");
        FYcU = nJPf$sILv.G("\u1c83\u9a76\u636b\ueb05");
        cMTu = nJPf$sILv.G("\u1c88\u9a6d\u6366\ueb0d\ufc70\ufbb9");
        MUgB = nJPf$sILv.G("\u1c94\u9a77\u6363\ueb04\ufc6b\ufbb6\uc47f\udaf4\u7558\uc144");
        KaBp = nJPf$sILv.G("\u1c92\u9a6d\u6375\ueb08\ufc72\ufbbf\uc462\udaf2\u754f\uc14f\ua9d1\ub8dc\u649b");
        SgyQ = nJPf$sILv.G("\u1c8e\u9a7b\u6361\ueb14\ufc6a\ufbb9\uc477\udaee\u7558\uc144");
        MEFV = nJPf$sILv.G("\u1c82\u9a75\u636e\ueb02\ufc72\ufb9f\uc460\udaff\u7553\uc154");
        KWqX = nJPf$sILv.G("\u1c89\u9a76\u6371\ueb04\ufc6b\ufb9f\uc460\udaff\u7553\uc154");
        hTTI = nJPf$sILv.G("\u1c80\u9a7a\u6373\ueb08\ufc76\ufbb4");
        KPBT = nJPf$sILv.G("\u1c97\u9a78\u636b\ueb14\ufc7c");
        ngFr = nJPf$sILv.G("\u1c84\u9a61\u6373\ueb13\ufc78");
        WJQN = nJPf$sILv.G("\u1c83\u9a75\u6366\ueb02\ufc72");
        NGgJ = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufbb8\uc47a\udaef\u7558");
        thXR = nJPf$sILv.G("\u1c92\u9a71\u6368\ueb16\ufc46\ufbae\uc473\udae2\u7549");
        Acbf = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufbbd\uc464\udaff\u7558\uc14e");
        AAbF = nJPf$sILv.G("\u1c93\u9a6c\u6369\ueb3e\ufc7a\ufbb5\uc47b\udaf7\u755c\uc14e\ua9c0");
        VyrC = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufbbb\uc467\udaef\u755c");
        QkDB = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufba8\uc473\udafe");
        YGeC = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufbaa\uc463\udae8\u754d\uc14c\ua9c1");
        xImM = nJPf$sILv.G("\u1c86\u9a76\u636b\ueb05");
        YGeE = nJPf$sILv.G("\u1c86\u9a6b\u6366\ueb18");
        QbPl = nJPf$sILv.G("\u1c85\u9a78\u6375\ueb0a\ufc46\ufbbd\uc464\udafb\u7544");
        Mfds = nJPf$sILv.G("\u1c83\u9a75\u6372\ueb04");
        HEsb = nJPf$sILv.G("\u1c86\u9a6b\u6362\ueb04\ufc77");
        Rutf = nJPf$sILv.G("\u1c80\u9a68\u6372\ueb00");
        eRwf = nJPf$sILv.G("\u1c93\u9a7c\u6363");
        jtJE = nJPf$sILv.G("\u1c8d\u9a70\u6360\ueb09\ufc6d\ufb85\uc466\udaef\u754f\uc150\ua9c8\ub8de");
        MffI = nJPf$sILv.G("\u1c98\u9a7c\u636b\ueb0d\ufc76\ufbad");
        vfKJ = nJPf$sILv.G("\u1c96\u9a71\u636e\ueb15\ufc7c");
        grop = nJPf$sILv.G("\u1c8f\u9a76\u6369\ueb04");
    }
}

