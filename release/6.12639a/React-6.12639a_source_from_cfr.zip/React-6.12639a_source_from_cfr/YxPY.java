/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.map.MapView
 */
import org.bukkit.inventory.ItemStack;
import org.bukkit.map.MapView;

public interface YxPY {
    public MapView hHjO();

    public UQqm XRnR();

    public void yJLS(UstC var1);

    public void NDol();

    public feCR<UstC> mWxx();

    public void UtIU(UstC var1);

    public void destroy();

    public ItemStack skNB();
}

