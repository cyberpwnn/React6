/*
 * Decompiled with CFR 0_123.
 */
class dDgX$2
extends CxNA {
    private final /* synthetic */ String mYUI;

    dDgX$2(String string) {
        this.mYUI = string;
    }

    @Override
    public void run() {
        o.w(-1111337224, (String)o.a(this, 680089337));
    }
}

