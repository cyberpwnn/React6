/*
 * Decompiled with CFR 0_123.
 */
import java.util.Collection;
import java.util.HashSet;

public class Lhwj<T>
extends HashSet<T> {
    private static final long serialVersionUID = 1;

    public Lhwj() {
    }

    public Lhwj(Collection<? extends T> collection) {
        super(collection);
    }

    public Lhwj(int n, float f) {
        super(n, f);
    }

    public Lhwj(int n) {
        super(n);
    }
}

