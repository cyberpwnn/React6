/*
 * Decompiled with CFR 0_123.
 */
public class GbVu {
    private String string;

    public GbVu(String string) {
        this.string = string;
    }

    public String get() {
        return (String)o.a(this, 243878975);
    }

    public void set(String string) {
        o.v(this, 243878975, string);
    }
}

