/*
 * Decompiled with CFR 0_123.
 */
public class pHDn
extends feCR<StackTraceElement> {
    private static final long serialVersionUID = -8770407657084760411L;
}

