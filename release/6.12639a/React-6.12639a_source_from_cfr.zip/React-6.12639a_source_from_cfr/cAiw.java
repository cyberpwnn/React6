/*
 * Decompiled with CFR 0_123.
 */
public interface cAiw {
    public TNku<Long, mGQw> biLo(long var1, long var3);
}

