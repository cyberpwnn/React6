/*
 * Decompiled with CFR 0_123.
 */
final class Fpab$HeSD$yJLS
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public Fpab$HeSD$yJLS(String string, Throwable throwable) {
        super(string, throwable);
    }
}

