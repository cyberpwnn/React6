/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class aTsu {
    public static final Character ydla;
    public static final Character UcvY;
    public static final Character vcst;
    public static final Character toQA;
    public static final Character vcsn;
    public static final Character wDxB;
    public static final Character huBi;
    public static final Character ymak;
    public static final Character GIoS;

    static {
        o.w(-578011599, aTsu.bO(38));
        o.w(2116304432, aTsu.bO(39));
        o.w(31080557, aTsu.bO(33));
        o.w(1374634102, aTsu.bO(61));
        o.w(1974878318, aTsu.bO(62));
        o.w(-441827215, aTsu.bO(60));
        o.w(-1910488969, aTsu.bO(63));
        o.w(-1963639249, aTsu.bO(34));
        o.w(1588609135, aTsu.bO(47));
    }

    public static String escape(String string) {
        StringBuilder stringBuilder = new StringBuilder((int)aTsu.bO(string));
        int n = 0;
        Object object = aTsu.bO(string);
        while (n < object) {
            Object object2 = aTsu.bO(string, n);
            switch (object2) {
                case 38: {
                    aTsu.bO(stringBuilder, mrFx$WjFM.d("\u280a\u9899\u8aae\u2748\u2e6e"));
                    break;
                }
                case 60: {
                    aTsu.bO(stringBuilder, mrFx$WjFM.d("\u280a\u9894\u8ab7\u2703"));
                    break;
                }
                case 62: {
                    aTsu.bO(stringBuilder, mrFx$WjFM.d("\u280a\u989f\u8ab7\u2703"));
                    break;
                }
                case 34: {
                    aTsu.bO(stringBuilder, mrFx$WjFM.d("\u280a\u9889\u8ab6\u2757\u2e21\u5e41"));
                    break;
                }
                case 39: {
                    aTsu.bO(stringBuilder, mrFx$WjFM.d("\u280a\u9899\u8ab3\u2757\u2e26\u5e41"));
                    break;
                }
                default: {
                    aTsu.bO(stringBuilder, object2);
                }
            }
            ++n;
        }
        return aTsu.bO(stringBuilder);
    }

    public static void YoVV(String string) throws gggG {
        Object object = aTsu.bO(string);
        if (object == false) {
            throw new gggG(FMkR$WjFM.a("\u624f\u5d1c\u67aa\u6df7\u1978\ub81e\u28f1\uc5b83\u8ae3\ud07f\u539a\ua453"));
        }
        int n = 0;
        while (n < object) {
            if (aTsu.bO(aTsu.bO(string, n)) != false) {
                throw new gggG((String)aTsu.bO(aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\u622d")), string), FMkR$WjFM.a("\u622d\u5d51\u67b9\u6dec\u196f\ub84a\u28e3\uc5a5/\u8af9\ud031\u539c\ua45d\u8807\u6526\u8804\u0b97\u2fcc\ufa54\u1da1\u4353\u5c2e\ud9f1\u63d9\u95c3\u19e8\u0830\uc6a4\u0de7"))));
            }
            ++n;
        }
    }

    /*
     * Enabled aggressive block sorting
     */
    private static boolean yJLS(Rjkm rjkm, vbpi vbpi2, String string) throws gggG {
        String string2;
        vbpi vbpi3 = null;
        Object object = aTsu.bO(rjkm);
        if (object != (Character)o.k(31080557)) {
            if (object == (Character)o.k(-1910488969)) {
                aTsu.bO(rjkm, FMkR$WjFM.a("\u0ee7\u00e1"));
                return false;
            }
            if (object == (Character)o.k(1588609135)) {
                object = aTsu.bO(rjkm);
                if (string == null) {
                    throw aTsu.bO(rjkm, aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7f8\u065a\uec31\u5232\u28f2\ua73b\u94b0\ue093\uefd0\u9983\u2101\u3d45\ub668\uaff1\u18d4\uf3fd\u574c\u81e6")), object)));
                }
                if (aTsu.bO(object, string) == false) {
                    throw aTsu.bO(rjkm, aTsu.bO(aTsu.bO(aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7f8\u065a\uec31\u5232\u28f2\ua73b\u94b0\ue093")), string), FMkR$WjFM.a("\u0ef8\u00be\uad22\uf7f1\u061b")), object)));
                }
                if (aTsu.bO(rjkm) == (Character)o.k(1974878318)) return true;
                throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0653\uec24\u5221\u28ff\ua73a\u94f4\ue0d0\uefdf\u9980\u211d\u3d53\ub62d\uafa5\u18c1\uf3fb"));
            }
            if (object instanceof Character) {
                throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0653\uec24\u5221\u28ff\ua73a\u94f4\ue0c7\uefd2\u9988"));
            }
        } else {
            Object object2 = aTsu.bO(rjkm);
            if (object2 == 45) {
                if (aTsu.bO(rjkm) == 45) {
                    aTsu.bO(rjkm, FMkR$WjFM.a("\u0ef5\u00f2\uad72"));
                    return false;
                }
                aTsu.bO(rjkm);
            } else if (object2 == 91) {
                object = aTsu.bO(rjkm);
                if (aTsu.bO(FMkR$WjFM.a("\u0e9b\u009b\uad0d\uf7c1\u067a"), object) == false) throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e9d\u00a7\uad3c\uf7f0\u0658\uec31\u5234\u28fe\ua77e\u94f3\ue0f0\ueff7\u99ae\u213a\u3d77\ub656\uaff6"));
                if (aTsu.bO(rjkm) != 91) throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e9d\u00a7\uad3c\uf7f0\u0658\uec31\u5234\u28fe\ua77e\u94f3\ue0f0\ueff7\u99ae\u213a\u3d77\ub656\uaff6"));
                Object object3 = aTsu.bO(rjkm);
                if (aTsu.bO(object3) <= 0) return false;
                aTsu.bO(vbpi2, FMkR$WjFM.a("\u0ebb\u00b0\uad22\uf7e1\u065e\uec2b\u5225"), object3);
                return false;
            }
            int n = 1;
            do {
                if ((object = aTsu.bO(rjkm)) == null) {
                    throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0652\uec2b\u5236\u28ba\ua779\u94ea\ue094\uef93\u998e\u2108\u3d42\ub668\uafa3\u1880\uf3bb\u5717\u81e7\u416a\u4c30"));
                }
                if (object == (Character)o.k(-441827215)) {
                    ++n;
                    continue;
                }
                if (object != (Character)o.k(1974878318)) continue;
                --n;
            } while (n > 0);
            return false;
        }
        String string3 = (String)object;
        object = null;
        vbpi3 = new vbpi();
        do {
            if (object == null) {
                object = aTsu.bO(rjkm);
            }
            if (!(object instanceof String)) break;
            string2 = (String)object;
            object = aTsu.bO(rjkm);
            if (object == (Character)o.k(1374634102)) {
                object = aTsu.bO(rjkm);
                if (!(object instanceof String)) {
                    throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0652\uec2b\u5236\u28ba\ua728\u94b5\ue0df\uefc6\u998a"));
                }
                aTsu.bO(vbpi3, string2, aTsu.stringToValue((String)object));
                object = null;
                continue;
            }
            aTsu.bO(vbpi3, string2, "");
        } while (true);
        if (object == (Character)o.k(1588609135)) {
            if (aTsu.bO(rjkm) != (Character)o.k(1974878318)) {
                throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0653\uec24\u5221\u28ff\ua73a\u94f4\ue0c7\uefd2\u9988"));
            }
            if (aTsu.bO(vbpi3) > 0) {
                aTsu.bO(vbpi2, string3, vbpi3);
                return false;
            }
            aTsu.bO(vbpi2, string3, "");
            return false;
        }
        if (object != (Character)o.k(1974878318)) throw aTsu.bO(rjkm, FMkR$WjFM.a("\u0e95\u00b6\uad3f\uf7e6\u0653\uec24\u5221\u28ff\ua73a\u94f4\ue0c7\uefd2\u9988"));
        do {
            if ((object = aTsu.bO(rjkm)) == null) {
                if (string3 == null) return false;
                throw aTsu.bO(rjkm, aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\u0e8d\u00b1\uad2f\uf7f9\u0654\uec36\u5234\u28fe\ua77e\u94a0\ue0d2\uefd4\u99cf")), string3)));
            }
            if (object instanceof String) {
                string2 = (String)object;
                if (aTsu.bO(string2) <= 0) continue;
                aTsu.bO(vbpi3, FMkR$WjFM.a("\u0ebb\u00b0\uad22\uf7e1\u065e\uec2b\u5225"), aTsu.stringToValue(string2));
                continue;
            }
            if (object == (Character)o.k(-441827215) && aTsu.yJLS(rjkm, vbpi3, string3)) break;
        } while (true);
        if (aTsu.bO(vbpi3) == false) {
            aTsu.bO(vbpi2, string3, "");
            return false;
        }
        if (aTsu.bO(vbpi3) == true) {
            if (aTsu.bO(vbpi3, FMkR$WjFM.a("\u0ebb\u00b0\uad22\uf7e1\u065e\uec2b\u5225")) != null) {
                aTsu.bO(vbpi2, string3, aTsu.bO(vbpi3, FMkR$WjFM.a("\u0ebb\u00b0\uad22\uf7e1\u065e\uec2b\u5225")));
                return false;
            }
        }
        aTsu.bO(vbpi2, string3, vbpi3);
        return false;
    }

    public static Object stringToValue(String string) {
        if (aTsu.bO(nJPf$sILv.G("\ucf77\uf2da\u5a4a\u5dd0"), string) != false) {
            return (Boolean)o.k(-316456551);
        }
        if (aTsu.bO(nJPf$sILv.G("\ucf65\uf2c9\u5a53\u5dc6\uf2c1"), string) != false) {
            return (Boolean)o.k(-1311620710);
        }
        if (aTsu.bO(nJPf$sILv.G("\ucf6d\uf2dd\u5a53\u5dd9"), string) != false) {
            return o.k(671498640);
        }
        try {
            Object object = aTsu.bO(string, false);
            if (object == 45 || object >= 48 && object <= 57) {
                Long l = new Long(string);
                if (aTsu.bO(aTsu.bO(l), string) != false) {
                    return l;
                }
            }
        }
        catch (Exception exception) {
            try {
                Double d = new Double(string);
                if (aTsu.bO(aTsu.bO(d), string) != false) {
                    return d;
                }
            }
            catch (Exception exception2) {
                // empty catch block
            }
        }
        return string;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static vbpi bhkI(String var0) throws gggG {
        var1_1 = new vbpi();
        var2_2 = new Rjkm(var0);
        ** GOTO lbl7
lbl-1000: // 1 sources:
        {
            aTsu.yJLS(var2_2, var1_1, null);
lbl7: // 2 sources:
            if (aTsu.bO(var2_2) == false) return var1_1;
            ** while (aTsu.bO(var2_2, mrFx$WjFM.d((Object)"\u2ecb")) != false)
        }
lbl11: // 1 sources:
        return var1_1;
    }

    public static String toString(Object object) throws gggG {
        return aTsu.toString(object, null);
    }

    public static String toString(Object object, String string) throws gggG {
        String string2;
        StringBuilder stringBuilder = new StringBuilder();
        if (object instanceof vbpi) {
            if (string != null) {
                aTsu.bO(stringBuilder, 60);
                aTsu.bO(stringBuilder, string);
                aTsu.bO(stringBuilder, 62);
            }
            vbpi vbpi2 = (vbpi)object;
            Object object2 = aTsu.bO(vbpi2);
            while (object2.hasNext()) {
                JRRx jRRx;
                int n;
                Object object3;
                String string3 = (String)object2.next();
                Object object4 = aTsu.bO(vbpi2, string3);
                if (object4 == null) {
                    object4 = "";
                }
                String string4 = object4 instanceof String ? (String)object4 : null;
                if (aTsu.bO(FMkR$WjFM.a("\ued63\u2a35\u4685\u0e7f\u89d4\u67ec\u8649"), string3) != false) {
                    if (object4 instanceof JRRx) {
                        jRRx = (JRRx)object4;
                        object3 = aTsu.bO(jRRx);
                        n = 0;
                        while (n < object3) {
                            if (n > 0) {
                                aTsu.bO(stringBuilder, 10);
                            }
                            aTsu.bO(stringBuilder, aTsu.escape((String)aTsu.bO(aTsu.bO(jRRx, n))));
                            ++n;
                        }
                        continue;
                    }
                    aTsu.bO(stringBuilder, aTsu.escape((String)aTsu.bO(object4)));
                    continue;
                }
                if (object4 instanceof JRRx) {
                    jRRx = (JRRx)object4;
                    object3 = aTsu.bO(jRRx);
                    n = 0;
                    while (n < object3) {
                        object4 = aTsu.bO(jRRx, n);
                        if (object4 instanceof JRRx) {
                            aTsu.bO(stringBuilder, 60);
                            aTsu.bO(stringBuilder, string3);
                            aTsu.bO(stringBuilder, 62);
                            aTsu.bO(stringBuilder, aTsu.toString(object4));
                            aTsu.bO(stringBuilder, FMkR$WjFM.a("\ued3c\u2a75"));
                            aTsu.bO(stringBuilder, string3);
                            aTsu.bO(stringBuilder, 62);
                        } else {
                            aTsu.bO(stringBuilder, aTsu.toString(object4, string3));
                        }
                        ++n;
                    }
                    continue;
                }
                if (aTsu.bO("", object4) != false) {
                    aTsu.bO(stringBuilder, 60);
                    aTsu.bO(stringBuilder, string3);
                    aTsu.bO(stringBuilder, FMkR$WjFM.a("\ued2f\u2a64"));
                    continue;
                }
                aTsu.bO(stringBuilder, aTsu.toString(object4, string3));
            }
            if (string != null) {
                aTsu.bO(stringBuilder, FMkR$WjFM.a("\ued3c\u2a75"));
                aTsu.bO(stringBuilder, string);
                aTsu.bO(stringBuilder, 62);
            }
            return aTsu.bO(stringBuilder);
        }
        if (aTsu.bO(aTsu.bO(object)) != false) {
            object = new JRRx(object);
        }
        if (object instanceof JRRx) {
            JRRx jRRx = (JRRx)object;
            Object object5 = aTsu.bO(jRRx);
            int n = 0;
            while (n < object5) {
                aTsu.bO(stringBuilder, aTsu.toString(aTsu.bO(jRRx, n), string == null ? FMkR$WjFM.a("\ued61\u2a28\u4699\u0e6a\u89c8") : string));
                ++n;
            }
            return aTsu.bO(stringBuilder);
        }
        String string5 = object == null ? FMkR$WjFM.a("\ued6e\u2a2f\u4687\u0e67") : (string2 = aTsu.escape((String)aTsu.bO(object)));
        if (string == null) {
            return aTsu.bO(aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\ued22")), string2), FMkR$WjFM.a("\ued22")));
        }
        if (aTsu.bO(string2) == false) {
            return aTsu.bO(aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\ued3c")), string), FMkR$WjFM.a("\ued2f\u2a64")));
        }
        return aTsu.bO(aTsu.bO(aTsu.bO(aTsu.bO(aTsu.bO(aTsu.bO(aTsu.bO(new StringBuilder(FMkR$WjFM.a("\ued3c")), string), FMkR$WjFM.a("\ued3e")), string2), FMkR$WjFM.a("\ued3c\u2a75")), string), FMkR$WjFM.a("\ued3e")));
    }

    private static Object bO(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

