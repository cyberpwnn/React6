/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class NgWw$UtIU
extends Enum<NgWw$UtIU> {
    public static final /* enum */ NgWw$UtIU vTgP;
    public static final /* enum */ NgWw$UtIU RTRD;
    public static final /* enum */ NgWw$UtIU VFkV;
    public static final /* enum */ NgWw$UtIU tOBH;
    public static final /* enum */ NgWw$UtIU iyUi;
    public static final /* enum */ NgWw$UtIU JCiK;
    public static final /* enum */ NgWw$UtIU Ocyd;
    public static final /* enum */ NgWw$UtIU nVAa;
    public static final /* enum */ NgWw$UtIU svRY;
    public static final /* enum */ NgWw$UtIU WdBI;
    public static final /* enum */ NgWw$UtIU MMQV;
    public static final /* enum */ NgWw$UtIU mkoH;
    public static final /* enum */ NgWw$UtIU OSVr;
    public static final /* enum */ NgWw$UtIU kUGu;
    public static final /* enum */ NgWw$UtIU Atcc;
    public static final /* enum */ NgWw$UtIU Mwdc;
    public static final /* enum */ NgWw$UtIU IIUd;
    public static final /* enum */ NgWw$UtIU dOre;
    public static final /* enum */ NgWw$UtIU CGeN;
    public static final /* enum */ NgWw$UtIU DmJs;
    private final String path;
    private static final /* synthetic */ NgWw$UtIU[] FPmU;

    static {
        o.w(-1790689046, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc6\u53e8\u01f1\u9c7f\u7209\uc14e\ud0d8\u70a3\u494c\u580f\u24c4+\u4f46\ueaaa\uef35\uabd3"), 0, (String)NgWw$UtIU.oG(NgWw$UtIU.oG(new StringBuilder(nJPf$sILv.G("\uace5\u53c4\u01cb\u9c14\u7227\uc175\ud0f7\u7080\u497b\u5822\u24f6\b\u4f60\uead2\uef03\uabe4\u2081\ub28e\u68e4\u5a40\u05fd")), NgWw$UtIU.getServerVersion()))));
        o.w(-2079768193, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c3"), 1, (String)NgWw$UtIU.oG(NgWw$UtIU.oG(new StringBuilder(nJPf$sILv.G("\uace4\u53d3\u01d8\u9c14\u7228\uc169\ud0f2\u708e\u4971\u5824\u24b9\r\u4f66\uea9d\uef16\uabf5\u2091\ub28d\u68ea\u5a59\u05ba\u746f\u3e50")), NgWw$UtIU.getServerVersion()))));
        o.w(1743012222, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f56\ueab0\uef3f\uabc2\u20b8"), 2, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace9\u53cd\u01d0\u9c59\u7221")));
        o.w(236929405, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f57\ueab4\uef25\uabcf\u20b8\ub2b1\u68ce"), 3, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace8\u53c9\u01ca\u9c54\u7221\uc175\ud0f6")));
        o.w(-1693826692, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f57\ueab3\uef3d\uabcc\u20b2\ub2b6\u68c5"), 4, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace8\u53ce\u01d2\u9c57\u722b\uc172\ud0fd")));
        o.w(59195771, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f57\ueab3\uef3e\uabd7\u20b6\ub2aa\u68d2\u5a73\u0587\u7452\u3e31\u29bf\u20b8"), 5, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace8\u53ce\u01d1\u9c4c\u722f\uc16e\ud0ea\u7084\u496c\u5839\u24f8\u0000\u4f67")));
        o.w(-1992343286, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f51\ueab2\uef33\uabc9\u20b2\ub2b6\u68d5\u5a7f\u0596\u7455\u3e2d"), 6, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacee\u53cf\u01dc\u9c52\u722b\uc172\ud0ed\u7088\u497d\u583e\u24e3\u001d")));
        o.w(-1555480347, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f51\ueab2\uef24\uabc8\u20a7\ub2a1"), 7, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacee\u53cf\u01cb\u9c53\u723e\uc165")));
        o.w(484327689, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f51\ueaaa\uef35\uabcf\u20a7"), 8, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacee\u53d7\u01da\u9c54\u723e")));
        o.w(1670988040, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f53\ueab9\uef3e\uabc4\u20a1\ub2b9\u68d5\u5a7d\u0581"), 9, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacec\u53c4\u01d1\u9c5f\u7238\uc17d\ud0ed\u708a\u496a")));
        o.w(-52084473, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f5c\ueab9\uef3c\uabd1"), 10, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace3\u53c4\u01d3\u9c4a")));
        o.w(-1887289082, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f5d\ueab2\uef26\uabc4\u20bd\ub2ac\u68ce\u5a60\u058a"), 11, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace2\u53cf\u01c9\u9c5f\u7224\uc168\ud0f6\u7097\u4961")));
        o.w(-933084923, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f59\ueabd\uef20"), 12, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace6\u53c0\u01cf")));
        o.w(168902916, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f59\ueab9\uef24\uabc0\u20b7\ub2b9\u68d5\u5a73"), 13, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uace6\u53c4\u01cb\u9c5b\u722e\uc17d\ud0ed\u7084")));
        o.w(-933543677, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f44\ueab3\uef24\uabc8\u20bc\ub2b6"), 14, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacfb\u53ce\u01cb\u9c53\u7225\uc172")));
        o.w(-2071445006, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f44\ueaae\uef3f\uabcb\u20b6\ub2bb\u68d5\u5a7b\u059f\u745e\u3e2d"), 15, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacfb\u53d3\u01d0\u9c50\u722f\uc17f\ud0ed\u708c\u4974\u5835\u24e4")));
        o.w(323437041, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f47\ueabf\uef38\uabc4\u20b7\ub2ad\u68cd\u5a77\u0581"), 16, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacf8\u53c2\u01d7\u9c5f\u722e\uc169\ud0f5\u7080\u496a")));
        o.w(1303396848, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f47\ueabf\uef3f\uabd3\u20b6\ub2ba\u68ce\u5a73\u0581\u745f"), 17, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacf8\u53c2\u01d0\u9c48\u722f\uc17e\ud0f6\u7084\u496a\u5834")));
        o.w(144065007, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f41\ueaac\uef34\uabc0\u20a7\ub2bd\u68d3"), 18, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacfe\u53d1\u01db\u9c5b\u723e\uc179\ud0eb")));
        o.w(-728808978, (Object)new NgWw$UtIU(nJPf$sILv.G("\uacc8\u53f3\u01fe\u9c7c\u721e\uc15e\ud0cc\u70ae\u4953\u5819\u24c31\u4f41\ueaa8\uef39\uabcd"), 19, (NgWw$UtIU)((Object)o.k(-2079768193)), nJPf$sILv.G("\uacfe\u53d5\u01d6\u9c56")));
        o.w(-998096403, new NgWw$UtIU[]{(NgWw$UtIU)((Object)o.k(-1790689046)), (NgWw$UtIU)((Object)o.k(-2079768193)), (NgWw$UtIU)((Object)o.k(1743012222)), (NgWw$UtIU)((Object)o.k(236929405)), (NgWw$UtIU)((Object)o.k(-1693826692)), (NgWw$UtIU)((Object)o.k(59195771)), (NgWw$UtIU)((Object)o.k(-1992343286)), (NgWw$UtIU)((Object)o.k(-1555480347)), (NgWw$UtIU)((Object)o.k(484327689)), (NgWw$UtIU)((Object)o.k(1670988040)), (NgWw$UtIU)((Object)o.k(-52084473)), (NgWw$UtIU)((Object)o.k(-1887289082)), (NgWw$UtIU)((Object)o.k(-933084923)), (NgWw$UtIU)((Object)o.k(168902916)), (NgWw$UtIU)((Object)o.k(-933543677)), (NgWw$UtIU)((Object)o.k(-2071445006)), (NgWw$UtIU)((Object)o.k(323437041)), (NgWw$UtIU)((Object)o.k(1303396848)), (NgWw$UtIU)((Object)o.k(144065007)), (NgWw$UtIU)((Object)o.k(-728808978))});
    }

    private NgWw$UtIU(String string2, int n2, String string3) {
        this.path = string2;
    }

    private NgWw$UtIU(String string2, int n2, NgWw$UtIU ngWw$UtIU, String string3) {
        this(string, n, (String)NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(new StringBuilder(), string2), nJPf$sILv.G("\u659d")), n2)));
    }

    public String getPath() {
        return (String)o.a((Object)this, -69320212);
    }

    public Class<?> getClass(String string) throws ClassNotFoundException {
        return NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(new StringBuilder(), this), mrFx$WjFM.d("\u83df")), string)));
    }

    public String toString() {
        return (String)o.a((Object)this, -69320212);
    }

    public static String getServerVersion() {
        return NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG(NgWw$UtIU.oG()))), 23);
    }

    public static NgWw$UtIU[] values() {
        NgWw$UtIU[] arrngWw$UtIU = (NgWw$UtIU[])o.k(-998096403);
        int n = arrngWw$UtIU.length;
        NgWw$UtIU[] arrngWw$UtIU2 = new NgWw$UtIU[n];
        NgWw$UtIU.oG(arrngWw$UtIU, false, arrngWw$UtIU2, false, n);
        return arrngWw$UtIU2;
    }

    public static NgWw$UtIU valueOf(String string) {
        return (NgWw$UtIU)((Object)NgWw$UtIU.oG(NgWw$UtIU.class, string));
    }

    private static Object oG(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

