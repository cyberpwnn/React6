/*
 * Decompiled with CFR 0_123.
 */
import java.io.Serializable;

public class nBGQ<A, B, C>
implements Serializable {
    private static final long serialVersionUID = 1912465707826963942L;
    private A ejpp;
    private B rOUV;
    private C FFfQ;

    public nBGQ(A a, B b, C c) {
        this.ejpp = a;
        this.rOUV = b;
        this.FFfQ = c;
    }

    public A ntkf() {
        return (A)o.a(this, 1790725315);
    }

    public void ktHX(A a) {
        o.v(this, 1790725315, a);
    }

    public B XAhy() {
        return (B)o.a(this, 416959666);
    }

    public void HeSD(B b) {
        o.v(this, 416959666, b);
    }

    public C oUjh() {
        return (C)o.a(this, -96514895);
    }

    public void Mkpo(C c) {
        o.v(this, -96514895, c);
    }
}

