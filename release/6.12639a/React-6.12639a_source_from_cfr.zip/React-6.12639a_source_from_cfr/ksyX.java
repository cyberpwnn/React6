/*
 * Decompiled with CFR 0_123.
 */
public interface ksyX {
    public void yJLS(eHVp var1);

    public void SKsf();

    public void dgVt();

    public void Kwaa();

    public void NpJL();

    public void yJLS(yAmM var1);

    public feCR<yAmM> eHVp();

    public Lqeo owvU();
}

