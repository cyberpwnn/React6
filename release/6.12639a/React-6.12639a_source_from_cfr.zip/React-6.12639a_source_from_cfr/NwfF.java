/*
 * Decompiled with CFR 0_123.
 */
public interface NwfF {
    public String getID();

    public ntkx xynF();

    public String getName();

    public String getDescription();

    public void setID(String var1);

    public void setName(String var1);

    public void setDescription(String var1);

    public psKX aLXV();

    public psKX Surr();

    public void yJLS(psKX var1, psKX var2);

    public int getInterval();

    public void UtIU(int var1);

    public void IgvC();

    public String get();

    public void equl();

    public void setValue(double var1);

    public double getValue();
}

