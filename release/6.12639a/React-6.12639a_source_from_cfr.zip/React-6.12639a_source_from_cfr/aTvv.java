/*
 * Decompiled with CFR 0_123.
 */
public class aTvv
extends Exception {
    private static final long serialVersionUID = 1;
}

