/*
 * Decompiled with CFR 0_123.
 */
final class Fpab$qcvH
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public Fpab$qcvH(String string) {
        super(string);
    }
}

