/*
 * Decompiled with CFR 0_123.
 */
public class ghLV
extends jOQr<Integer> {
    protected ghLV(Integer n) {
        super((WaLc)((Object)o.k(-1498592084)), n);
    }
}

