/*
 * Decompiled with CFR 0_123.
 */
public interface JROj
extends mGQw {
    public int getId();

    public XAfJ ArMt();

    public String dfot();
}

