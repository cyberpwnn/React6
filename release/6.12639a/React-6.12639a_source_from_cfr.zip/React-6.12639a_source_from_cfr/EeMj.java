/*
 * Decompiled with CFR 0_123.
 */
import java.util.List;

public interface EeMj<T> {
    public void bhkI(T var1);

    public void IpeM(double var1);

    public double XRsy();

    public int dMfa();

    public int yJLS(MRfD var1);

    public void ooQj(T var1);

    public void biLo(List<T> var1);

    public void yJLS(T[] var1);
}

