/*
 * Decompiled with CFR 0_123.
 */
class FyEK$1
extends vbvg {
    final /* synthetic */ FyEK VpCA;

    FyEK$1(FyEK fyEK, String string, int n) {
        this.VpCA = fyEK;
        super(string, n);
    }

    @Override
    public void run() {
        new FyEK$1$1(this);
    }

    static /* synthetic */ FyEK yJLS(FyEK$1 fyEK$1) {
        return (FyEK)o.a(fyEK$1, 1265719551);
    }
}

