/*
 * Decompiled with CFR 0_123.
 */
public class uGGj {
    private byte vekM;

    public uGGj(byte by) {
        this.vekM = by;
    }

    public byte JAeA() {
        if (((Byte)o.a(this, -1074708005)).byteValue() > 7) {
            return 7;
        }
        if (((Byte)o.a(this, -1074708005)).byteValue() < 0) {
            return 0;
        }
        return ((Byte)o.a(this, -1074708005)).byteValue();
    }

    public void HeSD(byte by) {
        o.v(this, -1074708005, Byte.valueOf(by));
    }
}

