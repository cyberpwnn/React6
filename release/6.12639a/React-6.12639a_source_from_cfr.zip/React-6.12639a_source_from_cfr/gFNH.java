/*
 * Decompiled with CFR 0_123.
 */
public class gFNH {
    private final int width;
    private final int height;
    private final int depth;

    public gFNH(int n, int n2, int n3) {
        this.width = n;
        this.height = n2;
        this.depth = n3;
    }

    public gFNH(int n, int n2) {
        this.width = n;
        this.height = n2;
        this.depth = 0;
    }

    public cAqI rxul() {
        if ((Integer)o.a(this, -1957086447) == 1) {
            return (cAqI)((Object)o.k(676936464));
        }
        if ((Integer)o.a(this, 1696283407) == 1) {
            return (cAqI)((Object)o.k(-714065138));
        }
        if ((Integer)o.a(this, -1657586931) == 1) {
            return (cAqI)((Object)o.k(1399995148));
        }
        return null;
    }

    public int getWidth() {
        return (Integer)o.a(this, -1957086447);
    }

    public int getHeight() {
        return (Integer)o.a(this, 1696283407);
    }

    public int getDepth() {
        return (Integer)o.a(this, -1657586931);
    }
}

