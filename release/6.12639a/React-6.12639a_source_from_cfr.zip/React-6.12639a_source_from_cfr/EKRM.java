/*
 * Decompiled with CFR 0_123.
 */
public abstract class EKRM<FROM, TO>
implements QVao<FROM, TO> {
    @Override
    public TO KTiK(FROM FROM) {
        return this.GPlk(FROM);
    }

    @Override
    public abstract TO GPlk(FROM var1);
}

