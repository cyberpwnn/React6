/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Event
 *  org.bukkit.event.HandlerList
 */
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

public class dLuw
extends Event {
    private static final HandlerList RQwW;

    static {
        o.w(-2101782825, (Object)new HandlerList());
    }

    public HandlerList getHandlers() {
        return (HandlerList)o.k(-2101782825);
    }

    public static HandlerList getHandlerList() {
        return (HandlerList)o.k(-2101782825);
    }
}

