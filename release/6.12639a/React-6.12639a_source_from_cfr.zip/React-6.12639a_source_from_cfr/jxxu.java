/*
 * Decompiled with CFR 0_123.
 */
public class jxxu
extends ggmf {
    @Override
    public void start() {
    }

    @Override
    public void stop() {
    }

    @Override
    public void tick() {
    }
}

