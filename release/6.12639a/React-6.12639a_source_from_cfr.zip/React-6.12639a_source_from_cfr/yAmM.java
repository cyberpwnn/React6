/*
 * Decompiled with CFR 0_123.
 */
public interface yAmM {
    public void start();

    public void stop();

    public void tick();
}

