/*
 * Decompiled with CFR 0_123.
 */
public interface ColC {
    public void run();
}

