/*
 * Decompiled with CFR 0_123.
 */
final class Fpab$ktHX
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public Fpab$ktHX(String string) {
        super(string);
    }
}

