/*
 * Decompiled with CFR 0_123.
 */
public class SmsU
extends jOQr<Long> {
    protected SmsU(Long l) {
        super((WaLc)((Object)o.k(-1643098965)), l);
    }
}

