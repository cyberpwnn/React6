/*
 * Decompiled with CFR 0_123.
 */
public class QEdN {
    private long yShE = 0;
    private long yuje = 0;
    private long Pmtm = 0;
    private long kRnh = 0;

    public double cAiw() {
        return (double)((Long)o.a(this, -885571917)).longValue() / (double)((Long)o.a(this, 773471906)).longValue();
    }

    public long jycd() {
        return (Long)o.a(this, -885571917);
    }

    public void CoVI(long l) {
        o.v(this, -885571917, l);
    }

    public long goyd() {
        return (Long)o.a(this, 773471906);
    }

    public void wKtV(long l) {
        o.v(this, 773471906, l);
    }

    public long Smoy() {
        return (Long)o.a(this, 1642020513);
    }

    public void xykf(long l) {
        o.v(this, 1642020513, l);
    }

    public long DXtE() {
        return (Long)o.a(this, 38813344);
    }

    public void IFQY(long l) {
        o.v(this, 38813344, l);
    }
}

