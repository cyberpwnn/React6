/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class eHVp
extends Enum<eHVp> {
    public static final /* enum */ eHVp rsJf;
    public static final /* enum */ eHVp DJcE;
    public static final /* enum */ eHVp CjDF;
    public static final /* enum */ eHVp qVTn;
    public static final /* enum */ eHVp KykJ;
    public static final /* enum */ eHVp IQbL;
    public static final /* enum */ eHVp keco;
    public static final /* enum */ eHVp wFbu;
    public static final /* enum */ eHVp BLnM;
    public static final /* enum */ eHVp aFdy;
    public static final /* enum */ eHVp sdjf;
    public static final /* enum */ eHVp rahH;
    public static final /* enum */ eHVp TAAL;
    public static final /* enum */ eHVp NjCa;
    public static final /* enum */ eHVp EDuU;
    public static final /* enum */ eHVp yMNR;
    public static final /* enum */ eHVp YOrD;
    public static final /* enum */ eHVp ubdK;
    public static final /* enum */ eHVp pRtE;
    public static final /* enum */ eHVp Ocvd;
    public static final /* enum */ eHVp KynK;
    public static final /* enum */ eHVp ojEG;
    public static final /* enum */ eHVp puWp;
    public static final /* enum */ eHVp kTfW;
    public static final /* enum */ eHVp RTOW;
    public static final /* enum */ eHVp Tsfq;
    public static final /* enum */ eHVp rrmG;
    public static final /* enum */ eHVp PMiA;
    public static final /* enum */ eHVp Aknq;
    public static final /* enum */ eHVp cfaX;
    public static final /* enum */ eHVp IIUJ;
    public static final /* enum */ eHVp YYDU;
    public static final /* enum */ eHVp ffxo;
    public static final /* enum */ eHVp rPiW;
    public static final /* enum */ eHVp eBSj;
    public static final /* enum */ eHVp mlNW;
    public static final /* enum */ eHVp tFNd;
    public static final /* enum */ eHVp MUaS;
    public static final /* enum */ eHVp didO;
    public static final /* enum */ eHVp BUaj;
    public static final /* enum */ eHVp hSks;
    public static final /* enum */ eHVp NYCY;
    public static final /* enum */ eHVp mIjE;
    public static final /* enum */ eHVp DSUm;
    public static final /* enum */ eHVp sBiw;
    public static final /* enum */ eHVp kwHv;
    public static final /* enum */ eHVp GTOJ;
    public static final /* enum */ eHVp BEAS;
    public static final /* enum */ eHVp DAtl;
    public static final /* enum */ eHVp fMfB;
    public static final /* enum */ eHVp oicA;
    public static final /* enum */ eHVp NaSi;
    public static final /* enum */ eHVp OBSj;
    public static final /* enum */ eHVp ynoP;
    private int version;
    private String THrU;
    private String bAYv;
    private boolean mRYw;
    private static final /* synthetic */ eHVp[] VFhJ;

    static {
        o.w(385566194, (Object)new eHVp(nJPf$sILv.G("\ube0a\ub524\u6f32\uc9e5\ub9ca\ubb50"), 0, 10000, nJPf$sILv.G("\ube0a\ub504\u6f12\uc9c5\ub9ea\ubb70")));
        o.w(-1647224698, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9ab\ubb5b\ue7f7"), 1, 340, nJPf$sILv.G("\ube77\ub54b\u6f57\uc992\ub9b7\ubb36"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9ab\ubb5b\ue797\u5da1")));
        o.w(-1135723689, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9ab\ubb5b\ue7f7\u5dcf\u2f97\u4ddd\ubc06"), 2, 339, nJPf$sILv.G("\ube77\ub54b\u6f57\uc992\ub9b7\ubb36\ue7e8\u5dc0\u2f95\u4dca"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9ab\ubb5b\ue797\u5da1")));
        o.w(-1210565802, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9ab\ubb5b\ue7f4"), 3, 338, nJPf$sILv.G("\ube77\ub54b\u6f57\uc992\ub9b7\ubb35"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9ab\ubb5b\ue797\u5da1")));
        o.w(-543991673, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9ab"), 4, 335, nJPf$sILv.G("\ube77\ub54b\u6f57\uc992"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9ab\ubb5b\ue797\u5da1")));
        o.w(-1641785212, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a8\ubb5b\ue7f7"), 5, 316, nJPf$sILv.G("\ube77\ub54b\u6f57\uc991\ub9b7\ubb36"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a8\ubb5b\ue797\u5da1")));
        o.w(863517525, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a8\ubb5b\ue7f4"), 6, 316, nJPf$sILv.G("\ube77\ub54b\u6f57\uc991\ub9b7\ubb35"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a8\ubb5b\ue797\u5da1")));
        o.w(-97167227, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a8"), 7, 315, nJPf$sILv.G("\ube77\ub54b\u6f57\uc991"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a8\ubb5b\ue797\u5da1")));
        o.w(-1177463950, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a9\ubb5b\ue7f7"), 8, 210, nJPf$sILv.G("\ube77\ub54b\u6f57\uc990\ub9b7\ubb36"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a9\ubb5b\ue797\u5da1")));
        o.w(-254461100, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a9\ubb5b\ue7f4"), 9, 210, nJPf$sILv.G("\ube77\ub54b\u6f57\uc990\ub9b7\ubb35"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a9\ubb5b\ue797\u5da1")));
        o.w(-1096263549, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc991\ub9a9"), 10, 210, nJPf$sILv.G("\ube77\ub54b\u6f57\uc990"), nJPf$sILv.G("\ube30\ub554\u6f39\uc991\ub9a9\ubb5b\ue797\u5da1")));
        o.w(1892176753, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc999\ub9c6\ubb30"), 11, 110, nJPf$sILv.G("\ube77\ub54b\u6f5f\uc98e\ub9ad"), nJPf$sILv.G("\ube30\ub554\u6f39\uc999\ub9c6\ubb56\ue7f7")));
        o.w(380386131, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc999\ub9c6\ubb37"), 12, 110, nJPf$sILv.G("\ube77\ub54b\u6f5f\uc98e\ub9aa"), nJPf$sILv.G("\ube30\ub554\u6f39\uc999\ub9c6\ubb56\ue7f7")));
        o.w(1908359362, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc999\ub9c6\ubb36"), 13, 109, nJPf$sILv.G("\ube77\ub54b\u6f5f\uc98e\ub9ab"), nJPf$sILv.G("\ube30\ub554\u6f39\uc999\ub9c6\ubb56\ue7f4")));
        o.w(-681885503, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc999\ub9c6\ubb35"), 14, 108, nJPf$sILv.G("\ube77\ub54b\u6f5f\uc98e\ub9a8"), nJPf$sILv.G("\ube30\ub554\u6f39\uc999\ub9c6\ubb56\ue7f4")));
        o.w(1167475980, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc999"), 15, 107, nJPf$sILv.G("\ube77\ub54b\u6f5f"), nJPf$sILv.G("\ube30\ub554\u6f39\uc999\ub9c6\ubb56\ue7f4")));
        o.w(568480624, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb3d"), 16, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9a0"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1150304448, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb3c"), 17, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9a1"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1146568895, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb33"), 18, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9ae"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1565016254, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb32"), 19, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9af"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(927088829, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb31"), 20, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9ac"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1306738876, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb30"), 21, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9ad"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1963409595, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb37"), 22, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9aa"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1336818506, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb36"), 23, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9ab"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(837565257, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998\ub9c6\ubb35"), 24, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e\uc98e\ub9a8"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(329073944, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc998"), 25, 47, nJPf$sILv.G("\ube77\ub54b\u6f5e"), nJPf$sILv.G("\ube30\ub554\u6f39\uc998\ub9c6\ubb56\ue7f6")));
        o.w(1817332786, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb35\ue7f5"), 26, 5, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9a8\ubb34")));
        o.w(1070283592, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb3d"), 27, 5, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9a0")));
        o.w(1934637895, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb3c"), 28, 5, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9a1")));
        o.w(1228290886, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb33"), 29, 5, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9ae")));
        o.w(1600469829, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb32"), 30, 5, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9af")));
        o.w(-1150862524, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb31"), 31, 4, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9ac")));
        o.w(-546882749, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb30"), 32, 4, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9ad")));
        o.w(-1755692750, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb37"), 33, 4, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9aa")));
        o.w(-460963535, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb36"), 34, 4, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9ab")));
        o.w(1666794880, (Object)new eHVp(nJPf$sILv.G("\ube14\ub554\u6f39\uc997\ub9c6\ubb35"), 35, 4, nJPf$sILv.G("\ube77\ub54b\u6f51\uc98e\ub9a8")));
        o.w(-1921892048, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc996\ub9c6\ubb30"), 36, 78, nJPf$sILv.G("\ube77\ub54b\u6f50\uc98e\ub9ad"), true));
        o.w(1666400559, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc996\ub9c6\ubb37"), 37, 77, nJPf$sILv.G("\ube77\ub54b\u6f50\uc98e\ub9aa"), true));
        o.w(1334067502, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc996\ub9c6\ubb36"), 38, 74, nJPf$sILv.G("\ube77\ub54b\u6f50\uc98e\ub9ab"), true));
        o.w(-2077671123, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc996\ub9c6\ubb35"), 39, 73, nJPf$sILv.G("\ube77\ub54b\u6f50\uc98e\ub9a8"), true));
        o.w(-1882767060, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc995\ub9c6\ubb36"), 40, 61, nJPf$sILv.G("\ube77\ub54b\u6f53\uc98e\ub9ab"), true));
        o.w(102252843, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc995\ub9c6\ubb35"), 41, 60, nJPf$sILv.G("\ube77\ub54b\u6f53\uc98e\ub9a8"), true));
        o.w(-2145368806, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc995"), 42, 60, nJPf$sILv.G("\ube77\ub54b\u6f53"), true));
        o.w(-657571526, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc994\ub9c6\ubb33"), 43, 51, nJPf$sILv.G("\ube77\ub54b\u6f52\uc98e\ub9ae"), true));
        o.w(-1775091399, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc994\ub9c6\ubb32"), 44, 51, nJPf$sILv.G("\ube77\ub54b\u6f52\uc98e\ub9af"), true));
        o.w(691749176, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc994\ub9c6\ubb31"), 45, 49, nJPf$sILv.G("\ube77\ub54b\u6f52\uc98e\ub9ac"), true));
        o.w(-1452785353, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc994\ub9c6\ubb30"), 46, 49, nJPf$sILv.G("\ube77\ub54b\u6f52\uc98e\ub9ad"), true));
        o.w(1767653686, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc994\ub9c6\ubb36"), 47, 47, nJPf$sILv.G("\ube77\ub54b\u6f52\uc98e\ub9ab"), true));
        o.w(-2138881739, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc993\ub9c6\ubb36"), 48, 39, nJPf$sILv.G("\ube77\ub54b\u6f55\uc98e\ub9ab"), true));
        o.w(-1278721740, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc993\ub9c6\ubb35"), 49, 39, nJPf$sILv.G("\ube77\ub54b\u6f55\uc98e\ub9a8"), true));
        o.w(-19775181, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc992\ub9c6\ubb31"), 50, 29, nJPf$sILv.G("\ube77\ub54b\u6f54\uc98e\ub9ac"), true));
        o.w(-1906753246, (Object)new eHVp(nJPf$sILv.G("\ube04\ub554\u6f39\uc992\ub9c6\ubb30"), 51, 29, nJPf$sILv.G("\ube77\ub54b\u6f54\uc98e\ub9ad"), true));
        o.w(1702118664, (Object)new eHVp(nJPf$sILv.G("\ube03\ub524\u6f34\uc9ec\ub9d0\ubb41\ue796\u5dc4"), 52, 0));
        o.w(179126561, (Object)new eHVp(nJPf$sILv.G("\ube13\ub52b\u6f2d\uc9ee\ub9d6\ubb53\ue78b"), 53, -10000));
        o.w(637747488, new eHVp[]{(eHVp)((Object)o.k(385566194)), (eHVp)((Object)o.k(-1647224698)), (eHVp)((Object)o.k(-1135723689)), (eHVp)((Object)o.k(-1210565802)), (eHVp)((Object)o.k(-543991673)), (eHVp)((Object)o.k(-1641785212)), (eHVp)((Object)o.k(863517525)), (eHVp)((Object)o.k(-97167227)), (eHVp)((Object)o.k(-1177463950)), (eHVp)((Object)o.k(-254461100)), (eHVp)((Object)o.k(-1096263549)), (eHVp)((Object)o.k(1892176753)), (eHVp)((Object)o.k(380386131)), (eHVp)((Object)o.k(1908359362)), (eHVp)((Object)o.k(-681885503)), (eHVp)((Object)o.k(1167475980)), (eHVp)((Object)o.k(568480624)), (eHVp)((Object)o.k(1150304448)), (eHVp)((Object)o.k(1146568895)), (eHVp)((Object)o.k(1565016254)), (eHVp)((Object)o.k(927088829)), (eHVp)((Object)o.k(1306738876)), (eHVp)((Object)o.k(1963409595)), (eHVp)((Object)o.k(1336818506)), (eHVp)((Object)o.k(837565257)), (eHVp)((Object)o.k(329073944)), (eHVp)((Object)o.k(1817332786)), (eHVp)((Object)o.k(1070283592)), (eHVp)((Object)o.k(1934637895)), (eHVp)((Object)o.k(1228290886)), (eHVp)((Object)o.k(1600469829)), (eHVp)((Object)o.k(-1150862524)), (eHVp)((Object)o.k(-546882749)), (eHVp)((Object)o.k(-1755692750)), (eHVp)((Object)o.k(-460963535)), (eHVp)((Object)o.k(1666794880)), (eHVp)((Object)o.k(-1921892048)), (eHVp)((Object)o.k(1666400559)), (eHVp)((Object)o.k(1334067502)), (eHVp)((Object)o.k(-2077671123)), (eHVp)((Object)o.k(-1882767060)), (eHVp)((Object)o.k(102252843)), (eHVp)((Object)o.k(-2145368806)), (eHVp)((Object)o.k(-657571526)), (eHVp)((Object)o.k(-1775091399)), (eHVp)((Object)o.k(691749176)), (eHVp)((Object)o.k(-1452785353)), (eHVp)((Object)o.k(1767653686)), (eHVp)((Object)o.k(-2138881739)), (eHVp)((Object)o.k(-1278721740)), (eHVp)((Object)o.k(-19775181)), (eHVp)((Object)o.k(-1906753246)), (eHVp)((Object)o.k(1702118664)), (eHVp)((Object)o.k(179126561))});
    }

    private eHVp(String string2, int n2, int n3, String string3, boolean bl) {
        this(string, n, (int)string2, (String)n2, mrFx$WjFM.d("\uee1a\u7d83\ucfec\u2b71\uc933\ubcd8\uc967"), (boolean)n3);
    }

    private eHVp(String string2, int n2, int n3) {
        this(string, n, (int)string2, FMkR$WjFM.a("\u678f\u0def\ucab1\ue0d2\u5e43\uea70\u8912"), FMkR$WjFM.a("\u678f\u0def\ucab1\ue0d2\u5e43\uea70\u8912"), false);
    }

    private eHVp(String string2, int n2, int n3, String string3) {
        this(string, n, (int)string2, (String)n2, mrFx$WjFM.d("\uee1a\u7d83\ucfec\u2b71\uc933\ubcd8\uc967"), false);
    }

    private eHVp(String string2, int n2, int n3, String string3, String string4) {
        this(string, n, (int)string2, (String)n2, (String)n3, false);
    }

    private eHVp(String string2, int n2, int n3, String string3, String string4, boolean bl) {
        this.version = string2;
        this.bAYv = (String)n2;
        this.THrU = (String)n3;
        this.mRYw = string3;
        if (string3 != false) {
            var3_4 -= 1000;
        }
    }

    public boolean MvAH() {
        try {
            eHVp.PK(eHVp.PK(eHVp.PK(eHVp.PK(new StringBuilder(nJPf$sILv.G("\u6d25\u853e\u8449\u0b4b\u6378\u2076\u788b\ua444\u410e\u82a7\ue9e3\u465c\ucc75\uae24\u6be1\u8aa3\uefb0\ub3b0\uaec3\uadd9\u88e3")), (String)o.a((Object)this, 822296863)), nJPf$sILv.G("\u6d65\u8519\u8451\u0b0a\u6376\u2074"))));
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    public String MmPC() {
        return (String)o.a((Object)this, 822296863);
    }

    public String toString() {
        return (String)o.a((Object)this, 1807892766);
    }

    public static eHVp pbQb() {
        eHVp[] arreHVp = eHVp.values();
        int n = arreHVp.length;
        int n2 = 0;
        while (n2 < n) {
            eHVp eHVp2 = arreHVp[n2];
            if (eHVp2.yRyF() && eHVp2.kdCy() && eHVp2.MvAH()) {
                return eHVp2;
            }
            ++n2;
        }
        return null;
    }

    public static eHVp DkFY() {
        eHVp[] arreHVp = eHVp.values();
        int n = arreHVp.length;
        int n2 = 0;
        while (n2 < n) {
            eHVp eHVp2 = arreHVp[n2];
            if (eHVp2.kdCy()) {
                return eHVp2;
            }
            ++n2;
        }
        return (eHVp)((Object)o.k(179126561));
    }

    public owvU UtIU(eHVp eHVp2) {
        return new owvU(this, eHVp2);
    }

    public boolean kdCy() {
        return (boolean)eHVp.PK(eHVp.PK(), this.getVersionString());
    }

    public String getVersionString() {
        return this.toString();
    }

    public boolean UJRv() {
        if (((Boolean)o.a((Object)this, 1744978205)).booleanValue()) {
            return false;
        }
        return true;
    }

    public boolean yRyF() {
        return (boolean)eHVp.PK(this.toString(), nJPf$sILv.G("\u4193"));
    }

    public int getVersion() {
        if (this.yRyF() && !this.UJRv()) {
            return this.tDJQ() + 1000;
        }
        return this.tDJQ();
    }

    public int ejbL() {
        if (this.yRyF() && !this.UJRv()) {
            return this.tDJQ();
        }
        return this.tDJQ() + 1000;
    }

    public int tDJQ() {
        return (Integer)o.a((Object)this, -1467596516);
    }

    public static eHVp[] values() {
        eHVp[] arreHVp = (eHVp[])o.k(637747488);
        int n = arreHVp.length;
        eHVp[] arreHVp2 = new eHVp[n];
        eHVp.PK(arreHVp, false, arreHVp2, false, n);
        return arreHVp2;
    }

    public static eHVp valueOf(String string) {
        return (eHVp)((Object)eHVp.PK(eHVp.class, string));
    }

    private static Object PK(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

