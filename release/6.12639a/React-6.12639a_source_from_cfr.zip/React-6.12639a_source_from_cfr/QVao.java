/*
 * Decompiled with CFR 0_123.
 */
public interface QVao<FROM, TO> {
    public TO KTiK(FROM var1);

    public TO GPlk(FROM var1);
}

