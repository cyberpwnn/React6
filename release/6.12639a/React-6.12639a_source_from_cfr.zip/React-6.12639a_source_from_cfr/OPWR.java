/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 */
import org.bukkit.entity.EntityType;

public class OPWR {
    private Lhwj<EntityType> ryTY = new Lhwj();

    public Lhwj<EntityType> MSAa() {
        return (Lhwj)o.a(this, -1293662805);
    }
}

