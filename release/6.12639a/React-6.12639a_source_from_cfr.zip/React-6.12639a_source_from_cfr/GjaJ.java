/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import org.bukkit.command.CommandSender;

public interface GjaJ {
    public yuDM NwfF();

    public Class<?> getType();

    public boolean TEqA(Object var1);

    public Lhwj<Object> GjaJ();

    public Lhwj<Object> IFSe();

    public int KTiK(CommandSender var1, String var2) throws JYyP;

    public String getName();
}

