/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import org.bukkit.command.CommandSender;

public final class aeiw
extends Enum<aeiw> {
    public static final /* enum */ aeiw QFSb;
    public static final /* enum */ aeiw JcbI;
    public static final /* enum */ aeiw eQNN;
    public static final /* enum */ aeiw cKHH;
    public static final /* enum */ aeiw teii;
    public static final /* enum */ aeiw rxul;
    public static final /* enum */ aeiw Svlw;
    public static final /* enum */ aeiw pQNK;
    public static final /* enum */ aeiw loTp;
    public static final /* enum */ aeiw rVrU;
    public static final /* enum */ aeiw SfLm;
    public static final /* enum */ aeiw IyqQ;
    public static final /* enum */ aeiw QqGy;
    public static final /* enum */ aeiw lnrv;
    private String imyy;
    private static final /* synthetic */ aeiw[] Xljg;

    static {
        o.w(673269243, (Object)new aeiw(FMkR$WjFM.a("\uc0bb\u89d2\u77a6\ua336\ua732\u9ad7"), 0, (String)o.k(1523795452)));
        o.w(733824393, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c"), 1, (String)o.k(1420117386)));
        o.w(-1903409785, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e2c\uac77\u6bcc\u791f\u0a5c"), 2, (String)o.k(-1180351096)));
        o.w(1848722822, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e39\uac7d\u6bcc\u791a\u0a56\ua22e\ue7d3\u5dc9\uc8ec"), 3, (String)o.k(-1180351096)));
        o.w(-1249688188, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e35\uac7f\u6bc8"), 4, (String)o.k(-1541782139)));
        o.w(-54573966, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e3d\uac70\u6bce\u791a\u0a4b\ua22f\ue7d1\u5dcb\uc8ee\u1b8a\ud4a9"), 5, (String)o.k(2146977155)));
        o.w(-1427291024, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e3f\uac72\u6bd9\u7900\u0a4a\ua225\ue7cc"), 6, (String)o.k(231097457)));
        o.w(-1343273874, (Object)new aeiw(FMkR$WjFM.a("\uc0b7\u89de\u77ab\ua33a\ua735\u9acb\ude6c\u92dc\u6e3b\uac76\u6bcd\u791d\u0a52\ua23f\ue7dd\u5dca\uc8ea\u1b89\ud4b8"), 7, (String)o.k(-171031441)));
        o.w(-1481227156, (Object)new aeiw(FMkR$WjFM.a("\uc0a8\u89d0\u77ac\ua32c\ua72c\u9acb\ude70\u92ca\u6e2c\uac71\u6bca"), 8, (String)o.k(-1493220243)));
        o.w(392447098, (Object)new aeiw(FMkR$WjFM.a("\uc0a8\u89d0\u77ac\ua32c\ua722\u9acb\ude70\u92d7\u6e2a\uac71\u6bd4"), 9, (String)o.k(65356907)));
        o.w(-928627592, (Object)new aeiw(FMkR$WjFM.a("\uc0a8\u89d0\u77ac\ua32c\ua720\u9ac7\ude7d\u92c6\u6e2b\uac6d"), 10, (String)o.k(-588102535)));
        o.w(1983792246, (Object)new aeiw(FMkR$WjFM.a("\uc0a8\u89d0\u77ac"), 11, (String)o.k(165823607)));
        o.w(-54639500, (Object)new aeiw(FMkR$WjFM.a("\uc0bb\u89d2\u77b1"), 12, (String)o.k(1929593973)));
        o.w(-2033957790, (Object)new aeiw(FMkR$WjFM.a("\uc0a8\u89d4\u77a9\ua33c\ua720\u9ac0"), 13, (String)o.k(1589527667)));
        o.w(-1008843679, new aeiw[]{(aeiw)((Object)o.k(673269243)), (aeiw)((Object)o.k(733824393)), (aeiw)((Object)o.k(-1903409785)), (aeiw)((Object)o.k(1848722822)), (aeiw)((Object)o.k(-1249688188)), (aeiw)((Object)o.k(-54573966)), (aeiw)((Object)o.k(-1427291024)), (aeiw)((Object)o.k(-1343273874)), (aeiw)((Object)o.k(-1481227156)), (aeiw)((Object)o.k(392447098)), (aeiw)((Object)o.k(-928627592)), (aeiw)((Object)o.k(1983792246)), (aeiw)((Object)o.k(-54639500)), (aeiw)((Object)o.k(-2033957790))});
    }

    private aeiw(String string2, int n2, String string3) {
        try {
            this.imyy = aeiw.HR(aeiw.HR(new StringBuilder((String)aeiw.HR((String)o.k(-1456323488))), string2));
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public boolean yJLS(CommandSender commandSender) {
        return commandSender.hasPermission(this.aeiw());
    }

    public String aeiw() {
        return (String)o.a((Object)this, -1222556577);
    }

    public static aeiw[] values() {
        aeiw[] arraeiw = (aeiw[])o.k(-1008843679);
        int n = arraeiw.length;
        aeiw[] arraeiw2 = new aeiw[n];
        aeiw.HR(arraeiw, false, arraeiw2, false, n);
        return arraeiw2;
    }

    public static aeiw valueOf(String string) {
        return (aeiw)((Object)aeiw.HR(aeiw.class, string));
    }

    private static Object HR(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

