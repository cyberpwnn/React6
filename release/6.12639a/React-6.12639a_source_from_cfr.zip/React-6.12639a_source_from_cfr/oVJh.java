/*
 * Decompiled with CFR 0_123.
 */
public interface oVJh {
    public void yJLS(BuLd var1, mrHN var2, mrHN var3);

    public void yJLS(BuLd var1);

    public void UtIU(BuLd var1);

    public void biLo(BuLd var1);

    public void yJLS(BuLd var1, long var2, long var4, double var6);
}

