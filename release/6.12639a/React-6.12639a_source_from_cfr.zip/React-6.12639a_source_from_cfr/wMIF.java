/*
 * Decompiled with CFR 0_123.
 */
public interface wMIF {
    public void cancel();
}

