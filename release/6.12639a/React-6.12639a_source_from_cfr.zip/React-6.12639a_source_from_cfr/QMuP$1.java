/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

class QMuP$1
extends xGOy {
    final /* synthetic */ QMuP CNfO;

    QMuP$1(QMuP qMuP) {
        this.CNfO = qMuP;
    }

    @Override
    public void run() {
        if (((Boolean)o.a((QMuP)o.a(this, -316385317), -1400809494)).booleanValue()) {
            String[] arrstring = new String[2];
            arrstring[0] = QMuP$1.xx(mrFx$WjFM.d("\u2341\u537f\u316d\u92a3\u9cf7\uf0f3\ue47c\uf31c\ucd9d\u0779\u6d37\uebf6\ucb94\u1d31\uc008\u2857\u9569\u8d8f\u6a08\ua74e\u35c5\u68f2\u8897\u065a\u3d4a\ua42a\u56b4\u9634\udef2\u82c7\ud0bf"));
            arrstring[1] = QMuP$1.xx(mrFx$WjFM.d("\u2341\u537f\u316d\u92a3\u9cf7\uf0f3\ue47c\uf31c\ucd9d\u0779\u6d37\uebf6\ucb94\u1d31\uc008\u2857\u9569\u8d8f\u6a08\ua74e\u35c5\u68f2\u8897\u065a\u3d4a\ua42a\u56b4\u963c\udeff\u82d7\ud0a1\u5cbf\u10dd\udd01\uef33\ubbe8\ue77a"));
            QMuP$1.xx((uqOm)o.k(-609594549), new hHgD((vsrN)((Object)o.k(871061494)), arrstring));
            return;
        }
        String[] arrstring = new String[2];
        arrstring[0] = QMuP$1.xx(mrFx$WjFM.d("\u2341\u537f\u316d\u92a3\u9cf7\uf0f3\ue47c\uf31c\ucd9d\u0779\u6d37\uebf6\ucb94\u1d31\uc008\u2857\u9569\u8d8f\u6a08\ua74e\u35c5\u68f2\u8897\u065a\u3d4a\ua42a\u56b4\u9634\udef2\u82c7\ud0bf\u5cbd\u109e\udd12"));
        arrstring[1] = QMuP$1.xx(mrFx$WjFM.d("\u2341\u537f\u316d\u92a3\u9cf7\uf0f3\ue47c\uf31c\ucd9d\u0779\u6d37\uebf6\ucb94\u1d31\uc008\u2857\u9569\u8d8f\u6a08\ua74e\u35c5\u68f2\u8897\u065a\u3d4a\ua42a\u56b4\u963c\udeff\u82d7\ud0a1\u5cbf\u10dd\udd01\uef33\ubbe8\ue77a"));
        QMuP$1.xx((uqOm)o.k(-609594549), new hHgD((vsrN)((Object)o.k(1411405812)), arrstring));
    }

    private static Object xx(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

