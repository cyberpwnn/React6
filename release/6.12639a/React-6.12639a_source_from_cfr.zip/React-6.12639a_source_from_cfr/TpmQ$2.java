/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.block.Block
 */
import org.bukkit.block.Block;

class TpmQ$2
extends xGOy {
    final /* synthetic */ TpmQ htUH;
    private final /* synthetic */ Block LQBM;

    TpmQ$2(TpmQ tpmQ, Block block) {
        this.htUH = tpmQ;
        this.LQBM = block;
    }

    @Override
    public void run() {
        ((Block)o.a(this, 1892505882)).breakNaturally();
    }
}

