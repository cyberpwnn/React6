/*
 * Decompiled with CFR 0_123.
 */
public class MAmw
extends jOQr<Double> {
    protected MAmw(Double d) {
        super((WaLc)((Object)o.k(-1049080659)), d);
    }
}

