/*
 * Decompiled with CFR 0_123.
 */
public abstract class Fpab$TEqA {
    public abstract float bijP();

    public abstract float paqR();

    public abstract float xiiW();
}

