/*
 * Decompiled with CFR 0_123.
 */
public interface NVRU<T> {
    public WaLc wMJq();

    public void set(T var1);

    public T get();
}

