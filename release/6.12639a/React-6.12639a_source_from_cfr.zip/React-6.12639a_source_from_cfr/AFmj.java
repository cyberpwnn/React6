/*
 * Decompiled with CFR 0_123.
 */
public class AFmj
extends baAO {
    private static final long serialVersionUID = -6778105688310325503L;

    public AFmj(String string) {
        super(string);
    }
}

