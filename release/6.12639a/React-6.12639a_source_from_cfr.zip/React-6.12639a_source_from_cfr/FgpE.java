/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class FgpE {
    private static boolean cCVb;
    protected static int version;
    public static Class<?> mYeI;
    public static Class<?> MBva;
    public static Class<?> OtQo;
    public static Class<?> PDPe;
    public static Class<?> UKPO;
    protected static Class<?> inyw;
    public static Class<?> mPrp;
    public static Class<?> DbqF;
    public static Class<?> DcRI;
    public static Class<?> Hwmx;

    static {
        o.w(-782543015, false);
        o.w(2013747032, 170);
        if (!((Boolean)o.k(-782543015)).booleanValue()) {
            if (FgpE.mh(FgpE.mh(), nJPf$sILv.G("\ud90e\udb90\ufeed")) != false) {
                o.w(2013747032, 170);
            }
            if (FgpE.mh(FgpE.mh(), nJPf$sILv.G("\ud90e\udb90\ufee2")) != false) {
                o.w(2013747032, 180);
            }
            if (FgpE.mh(FgpE.mh(), nJPf$sILv.G("\ud90e\udb90\ufee2\ube50\u2782\u4a47")) != false) {
                o.w(2013747032, 181);
            }
            if (FgpE.mh(FgpE.mh(), nJPf$sILv.G("\ud90e\udb90\ufee2\ube50\u2782\u4a44")) != false) {
                o.w(2013747032, 182);
            }
            if (FgpE.mh(FgpE.mh(), nJPf$sILv.G("\ud90e\udb90\ufee2\ube50\u2782\u4a45")) != false) {
                o.w(2013747032, 183);
            }
            if ((Integer)o.k(2013747032) >= 180) {
                o.w(639522645, FgpE.mh(nJPf$sILv.G("\ud96f\udbae\ufeb9\ube64\u27b5\u4a02\uc3f6\ua881\u0c07\ud3fa\ue3f8\u5f0f\ue9eb\u9721\u744a\ufc05\uef2e\ufd1e\u563d\u1a74\u42fa\u7fb3\u291b\u838d\u24de\u5319\ub5d4\ua114\ue2ea\ue8b1\ub6af\u4248\u34a1\u6905\u4d66")));
            }
            o.w(-1035774125, FgpE.mh(nJPf$sILv.G("\ud976\udb8c\ufeb2\ube6e\u27a4\u4a34\uc3c7\ua89e\u0c03\ud3c0\ue3d8\u5f17\ue9ef\u971e\u7448\ufc01\uef39\ufd0f")));
            if ((Integer)o.k(2013747032) < 181) {
                o.w(-1850127166, FgpE.mh(nJPf$sILv.G("\ud97c\udba7\ufebb\ube7b\u2783\u4a13\uc3d4\ua884\u0c07\ud3ef\ue3de\u5f00\ue9fa\u9703")));
            } else {
                o.w(-1850127166, FgpE.mh(nJPf$sILv.G("\ud976\udb8c\ufeb2\ube6e\u27a4\u4a34\uc3c7\ua89e\u0c03\ud3c0\ue3d8\u5f17\ue9ef\u971e\u7448\ufc01\uef39\ufd0f\u566b\u1a7b\u42fb\u7fa1\u291b\u8396\u24de\u530a\ub5d9\ua110\ue2f4\ue89e\ub6ba\u4242\u34a7")));
            }
            o.w(-1534047039, FgpE.mh(nJPf$sILv.G("\ud96f\udbae\ufeb9\ube64\u27b5\u4a02\uc3f6\ua881\u0c07\ud3fa\ue3f8\u5f0f\ue9eb\u9721\u744a\ufc05\uef2e\ufd1e\u563d\u1a71\u42fd\u7fa6\u2900")));
            if ((Integer)o.k(2013747032) >= 180) {
                o.w(-1627960128, FgpE.mh(nJPf$sILv.G("\ud96f\udbae\ufeb9\ube64\u27b5\u4a02\uc3f6\ua881\u0c07\ud3fa\ue3f8\u5f0f\ue9eb\u9721\u744a\ufc05\uef2e\ufd1e\u563d\u1a71\u42fd\u7fa6\u2900\u83e1\u24eb\u5314\ub5d1\ua108\ue2fd\ue885\ub689\u4249\u34b3\u690f\u4d50\u8326\uaf60\ufe64")));
            }
            if ((Integer)o.k(2013747032) <= 181) {
                o.w(1019694271, FgpE.mh(nJPf$sILv.G("\ud97a\udba1\ufeaf\ube62\u2780\u4a1a\uc3c7\ua894\u0c03\ud3f1\ue3fe\u5f14\ue9f9\u971e\u7467\ufc07\uef23\ufd12\u5620\u1a56")));
            } else {
                o.w(1019694271, FgpE.mh(nJPf$sILv.G("\ud96f\udbae\ufeb9\ube64\u27b5\u4a02\uc3f6\ua881\u0c07\ud3fa\ue3f8\u5f0f\ue9eb\u9721\u744a\ufc05\uef2e\ufd1e\u563d\u1a71\u42fd\u7fa6\u2900\u83e1\u24fe\u5316\ub5c5\ua11c\ue2c8\ue89b\ub6a1\u425e\u34b0\u6912\u4d5d\u8329\uaf72\ufe6a\ua257\u1e2c\u1fdc\uc1d8\uff91\u2e18")));
            }
            try {
                if ((Integer)o.k(2013747032) < 180) {
                    o.w(-1902687042, FgpE.mh(nJPf$sILv.G("\ud951\udbaa\ufeae\ube21\u27bd\u4a1f\uc3c8\ua888\u0c05\ud3f1\ue3d6\u5f1c\ue9eb\u975f\u7453\ufc10\uef3e\ufd17\u5661\u1a5b\u42fc\u7fad\u2941\u83a8\u24d4\u5312\ub5d1\ua11f\ue2ff\ue8d9\ub6a1\u4252\u34a1\u6908\u4d78\u832e\uaf76\ufe2b\ua251\u1e2e\u1fc5\uc1d4\uffae\u2e04\u134c\uc704\ua5fe\u0568\u08d8")));
                } else {
                    o.w(-1902687042, FgpE.mh(nJPf$sILv.G("\ud95c\udba0\ufeb7\ube21\u27bd\u4a19\uc3cc\ua88c\u0c08\ud3e4\ue399\u5f1b\ue9ea\u9705\u744e\ufc08\uef3e\ufd19\u5661\u1a7f\u42f2\u7fad\u290a\u8395\u24c9\u5317\ub5d6\ua118\ue2f4\ue892")));
                }
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
            if ((Integer)o.k(2013747032) < 182) {
                o.w(-1439281987, FgpE.mh(nJPf$sILv.G("\ud97a\udba1\ufeaf\ube62\u2797\u4a17\uc3cb\ua888\u0c0b\ud3ec\ue3d3\u5f1f")));
            } else {
                o.w(-1439281987, FgpE.mh(nJPf$sILv.G("\ud968\udba0\ufea8\ube63\u27b4\u4a25\uc3c3\ua899\u0c12\ud3ea\ue3d9\u5f1d\ue9ec\u9755\u7463\ufc0a\uef22\ufd16\u5608\u1a59\u42fe\u7fa5\u2902\u83aa\u24df\u531d")));
            }
            o.w(-1635693380, FgpE.mh(nJPf$sILv.G("\ud96b\udba6\ufeb6\ube6a\u2795\u4a18\uc3d2\ua884\u0c12\ud3fa\ue3e4\u5f11\ue9ea\u971d\u744a")));
            try {
                if ((Integer)o.k(2013747032) < 180) {
                    o.w(1394035899, FgpE.mh(nJPf$sILv.G("\ud951\udbaa\ufeae\ube21\u27bd\u4a1f\uc3c8\ua888\u0c05\ud3f1\ue3d6\u5f1c\ue9eb\u975f\u7453\ufc10\uef3e\ufd17\u5661\u1a5b\u42fc\u7fad\u2941\u83a2\u24d4\u5317\ub5d7\ua11d\ue2fd\ue8d9\ub6a3\u4248\u34b8\u690d\u4d7b\u8329\uaf3a\ufe66\ua277\u1e2c\u1fc0\uc1d4\uffd0\u2e3a\u134c\uc703\ua5f3\u056d\u08d3\u34f8\u6298\u6b78\u8d1f\ud18b\u17ab")));
                } else {
                    o.w(1394035899, FgpE.mh(nJPf$sILv.G("\ud95c\udba0\ufeb7\ube21\u27b7\u4a19\uc3c9\ua88a\u0c0a\ud3e6\ue399\u5f19\ue9f0\u971c\u744b\ufc0b\uef39\ufd55\u562c\u1a59\u42f0\u7fa8\u290a\u83eb\u24f7\u5317\ub5d1\ua115\ue2f1\ue899\ub6a7\u4264\u34b4\u6903\u4d7c\u8322")));
                }
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
            o.w(-782543015, true);
        }
    }

    private static Object mh(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(o.Y(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

