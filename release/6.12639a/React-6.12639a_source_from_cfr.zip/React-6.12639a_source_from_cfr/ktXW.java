/*
 * Decompiled with CFR 0_123.
 */
public class ktXW
extends jOQr<Boolean> {
    protected ktXW(Boolean bl) {
        super((WaLc)((Object)o.k(465915054)), bl);
    }
}

