/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public interface equl<T extends IgvC<?>> {
    public int getSize();

    public T yJLS(long var1);

    public long jxuv();

    public void yJLS(T var1);

    public long jNbl();

    public int yJLS(long var1, long var3);

    public TNku<Long, T> UtIU(long var1, long var3);

    public int UtIU(long var1);

    public void save();

    public File getFile();
}

