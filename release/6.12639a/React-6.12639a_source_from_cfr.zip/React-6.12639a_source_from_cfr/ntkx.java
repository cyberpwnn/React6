/*
 * Decompiled with CFR 0_123.
 */
public interface ntkx {
    public String uVol(double var1);
}

