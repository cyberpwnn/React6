/*
 * Decompiled with CFR 0_123.
 */
public interface vHyF {
    public eHVp uFVW();

    public String dDeO();

    public String pGhD();

    public int iBsQ();
}

