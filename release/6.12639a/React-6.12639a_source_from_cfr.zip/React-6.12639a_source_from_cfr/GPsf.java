/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Chunk
 */
import org.bukkit.Chunk;

public class GPsf
extends MSAa<Chunk, bWps> {
}

