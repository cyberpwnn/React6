/*
 * Decompiled with CFR 0_123.
 */
public class kYwm
extends cRaV {
    private static final long serialVersionUID = 7755514107832808772L;

    public kYwm(String string) {
        super(string);
    }
}

