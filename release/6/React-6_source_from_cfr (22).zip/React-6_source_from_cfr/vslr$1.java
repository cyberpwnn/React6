/*
 * Decompiled with CFR 0_123.
 */
class vslr$1 {
}

