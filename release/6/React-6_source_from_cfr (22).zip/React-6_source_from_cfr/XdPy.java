/*
 * Decompiled with CFR 0_123.
 */
public interface XdPy {
    public void refresh();
}

