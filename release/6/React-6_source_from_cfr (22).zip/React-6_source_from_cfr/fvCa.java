/*
 * Decompiled with CFR 0_123.
 */
public class fvCa
extends vbnM<Integer> {
    protected fvCa(Integer n) {
        super((GHiL)((Object)cv.e(2053829153)), n);
    }
}

