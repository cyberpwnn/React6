/*
 * Decompiled with CFR 0_123.
 */
public interface BSOO<T> {
    public wfPa<T> RkTm();

    public void add(T var1);
}

