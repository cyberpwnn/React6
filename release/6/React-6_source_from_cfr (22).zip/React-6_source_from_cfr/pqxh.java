/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class pqxh
extends Enum<pqxh> {
    public static final /* enum */ pqxh cuSa;
    public static final /* enum */ pqxh WqqP;
    public static final /* enum */ pqxh gFKj;
    public static final /* enum */ pqxh ktYs;
    public static final /* enum */ pqxh qJwE;
    public static final /* enum */ pqxh rWKg;
    public static final /* enum */ pqxh SKrK;
    public static final /* enum */ pqxh dVTX;
    public static final /* enum */ pqxh BAnt;
    public static final /* enum */ pqxh qKWl;
    public static final /* enum */ pqxh DajI;
    public static final /* enum */ pqxh ePfK;
    public static final /* enum */ pqxh OiyY;
    public static final /* enum */ pqxh Rsag;
    public static final /* enum */ pqxh Hecg;
    public static final /* enum */ pqxh lDXV;
    public static final /* enum */ pqxh FFKt;
    public static final /* enum */ pqxh ObHd;
    public static final /* enum */ pqxh RsbV;
    public static final /* enum */ pqxh hHko;
    public static final /* enum */ pqxh JRXe;
    public static final /* enum */ pqxh kcXK;
    private String rgig;
    private static final /* synthetic */ pqxh[] Eult;

    public static pqxh[] values() {
        return (pqxh[])((pqxh[])cv.e(-1637019652)).clone();
    }

    public static pqxh valueOf(String string) {
        return (pqxh)((Object)pqxh.cG(pqxh.class, string));
    }

    private pqxh(String string2) {
        try {
            this.rgig = string2;
            return;
        }
        catch (Exception exception) {
            return;
        }
    }

    public String VCgr() {
        return (String)cv.b((Object)this, -1870852097);
    }

    static {
        cv.V(580128761, (Object)new pqxh((String)cv.e(-117698562)));
        cv.V(-1152642885, (Object)new pqxh((String)cv.e(1911689400)));
        cv.V(2017333413, (Object)new pqxh((String)cv.e(1266225338)));
        cv.V(71700647, (Object)new pqxh((String)cv.e(-1497296732)));
        cv.V(-493612890, (Object)new pqxh((String)cv.e(-117698562)));
        cv.V(701960353, (Object)new pqxh((String)cv.e(1911689400)));
        cv.V(316412064, (Object)new pqxh((String)cv.e(1266225338)));
        cv.V(951914659, (Object)new pqxh((String)cv.e(-1497296732)));
        cv.V(-310243155, (Object)new pqxh((String)cv.e(1948324002)));
        cv.V(1212616879, (Object)new pqxh((String)cv.e(1520308396)));
        cv.V(987041961, (Object)new pqxh((String)cv.e(-440987474)));
        cv.V(-1615195989, (Object)new pqxh((String)cv.e(-451669848)));
        cv.V(1997934741, (Object)new pqxh((String)cv.e(-719843158)));
        cv.V(1773277335, (Object)new pqxh((String)cv.e(661590164)));
        cv.V(2031095953, (Object)new pqxh((String)cv.e(1592791190)));
        cv.V(1040388243, (Object)new pqxh((String)cv.e(-1551363952)));
        cv.V(-893710179, (Object)new pqxh((String)cv.e(-2001334126)));
        cv.V(-405860193, (Object)new pqxh((String)cv.e(-214101860)));
        cv.V(-412938087, (Object)new pqxh((String)cv.e(1872171166)));
        cv.V(1928990939, (Object)new pqxh((String)cv.e(793186520)));
        cv.V(-2043277115, (Object)new pqxh((String)cv.e(1285296346)));
        cv.V(-1238232889, (Object)new pqxh((String)cv.e(1670910148)));
        cv.V(-1637019652, new pqxh[]{(pqxh)((Object)cv.e(580128761)), (pqxh)((Object)cv.e(-1152642885)), (pqxh)((Object)cv.e(2017333413)), (pqxh)((Object)cv.e(71700647)), (pqxh)((Object)cv.e(-493612890)), (pqxh)((Object)cv.e(701960353)), (pqxh)((Object)cv.e(316412064)), (pqxh)((Object)cv.e(951914659)), (pqxh)((Object)cv.e(-310243155)), (pqxh)((Object)cv.e(1212616879)), (pqxh)((Object)cv.e(987041961)), (pqxh)((Object)cv.e(-1615195989)), (pqxh)((Object)cv.e(1997934741)), (pqxh)((Object)cv.e(1773277335)), (pqxh)((Object)cv.e(2031095953)), (pqxh)((Object)cv.e(1040388243)), (pqxh)((Object)cv.e(-893710179)), (pqxh)((Object)cv.e(-405860193)), (pqxh)((Object)cv.e(-412938087)), (pqxh)((Object)cv.e(1928990939)), (pqxh)((Object)cv.e(-2043277115)), (pqxh)((Object)cv.e(-1238232889))});
    }

    private static Object cG(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

