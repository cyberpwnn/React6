/*
 * Decompiled with CFR 0_123.
 */
public class YUkF
extends vbnM<Double> {
    protected YUkF(Double d) {
        super((GHiL)((Object)cv.e(23917094)), d);
    }
}

