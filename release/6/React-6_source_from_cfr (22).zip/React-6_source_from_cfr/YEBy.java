/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Chunk
 */
import org.bukkit.Chunk;

public class YEBy
extends LGKN<Chunk, HuvK> {
}

