/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 */
import org.bukkit.Material;

public final class JbuU$DYFV
extends JbuU$BkpW {
    public JbuU$DYFV(Material material, byte by) {
        super(material, by);
    }
}

