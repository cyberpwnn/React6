/*
 * Decompiled with CFR 0_123.
 */
public interface kkap {
    public int getId();

    public void run();

    public boolean lnfu();

    public String getName();

    public double vJAb();

    public double GHjQ();

    public double maJO();

    public boolean pbBn();
}

