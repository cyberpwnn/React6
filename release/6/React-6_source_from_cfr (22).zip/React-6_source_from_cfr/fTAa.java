/*
 * Decompiled with CFR 0_123.
 */
public interface fTAa {
    public wfPa<fTAa> JbqW();

    public void YUkF();

    public void VCsR();

    public String getTag();

    public wfPa<fTAa> fvCa();

    public boolean Rayq();

    public boolean esCa();

    public void update();

    public void ssNb(fTAa var1);
}

