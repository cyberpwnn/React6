/*
 * Decompiled with CFR 0_123.
 */
import java.io.Serializable;

public class aUPw<A, B>
implements Serializable {
    private static final long serialVersionUID = 1;
    private A HemE;
    private B cAun;

    public aUPw(A a, B b) {
        this.HemE = a;
        this.cAun = b;
    }

    public A GkIA() {
        return (A)cv.b(this, -1676216275);
    }

    public void lCdp(A a) {
        cv.e(this, -1676216275, a);
    }

    public B YDfo() {
        return (B)cv.b(this, 118421548);
    }

    public void nJLQ(B b) {
        cv.e(this, 118421548, b);
    }
}

