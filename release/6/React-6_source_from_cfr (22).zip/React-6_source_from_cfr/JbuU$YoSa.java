/*
 * Decompiled with CFR 0_123.
 */
public abstract class JbuU$YoSa {
    public abstract float uOTo();

    public abstract float ogUp();

    public abstract float jGEc();
}

