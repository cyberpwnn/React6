/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public interface GsQl<T extends NxGC<?>> {
    public int getSize();

    public T ssNb(long var1);

    public long oVCY();

    public void ssNb(T var1);

    public long nImU();

    public int ssNb(long var1, long var3);

    public ktOu<Long, T> DYFV(long var1, long var3);

    public int DYFV(long var1);

    public void save();

    public File getFile();
}

