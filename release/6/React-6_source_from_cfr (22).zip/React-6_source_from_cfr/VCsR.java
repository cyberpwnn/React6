/*
 * Decompiled with CFR 0_123.
 */
import java.util.List;

public class VCsR
extends vbnM<List<String>> {
    protected VCsR(List<String> list) {
        super((GHiL)((Object)cv.e(1236529698)), list);
    }
}

