/*
 * Decompiled with CFR 0_123.
 */
public class GHjQ {
    private final int width;
    private final int height;
    private final int depth;

    public GHjQ(int n, int n2, int n3) {
        this.width = n;
        this.height = n2;
        this.depth = n3;
    }

    public GHjQ(int n, int n2) {
        this.width = n;
        this.height = n2;
        this.depth = 0;
    }

    public maJO OGxH() {
        if ((Integer)cv.b(this, 1358755476) == 1) {
            return (maJO)((Object)cv.e(-495126889));
        }
        if ((Integer)cv.b(this, 22476438) == 1) {
            return (maJO)((Object)cv.e(-1337395567));
        }
        if ((Integer)cv.b(this, -75696496) == 1) {
            return (maJO)((Object)cv.e(-2022902125));
        }
        return null;
    }

    public int getWidth() {
        return (Integer)cv.b(this, 1358755476);
    }

    public int getHeight() {
        return (Integer)cv.b(this, 22476438);
    }

    public int getDepth() {
        return (Integer)cv.b(this, -75696496);
    }
}

