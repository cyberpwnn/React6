/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public interface byyi {
    public QFEs IWSm(File var1);
}

