/*
 * Decompiled with CFR 0_123.
 */
public interface CoXE {
    public String getName();

    public String getDescription();

    public rwyd BkpW();

    public /* varargs */ void DYFV(ftyu var1, EmKi ... var2) throws LGKl;

    public /* varargs */ void ssNb(ftyu var1, EmKi ... var2);

    public kQcX lCdp();

    public rMgK nJLQ();

    public /* varargs */ void ssNb(String ... var1);

    public String[] LGKl();

    public String getStatus();

    public void ssNb(String var1);

    public double getProgress();

    public void setProgress(double var1);

    public cIji vtFs();

    public ktOu<Class<?>, xqeH<EmKi>> EmLA();

    public void ssNb(Class<?> var1, xqeH<EmKi> var2);

    public /* varargs */ EmKi[] ssNb(EmKi ... var1);

    public ftyu TyVf();

    public void WGJn();
}

