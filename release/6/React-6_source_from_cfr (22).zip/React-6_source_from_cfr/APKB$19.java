/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 */
import net.md_5.bungee.api.ChatColor;

class APKB$19
extends APKB {
    APKB$19(String string2, int n2, char c, int n3) {
    }

    @Override
    public ChatColor asBungee() {
        return (ChatColor)cv.e(-638651324);
    }
}

