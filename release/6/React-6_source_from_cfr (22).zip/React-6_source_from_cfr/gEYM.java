/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class gEYM
implements ftyu {
    @Override
    public void DYFV(String string) {
        gEYM.Io(gEYM.Io(gEYM.Io(new StringBuilder(YEBy$TyVf.W("\uaef5\u104f\u5fdc\ud79d\u2114\u777f\ua84a")), string)));
    }

    @Override
    public void IWSm(String string) {
        gEYM.Io(gEYM.Io(gEYM.Io(new StringBuilder(rgig$AWxc.r("\u7e3f\u6298\u1859\u90de\u1e43\u5912\ud341")), string)));
    }

    @Override
    public void OXeK(String string) {
        gEYM.Io(gEYM.Io(gEYM.Io(new StringBuilder(rgig$AWxc.r("\u3e1e\u585c\u5327\u552a\u65e6\u3ed9\u9863")), string)));
    }

    @Override
    public void YoSa(String string) {
        gEYM.Io(gEYM.Io(gEYM.Io(new StringBuilder(KUXS$dwji.S("\u9ebb\u5139\ud17a\u919c\u6c5a\u597f\u2502")), string)));
    }

    private static Object Io(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

