/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Material
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import org.bukkit.Material;

public final class kcUD
extends Enum<kcUD> {
    public static final /* enum */ kcUD uGWL;
    public static final /* enum */ kcUD ChLY;
    public static final /* enum */ kcUD bjTh;
    public static final /* enum */ kcUD NFIB;
    public static final /* enum */ kcUD rXAH;
    public static final /* enum */ kcUD MTFw;
    public static final /* enum */ kcUD lVOT;
    public static final /* enum */ kcUD RRVx;
    public static final /* enum */ kcUD cmYx;
    public static final /* enum */ kcUD OcAO;
    public static final /* enum */ kcUD WsHl;
    public static final /* enum */ kcUD tMIO;
    public static final /* enum */ kcUD CWLm;
    public static final /* enum */ kcUD vSNm;
    public static final /* enum */ kcUD IPMo;
    public static final /* enum */ kcUD hRVg;
    public static final /* enum */ kcUD CWLj;
    public static final /* enum */ kcUD bHSp;
    public static final /* enum */ kcUD qvbw;
    public static final /* enum */ kcUD uaLf;
    public static final /* enum */ kcUD dgmH;
    public static final /* enum */ kcUD AsJF;
    public static final /* enum */ kcUD JAnj;
    public static final /* enum */ kcUD cKXL;
    public static final /* enum */ kcUD EUCe;
    public static final /* enum */ kcUD mYUP;
    public static final /* enum */ kcUD PfDa;
    public static final /* enum */ kcUD wfrC;
    public static final /* enum */ kcUD FXFm;
    public static final /* enum */ kcUD vBLm;
    public static final /* enum */ kcUD FXGQ;
    public static final /* enum */ kcUD VpFa;
    public static final /* enum */ kcUD tTxC;
    public static final /* enum */ kcUD dxnK;
    public static final /* enum */ kcUD febT;
    public static final /* enum */ kcUD YglH;
    public static final /* enum */ kcUD kBMH;
    public static final /* enum */ kcUD hJDu;
    public static final /* enum */ kcUD BSip;
    public static final /* enum */ kcUD tUXU;
    public static final /* enum */ kcUD xadO;
    public static final /* enum */ kcUD QGCU;
    public static final /* enum */ kcUD DHmV;
    public static final /* enum */ kcUD fLOJ;
    public static final /* enum */ kcUD XKWJ;
    public static final /* enum */ kcUD HoLr;
    public static final /* enum */ kcUD bsGu;
    public static final /* enum */ kcUD UuRl;
    public static final /* enum */ kcUD pjly;
    public static final /* enum */ kcUD jqmH;
    public static final /* enum */ kcUD gqTm;
    public static final /* enum */ kcUD UAls;
    public static final /* enum */ kcUD WjXA;
    public static final /* enum */ kcUD Gbwu;
    public static final /* enum */ kcUD Ojor;
    public static final /* enum */ kcUD slGX;
    public static final /* enum */ kcUD DHpM;
    public static final /* enum */ kcUD lfuK;
    public static final /* enum */ kcUD ejqX;
    public static final /* enum */ kcUD AGwN;
    public static final /* enum */ kcUD cJwx;
    public static final /* enum */ kcUD XeLc;
    public static final /* enum */ kcUD BSjf;
    public static final /* enum */ kcUD sJGQ;
    public static final /* enum */ kcUD OkTH;
    public static final /* enum */ kcUD qvdk;
    public static final /* enum */ kcUD WQIA;
    public static final /* enum */ kcUD jPNR;
    public static final /* enum */ kcUD gXGD;
    public static final /* enum */ kcUD DQas;
    public static final /* enum */ kcUD CFMJ;
    public static final /* enum */ kcUD ekPy;
    public static final /* enum */ kcUD OYpK;
    public static final /* enum */ kcUD mivm;
    public static final /* enum */ kcUD bsJH;
    public static final /* enum */ kcUD Pect;
    public static final /* enum */ kcUD xjWb;
    public static final /* enum */ kcUD yJwC;
    public static final /* enum */ kcUD skhc;
    public static final /* enum */ kcUD FiIO;
    public static final /* enum */ kcUD BvPQ;
    public static final /* enum */ kcUD pjpU;
    public static final /* enum */ kcUD xXuP;
    public static final /* enum */ kcUD UdSI;
    public static final /* enum */ kcUD xHSj;
    public static final /* enum */ kcUD uFym;
    public static final /* enum */ kcUD NWMt;
    public static final /* enum */ kcUD VNDj;
    public static final /* enum */ kcUD nKXF;
    public static final /* enum */ kcUD WGtv;
    public static final /* enum */ kcUD XBgt;
    public static final /* enum */ kcUD Snmk;
    public static final /* enum */ kcUD toKx;
    public static final /* enum */ kcUD FGIK;
    public static final /* enum */ kcUD LPil;
    public static final /* enum */ kcUD IrTu;
    public static final /* enum */ kcUD YxrV;
    public static final /* enum */ kcUD ETgA;
    public static final /* enum */ kcUD ydlR;
    public static final /* enum */ kcUD QFhB;
    public static final /* enum */ kcUD FFgr;
    public static final /* enum */ kcUD hQyl;
    public static final /* enum */ kcUD iMMe;
    public static final /* enum */ kcUD vmEU;
    public static final /* enum */ kcUD QNwp;
    public static final /* enum */ kcUD oxpm;
    public static final /* enum */ kcUD wUsw;
    public static final /* enum */ kcUD oqBA;
    public static final /* enum */ kcUD sJIU;
    public static final /* enum */ kcUD HMPD;
    public static final /* enum */ kcUD gykD;
    public static final /* enum */ kcUD EwKV;
    public static final /* enum */ kcUD pRAg;
    public static final /* enum */ kcUD qfEy;
    public static final /* enum */ kcUD uaPo;
    public static final /* enum */ kcUD GJJg;
    public static final /* enum */ kcUD LPhk;
    public static final /* enum */ kcUD EKsr;
    public static final /* enum */ kcUD KpIj;
    public static final /* enum */ kcUD dhPV;
    public static final /* enum */ kcUD ekRu;
    public static final /* enum */ kcUD kSSB;
    public static final /* enum */ kcUD ghiA;
    public static final /* enum */ kcUD NpbO;
    public static final /* enum */ kcUD Cgpx;
    public static final /* enum */ kcUD lVTp;
    public static final /* enum */ kcUD rqWy;
    public static final /* enum */ kcUD yeLN;
    public static final /* enum */ kcUD IqtA;
    public static final /* enum */ kcUD kmEM;
    public static final /* enum */ kcUD SMNR;
    public static final /* enum */ kcUD IqtG;
    public static final /* enum */ kcUD MCKs;
    public static final /* enum */ kcUD mYXU;
    public static final /* enum */ kcUD AbMO;
    public static final /* enum */ kcUD Pefl;
    public static final /* enum */ kcUD xrlj;
    public static final /* enum */ kcUD PDFv;
    public static final /* enum */ kcUD vKEE;
    public static final /* enum */ kcUD IHDF;
    public static final /* enum */ kcUD IXdV;
    public static final /* enum */ kcUD PLWa;
    public static final /* enum */ kcUD vtvk;
    public static final /* enum */ kcUD Gkop;
    public static final /* enum */ kcUD ujEA;
    public static final /* enum */ kcUD MvSV;
    public static final /* enum */ kcUD ixCm;
    public static final /* enum */ kcUD WQKs;
    private int IaVL;
    private static final /* synthetic */ kcUD[] ydmw;

    static {
        cv.V(1924723954, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b2e\ufbbb\ud187\u46e8\uc512\ub63c"), 0, 18000003));
        cv.V(1369765117, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b2a\ufbad\ud187\u46ee\uc514\ub625"), 1, 18000000));
        cv.V(-1761544964, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b20\ufba4\ud198\u46e0\uc519\ub62a"), 2, 18000000));
        cv.V(2088236287, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b21\ufbad\ud190\u46f3\uc508\ub63e\u3f80\u3f52\uaa9a\u9f9f\u2c4d"), 3, 18000000));
        cv.V(113505534, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b21\ufbad\ud190\u46f3\uc508\ub63e\u3f80\u3f52\uaa9a\u9f9f\u2c4d\u49d4\u889c\ud003\u5ebd\uea2a\u27e1"), 4, 18000000));
        cv.V(1452930297, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b21\ufbbf\ud19c\u46ed"), 5, 6000));
        cv.V(-1033767496, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b21\ufbaa\ud19d\u46e0\uc519\ub63a\u3f82\u3f45\uaa80\u9f8a\u2c5e\u49df\u889b\ud013\u5eb0\uea22"), 6, 6000));
        cv.V(-1052117573, (Object)new kcUD(rgig$AWxc.r("\uf820\u6b2d\ufbba\ud19c\u46e5\uc51e\ub62f\u3f81"), 7, 6000));
        cv.V(1758787002, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b21\ufbad\ud190\u46f3\uc508\ub62d\u3f87\u3f45\uaa9d\u9f8a"), 8, 3000));
        cv.V(1756296613, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b2e\ufbbd\ud190\u46f3"), 9, 500));
        cv.V(672462244, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2e\ufbbf\ud194"), 10, 500));
        cv.V(47904167, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba8\ud181\u46e8\uc518\ub620\u3f8e\u3f52\uaa97\u9f81\u2c56\u49ca\u888e\ud014\u5eae"), 11, 500));
        cv.V(192607654, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b3d\ufba8\ud192\u46ee\uc519\ub631\u3f8a\u3f47\uaa89"), 12, 45));
        cv.V(1937372577, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b21\ufbad\ud190\u46f3\uc508\ub63d\u3f9b\u3f4f\uaa80\u9f9b"), 13, 45));
        cv.V(597882272, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b20\ufba8\ud199\u46fe\uc515\ub622\u3f80\u3f43\uaa85"), 14, 30));
        cv.V(-958007901, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b26\ufba8\ud198\u46ee\uc519\ub62a\u3f90\u3f42\uaa82\u9f91\u2c42\u49c0"), 15, 30));
        cv.V(-1784154718, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b22\ufbac\ud187\u46e0\uc51b\ub62a\u3f90\u3f42\uaa82\u9f91\u2c42\u49c0"), 16, 30));
        cv.V(1575220653, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b20\ufba5\ud191\u46fe\uc515\ub622\u3f80\u3f43\uaa85"), 17, 30));
        cv.V(1706292652, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc515\ub622\u3f80\u3f43\uaa85"), 18, 30));
        cv.V(955315631, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud186\u46f5\uc518\ub620\u3f8a\u3f5f\uaa8c\u9f92\u2c4e\u49c8\u8891"), 19, 30));
        cv.V(-106170962, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b3d\ufba0\ud196\u46ea"), 20, 30));
        cv.V(1233057193, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b3d\ufba0\ud196\u46ea\uc508\ub63d\u3f9b\u3f41\uaa87\u9f8c\u2c52"), 21, 30));
        cv.V(373749160, (Object)new kcUD(rgig$AWxc.r("\uf827\u6b2e\ufbbb\ud191\u46fe\uc514\ub622\u3f8e\u3f59"), 22, 30));
        cv.V(-1053035093, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba6\ud19b\u46e4"), 23, 30));
        cv.V(2093151658, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b22\ufba6\ud19a\u46f5\uc51f\ub631\u3f8d\u3f52\uaa87\u9f9d\u2c4a"), 24, 30));
        cv.V(-488573547, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b22\ufba6\ud19a\u46f5\uc51f\ub631\u3f9c\u3f54\uaa8f\u9f97\u2c53\u49d8"), 25, 30));
        cv.V(1013446036, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b20\ufbbc\ud197\u46ed\uc512\ub631\u3f9c\u3f54\uaa81\u9f90\u2c44\u49d4\u8889\ud01d\u5ebd\uea25\u2796"), 26, 30));
        cv.V(-255461993, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba6\ud19b\u46e4\uc508\ub63d\u3f83\u3f41\uaa8c\u9fec"), 27, 30));
        cv.V(669906326, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc513\ub621\u3f80\u3f52"), 28, 30));
        cv.V(-945818223, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc513\ub621\u3f80\u3f52\uaa91\u9f9c\u2c4d\u49c4\u8899\ud01a"), 29, 25));
        cv.V(1380513168, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc503\ub63c\u3f8e\u3f50\uaa8a\u9f91\u2c4e\u49d9"), 30, 25));
        cv.V(2046490003, (Object)new kcUD(rgig$AWxc.r("\uf822\u6b20\ufbab\ud18a\u46f2\uc507\ub62f\u3f98\u3f4e\uaa8b\u9f8c"), 31, 25));
        cv.V(-1631980142, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b2a\ufbab"), 32, 20));
        cv.V(66975133, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b26\ufbba\ud185\u46e4\uc519\ub63d\u3f8a\u3f52"), 33, 17));
        cv.V(1066595740, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b3d\ufba6\ud185\u46f1\uc512\ub63c"), 34, 17));
        cv.V(-1046219361, (Object)new kcUD(rgig$AWxc.r("\uf829\u6b3a\ufbbb\ud19b\u46e0\uc514\ub62b"), 35, 17));
        cv.V(1387066782, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b3a\ufbbb\ud19b\u46e8\uc519\ub629\u3f90\u3f46\uaa9b\u9f8c\u2c4f\u49ca\u8899\ud014"), 36, 17));
        cv.V(-306448999, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b2a\ufba8\ud196\u46ee\uc519"), 37, 15));
        cv.V(1589442008, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b20\ufba8\ud199\u46fe\uc518\ub63c\u3f8a"), 38, 15));
        cv.V(-20908581, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b20\ufbaa\ud19a\u46e0"), 39, 15));
        cv.V(1423111642, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b26\ufba8\ud198\u46ee\uc519\ub62a\u3f90\u3f4f\uaa9c\u9f9b"), 40, 15));
        cv.V(591656389, (Object)new kcUD(rgig$AWxc.r("\uf82a\u6b22\ufbac\ud187\u46e0\uc51b\ub62a\u3f90\u3f4f\uaa9c\u9f9b"), 41, 15));
        cv.V(866579908, (Object)new kcUD(rgig$AWxc.r("\uf829\u6b2a\ufba7\ud196\u46e4"), 42, 15));
        cv.V(-291834425, (Object)new kcUD(rgig$AWxc.r("\uf829\u6b2a\ufba7\ud196\u46e4\uc508\ub629\u3f8e\u3f54\uaa8b"), 43, 15));
        cv.V(1082062278, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b2c\ufba8\ud196\u46e8\uc516\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44\u49d4\u889d\ud010\u5ea8\uea22"), 44, 15));
        cv.V(-826804799, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b26\ufbbb\ud196\u46e9\uc508\ub628\u3f8a\u3f4e\uaa8d\u9f9b\u2c5e\u49cc\u889b\ud005\u5eb9"), 45, 15));
        cv.V(-1896352320, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbbb\ud19e\u46fe\uc518\ub62f\u3f84\u3f5f\uaa88\u9f9b\u2c4f\u49c8\u889f\ud00e\u5ebb\uea26\u27f0\u80b8"), 46, 15));
        cv.V(848557507, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3f\ufbbb\ud180\u46e2\uc512\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44\u49d4\u889d\ud010\u5ea8\uea22"), 47, 15));
        cv.V(1481438658, (Object)new kcUD(rgig$AWxc.r("\uf825\u6b3a\ufba7\ud192\u46ed\uc512\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44\u49d4\u889d\ud010\u5ea8\uea22"), 48, 15));
        cv.V(-1250822707, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b2c\ufba8\ud196\u46e8\uc516\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44"), 49, 15));
        cv.V(311293388, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b26\ufbbb\ud196\u46e9\uc508\ub628\u3f8a\u3f4e\uaa8d\u9f9b"), 50, 15));
        cv.V(511899087, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbbb\ud19e\u46fe\uc518\ub62f\u3f84\u3f5f\uaa88\u9f9b\u2c4f\u49c8\u889f"), 51, 15));
        cv.V(-1392839218, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3f\ufbbb\ud180\u46e2\uc512\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44"), 52, 15));
        cv.V(997651913, (Object)new kcUD(rgig$AWxc.r("\uf825\u6b3a\ufba7\ud192\u46ed\uc512\ub631\u3f89\u3f45\uaa80\u9f9d\u2c44"), 53, 15));
        cv.V(-464194104, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b2c\ufba8\ud196\u46e8\uc516\ub631\u3f98\u3f4f\uaa81\u9f9a\u2c5e\u49d8\u888e\ud010\u5eb5\uea35\u27f7"), 54, 15));
        cv.V(1174533579, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b26\ufbbb\ud196\u46e9\uc508\ub639\u3f80\u3f4f\uaa8a\u9f81\u2c52\u49df\u889b\ud018\u5eae\uea34"), 55, 15));
        cv.V(-1033046582, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbbb\ud19e\u46fe\uc518\ub62f\u3f84\u3f5f\uaa99\u9f91\u2c4e\u49cf\u8885\ud002\u5ea8\uea26\u27ed\u80af\ue3e5"), 56, 15));
        cv.V(336065973, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3f\ufbbb\ud180\u46e2\uc512\ub631\u3f98\u3f4f\uaa81\u9f9a\u2c5e\u49d8\u888e\ud010\u5eb5\uea35\u27f7"), 57, 15));
        cv.V(-545720908, (Object)new kcUD(rgig$AWxc.r("\uf825\u6b3a\ufba7\ud192\u46ed\uc512\ub631\u3f98\u3f4f\uaa81\u9f9a\u2c5e\u49d8\u888e\ud010\u5eb5\uea35\u27f7"), 58, 15));
        cv.V(-335546953, (Object)new kcUD(rgig$AWxc.r("\uf83e\u6b3a\ufba8\ud187\u46f5\uc50d\ub631\u3f9c\u3f54\uaa8f\u9f97\u2c53\u49d8"), 59, 15));
        cv.V(1486419382, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b20\ufbab\ud197\u46ed\uc512\ub63d\u3f9b\u3f4f\uaa80\u9f9b\u2c5e\u49d8\u888e\ud010\u5eb5\uea35\u27f7"), 60, 15));
        cv.V(171374001, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b2e\ufba7\ud191\u46f2\uc503\ub621\u3f81\u3f45\uaa91\u9f8d\u2c55\u49ca\u8893\ud003\u5eaf"), 61, 15));
        cv.V(-2143291984, (Object)new kcUD(rgig$AWxc.r("\uf821\u6b2a\ufbbd\ud19d\u46e4\uc505\ub631\u3f8d\u3f52\uaa87\u9f9d\u2c4a\u49d4\u8889\ud005\u5ebd\uea2e\u27f6\u80ae"), 62, 15));
        cv.V(-1924205133, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufba6\ud191\u46fe\uc504\ub63a\u3f8e\u3f49\uaa9c\u9f8d"), 63, 15));
        cv.V(-468716110, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud18a\u46f2\uc516\ub620\u3f8b\u3f53\uaa9a\u9f91\u2c4f\u49ce\u8885\ud002\u5ea8\uea26\u27ed\u80af\ue3e5"), 64, 15));
        cv.V(-520030787, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b2c\ufba8\ud196\u46e8\uc516\ub631\u3f8b\u3f4f\uaa81\u9f8c"), 65, 15));
        cv.V(181925308, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b26\ufbbb\ud196\u46e9\uc508\ub62a\u3f80\u3f4f\uaa9c"), 66, 15));
        cv.V(-1623657025, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbbb\ud19e\u46fe\uc518\ub62f\u3f84\u3f5f\uaa8a\u9f91\u2c4e\u49d9"), 67, 15));
        cv.V(-533137986, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3f\ufbbb\ud180\u46e2\uc512\ub631\u3f8b\u3f4f\uaa81\u9f8c"), 68, 15));
        cv.V(-468388423, (Object)new kcUD(rgig$AWxc.r("\uf825\u6b3a\ufba7\ud192\u46ed\uc512\ub631\u3f8b\u3f4f\uaa81\u9f8c"), 69, 15));
        cv.V(1662449016, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b20\ufba5\ud191\u46fe\uc518\ub63c\u3f8a"), 70, 15));
        cv.V(-1113721477, (Object)new kcUD(rgig$AWxc.r("\uf827\u6b20\ufbb9\ud185\u46e4\uc505"), 71, 15));
        cv.V(-1959856774, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc518\ub63c\u3f8a"), 72, 15));
        cv.V(104658277, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2e\ufbb9\ud19c\u46f2\uc508\ub62c\u3f83\u3f4f\uaa8d\u9f95"), 73, 15));
        cv.V(-727190172, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2e\ufbb9\ud19c\u46f2\uc508\ub621\u3f9d\u3f45"), 74, 15));
        cv.V(-338889369, (Object)new kcUD(rgig$AWxc.r("\uf83e\u6b3a\ufba8\ud187\u46f5\uc50d\ub631\u3f80\u3f52\uaa8b"), 75, 15));
        cv.V(635434342, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud186\u46f5\uc518\ub620\u3f8a\u3f5f\uaa81\u9f8c\u2c44"), 76, 15));
        cv.V(505541985, (Object)new kcUD(rgig$AWxc.r("\uf83b\u6b3d\ufba8\ud185\u46fe\uc513\ub621\u3f80\u3f52"), 77, 15));
        cv.V(1065743712, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufba6\ud191"), 78, 15));
        cv.V(541848931, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b27\ufbac\ud186\u46f5"), 79, 12));
        cv.V(1637545314, (Object)new kcUD(rgig$AWxc.r("\uf83b\u6b3d\ufba8\ud185\u46f1\uc512\ub62a\u3f90\u3f43\uaa86\u9f9b\u2c52\u49df"), 80, 12));
        cv.V(-2019691155, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufbbb\ud19e\u46e3\uc512\ub620\u3f8c\u3f48"), 81, 12));
        cv.V(479720812, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b2e\ufbbc\ud199\u46e5\uc505\ub621\u3f81"), 82, 12));
        cv.V(14480751, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b20\ufbae"), 83, 10));
        cv.V(-2015103634, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b20\ufbae\ud18a\u4693"), 84, 10));
        cv.V(307623273, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b20\ufba6\ud19e\u46f2\uc51f\ub62b\u3f83\u3f46"), 85, 7));
        cv.V(-515705496, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b2e\ufba7\ud19b\u46e4\uc505"), 86, 5));
        cv.V(-788466325, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba8\ud19b\u46e5\uc51e\ub620\u3f88\u3f5f\uaa8c\u9f9f\u2c4f\u49c5\u889f\ud003"), 87, 5));
        cv.V(-2037320342, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b2e\ufba5\ud199\u46fe\uc515\ub62f\u3f81\u3f4e\uaa8b\u9f8c"), 88, 5));
        cv.V(-1145309867, (Object)new kcUD(rgig$AWxc.r("\uf825\u6b2e\ufbaa\ud19e\u46fe\uc518\ub631\u3f83\u3f41\uaa80\u9f8a\u2c44\u49d9\u8894"), 89, 5));
        cv.V(1013577044, (Object)new kcUD(rgig$AWxc.r("\uf822\u6b2a\ufba5\ud19a\u46ef\uc508\ub62c\u3f83\u3f4f\uaa8d\u9f95"), 90, 5));
        cv.V(1635120471, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b24\ufbbc\ud199\u46ed"), 91, 5));
        cv.V(1981085014, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b3a\ufba4\ud185\u46ea\uc51e\ub620"), 92, 5));
        cv.V(-713165487, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b26\ufbae\ud19b"), 93, 5));
        cv.V(-1238633136, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b26\ufbae\ud19b\u46fe\uc507\ub621\u3f9c\u3f54"), 94, 5));
        cv.V(981923155, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b2e\ufba5\ud199\u46fe\uc504\ub627\u3f88\u3f4e"), 95, 5));
        cv.V(-1491471022, (Object)new kcUD(rgig$AWxc.r("\uf83e\u6b3a\ufba8\ud187\u46f5\uc50d\ub631\u3f8d\u3f4c\uaa81\u9f9d\u2c4a"), 96, 4));
        cv.V(772142429, (Object)new kcUD(rgig$AWxc.r("\uf821\u6b20\ufbbd\ud190\u46fe\uc515\ub622\u3f80\u3f43\uaa85"), 97, 4));
        cv.V(-1998981796, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud18a\u46f2\uc516\ub620\u3f8b\u3f53\uaa9a\u9f91\u2c4f\u49ce"), 98, 4));
        cv.V(-627313313, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b2e\ufba7\ud191\u46f2\uc503\ub621\u3f81\u3f45"), 99, 4));
        cv.V(1156838750, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufba6\ud199"), 100, 4));
        cv.V(-241371815, (Object)new kcUD(rgig$AWxc.r("\uf822\u6b20\ufba7\ud186\u46f5\uc512\ub63c\u3f90\u3f45\uaa89\u9f99"), 101, 4));
        cv.V(2015032728, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2e\ufba0\ud199\u46f2"), 102, 3));
        cv.V(556987803, (Object)new kcUD(rgig$AWxc.r("\uf82e\u6b2c\ufbbd\ud19c\u46f7\uc516\ub63a\u3f80\u3f52\uaa91\u9f8c\u2c40\u49c2\u8896"), 103, 3));
        cv.V(1966863770, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2a\ufbbd\ud190\u46e2\uc503\ub621\u3f9d\u3f5f\uaa9c\u9f9f\u2c48\u49c7"), 104, 3));
        cv.V(-375261819, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b20\ufbbe\ud190\u46f3\uc512\ub62a\u3f90\u3f52\uaa8f\u9f97\u2c4d"), 105, 3));
        cv.V(1875768708, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b23\ufba8\ud18c"), 106, 3));
        cv.V(-2057964153, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b26\ufbbb\ud181"), 107, 3));
        cv.V(-1634667130, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b3d\ufba8\ud186\u46f2"), 108, 3));
        cv.V(-1780222591, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b3d\ufba8\ud183\u46e4\uc51b"), 109, 3));
        cv.V(62387584, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3f\ufba6\ud19b\u46e6\uc512"), 110, 3));
        cv.V(192804227, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b3d\ufbac\ud182\u46e8\uc519\ub629\u3f90\u3f53\uaa9a\u9f9f\u2c4f\u49cf"), 111, 3));
        cv.V(577172866, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba6\ud19b\u46e4\uc508\ub62c\u3f9a\u3f54\uaa9a\u9f91\u2c4f"), 112, 3));
        cv.V(83424653, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufba6\ud191\u46fe\uc515\ub63b\u3f9b\u3f54\uaa81\u9f90"), 113, 3));
        cv.V(125695372, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b2e\ufba2\ud190\u46fe\uc515\ub622\u3f80\u3f43\uaa85"), 114, 3));
        cv.V(-1749355121, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b2c\ufbac"), 115, 3));
        cv.V(-194513522, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b2e\ufbaa\ud19e\u46e4\uc513\ub631\u3f86\u3f43\uaa8b"), 116, 3));
        cv.V(1599337865, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2a\ufbbf\ud190\u46f3"), 117, 3));
        cv.V(1193407880, (Object)new kcUD(rgig$AWxc.r("\uf822\u6b36\ufbaa\ud190\u46ed"), 118, 3));
        cv.V(1148319115, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b26\ufbba\ud181\u46ee\uc519\ub631\u3f8d\u3f41\uaa9d\u9f9b"), 119, 3));
        cv.V(-818481782, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b26\ufbba\ud181\u46ee\uc519\ub631\u3f8a\u3f58\uaa9a\u9f9b\u2c4f\u49d8\u8893\ud01e\u5eb2"), 120, 3));
        cv.V(750450037, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b26\ufbba\ud181\u46ee\uc519\ub631\u3f82\u3f4f\uaa98\u9f97\u2c4f\u49cc\u8885\ud001\u5eb5\uea22\u27e7\u80b8"), 121, 3));
        cv.V(-1626081932, (Object)new kcUD(rgig$AWxc.r("\uf83f\u6b26\ufbba\ud181\u46ee\uc519\ub631\u3f9c\u3f54\uaa87\u9f9d\u2c4a\u49d2\u8885\ud013\u5ebd\uea34\u27e1"), 122, 3));
        cv.V(1411708279, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b20\ufba5\ud191\u46fe\uc507\ub622\u3f8e\u3f54\uaa8b"), 123, 3));
        cv.V(710669686, (Object)new kcUD(rgig$AWxc.r("\uf826\u6b3d\ufba6\ud19b\u46fe\uc507\ub622\u3f8e\u3f54\uaa8b"), 124, 3));
        cv.V(456783217, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba6\ud19b\u46e4\uc508\ub63e\u3f83\u3f41\uaa9a\u9f9b"), 125, 3));
        cv.V(138016112, (Object)new kcUD(rgig$AWxc.r("\uf838\u6b20\ufba6\ud191\u46fe\uc507\ub622\u3f8e\u3f54\uaa8b"), 126, 3));
        cv.V(194180467, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b2e\ufba7\ud191"), 127, 3));
        cv.V(1969878386, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b20\ufbbc\ud199\u46fe\uc504\ub62f\u3f81\u3f44"), 128, 3));
        cv.V(120649085, (Object)new kcUD(rgig$AWxc.r("\uf82c\u6b2e\ufbaa\ud181\u46f4\uc504"), 129, 2));
        cv.V(606401916, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2e\ufbad\ud191\u46e4\uc505"), 130, 2));
        cv.V(1935734143, (Object)new kcUD(rgig$AWxc.r("\uf821\u6b2a\ufbbd\ud19d\u46e4\uc505\ub63c\u3f8e\u3f43\uaa85"), 131, 2));
        cv.V(1084093822, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b23\ufba8\ud186\u46f2"), 132, 1));
        cv.V(1777464697, (Object)new kcUD(rgig$AWxc.r("\uf83b\u6b27\ufba0\ud19b\u46fe\uc510\ub622\u3f8e\u3f53\uaa9d"), 133, 1));
        cv.V(478606392, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba8\ud19c\u46ef\uc512\ub62a\u3f90\u3f47\uaa82\u9f9f\u2c52\u49d8"), 134, 1));
        cv.V(-697174981, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b3b\ufba8\ud19c\u46ef\uc512\ub62a\u3f90\u3f47\uaa82\u9f9f\u2c52\u49d8\u8885\ud001\u5ebd\uea29\u27e1"), 135, 1));
        cv.V(1077212218, (Object)new kcUD(rgig$AWxc.r("\uf828\u6b23\ufba6\ud182\u46f2\uc503\ub621\u3f81\u3f45"), 136, 1));
        cv.V(1382020133, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud186\u46f5\uc518\ub620\u3f8a\u3f5f\uaa82\u9f9f\u2c4c\u49db\u8885\ud01e\u5eba\uea21"), 137, 1));
        cv.V(785576996, (Object)new kcUD(rgig$AWxc.r("\uf83d\u6b2a\ufbad\ud186\u46f5\uc518\ub620\u3f8a\u3f5f\uaa82\u9f9f\u2c4c\u49db\u8885\ud01e\u5eb2"), 138, 1));
        cv.V(-1757285337, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b2a\ufba8\ud18a\u46ed\uc516\ub620\u3f9b\u3f45\uaa9c\u9f90"), 139, 1));
        cv.V(-794627034, (Object)new kcUD(rgig$AWxc.r("\uf82d\u6b2a\ufbad\ud18a\u46e3\uc51b\ub621\u3f8c\u3f4b"), 140, 1));
        cv.V(1621029921, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbb0\ud199\u46e8\uc510\ub626\u3f9b\u3f5f\uaa8a\u9f9b\u2c55\u49ce\u8899\ud005\u5eb3\uea35"), 141, 1));
        cv.V(-2104822752, (Object)new kcUD(rgig$AWxc.r("\uf82b\u6b2e\ufbb0\ud199\u46e8\uc510\ub626\u3f9b\u3f5f\uaa8a\u9f9b\u2c55\u49ce\u8899\ud005\u5eb3\uea35\u27fb\u80b4\ue3f8\uf3c4\ue78f\u9c9c\uae2c\u5af0\uc20e"), 142, 1));
        cv.V(-1868041181, (Object)new kcUD(rgig$AWxc.r("\uf827\u6b3a\ufbae\ud190\u46fe\uc51a\ub63b\u3f9c\u3f48\uaa9c\u9f91\u2c4e\u49c6\u8885\ud060"), 143, 1));
        cv.V(1441330210, (Object)new kcUD(rgig$AWxc.r("\uf827\u6b3a\ufbae\ud190\u46fe\uc51a\ub63b\u3f9c\u3f48\uaa9c\u9f91\u2c4e\u49c6\u8885\ud063"), 144, 1));
        cv.V(1768617005, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2a\ufba8\ud183\u46e4\uc504"), 145, 1));
        cv.V(-163646420, (Object)new kcUD(rgig$AWxc.r("\uf823\u6b2a\ufba8\ud183\u46e4\uc504\ub631\u3ffd"), 146, 1));
        cv.V(595325999, (Object)new kcUD(rgig$AWxc.r("\uf83c\u6b21\ufba6\ud182"), 147, 1));
        cv.V(257422382, new kcUD[]{(kcUD)((Object)cv.e(1924723954)), (kcUD)((Object)cv.e(1369765117)), (kcUD)((Object)cv.e(-1761544964)), (kcUD)((Object)cv.e(2088236287)), (kcUD)((Object)cv.e(113505534)), (kcUD)((Object)cv.e(1452930297)), (kcUD)((Object)cv.e(-1033767496)), (kcUD)((Object)cv.e(-1052117573)), (kcUD)((Object)cv.e(1758787002)), (kcUD)((Object)cv.e(1756296613)), (kcUD)((Object)cv.e(672462244)), (kcUD)((Object)cv.e(47904167)), (kcUD)((Object)cv.e(192607654)), (kcUD)((Object)cv.e(1937372577)), (kcUD)((Object)cv.e(597882272)), (kcUD)((Object)cv.e(-958007901)), (kcUD)((Object)cv.e(-1784154718)), (kcUD)((Object)cv.e(1575220653)), (kcUD)((Object)cv.e(1706292652)), (kcUD)((Object)cv.e(955315631)), (kcUD)((Object)cv.e(-106170962)), (kcUD)((Object)cv.e(1233057193)), (kcUD)((Object)cv.e(373749160)), (kcUD)((Object)cv.e(-1053035093)), (kcUD)((Object)cv.e(2093151658)), (kcUD)((Object)cv.e(-488573547)), (kcUD)((Object)cv.e(1013446036)), (kcUD)((Object)cv.e(-255461993)), (kcUD)((Object)cv.e(669906326)), (kcUD)((Object)cv.e(-945818223)), (kcUD)((Object)cv.e(1380513168)), (kcUD)((Object)cv.e(2046490003)), (kcUD)((Object)cv.e(-1631980142)), (kcUD)((Object)cv.e(66975133)), (kcUD)((Object)cv.e(1066595740)), (kcUD)((Object)cv.e(-1046219361)), (kcUD)((Object)cv.e(1387066782)), (kcUD)((Object)cv.e(-306448999)), (kcUD)((Object)cv.e(1589442008)), (kcUD)((Object)cv.e(-20908581)), (kcUD)((Object)cv.e(1423111642)), (kcUD)((Object)cv.e(591656389)), (kcUD)((Object)cv.e(866579908)), (kcUD)((Object)cv.e(-291834425)), (kcUD)((Object)cv.e(1082062278)), (kcUD)((Object)cv.e(-826804799)), (kcUD)((Object)cv.e(-1896352320)), (kcUD)((Object)cv.e(848557507)), (kcUD)((Object)cv.e(1481438658)), (kcUD)((Object)cv.e(-1250822707)), (kcUD)((Object)cv.e(311293388)), (kcUD)((Object)cv.e(511899087)), (kcUD)((Object)cv.e(-1392839218)), (kcUD)((Object)cv.e(997651913)), (kcUD)((Object)cv.e(-464194104)), (kcUD)((Object)cv.e(1174533579)), (kcUD)((Object)cv.e(-1033046582)), (kcUD)((Object)cv.e(336065973)), (kcUD)((Object)cv.e(-545720908)), (kcUD)((Object)cv.e(-335546953)), (kcUD)((Object)cv.e(1486419382)), (kcUD)((Object)cv.e(171374001)), (kcUD)((Object)cv.e(-2143291984)), (kcUD)((Object)cv.e(-1924205133)), (kcUD)((Object)cv.e(-468716110)), (kcUD)((Object)cv.e(-520030787)), (kcUD)((Object)cv.e(181925308)), (kcUD)((Object)cv.e(-1623657025)), (kcUD)((Object)cv.e(-533137986)), (kcUD)((Object)cv.e(-468388423)), (kcUD)((Object)cv.e(1662449016)), (kcUD)((Object)cv.e(-1113721477)), (kcUD)((Object)cv.e(-1959856774)), (kcUD)((Object)cv.e(104658277)), (kcUD)((Object)cv.e(-727190172)), (kcUD)((Object)cv.e(-338889369)), (kcUD)((Object)cv.e(635434342)), (kcUD)((Object)cv.e(505541985)), (kcUD)((Object)cv.e(1065743712)), (kcUD)((Object)cv.e(541848931)), (kcUD)((Object)cv.e(1637545314)), (kcUD)((Object)cv.e(-2019691155)), (kcUD)((Object)cv.e(479720812)), (kcUD)((Object)cv.e(14480751)), (kcUD)((Object)cv.e(-2015103634)), (kcUD)((Object)cv.e(307623273)), (kcUD)((Object)cv.e(-515705496)), (kcUD)((Object)cv.e(-788466325)), (kcUD)((Object)cv.e(-2037320342)), (kcUD)((Object)cv.e(-1145309867)), (kcUD)((Object)cv.e(1013577044)), (kcUD)((Object)cv.e(1635120471)), (kcUD)((Object)cv.e(1981085014)), (kcUD)((Object)cv.e(-713165487)), (kcUD)((Object)cv.e(-1238633136)), (kcUD)((Object)cv.e(981923155)), (kcUD)((Object)cv.e(-1491471022)), (kcUD)((Object)cv.e(772142429)), (kcUD)((Object)cv.e(-1998981796)), (kcUD)((Object)cv.e(-627313313)), (kcUD)((Object)cv.e(1156838750)), (kcUD)((Object)cv.e(-241371815)), (kcUD)((Object)cv.e(2015032728)), (kcUD)((Object)cv.e(556987803)), (kcUD)((Object)cv.e(1966863770)), (kcUD)((Object)cv.e(-375261819)), (kcUD)((Object)cv.e(1875768708)), (kcUD)((Object)cv.e(-2057964153)), (kcUD)((Object)cv.e(-1634667130)), (kcUD)((Object)cv.e(-1780222591)), (kcUD)((Object)cv.e(62387584)), (kcUD)((Object)cv.e(192804227)), (kcUD)((Object)cv.e(577172866)), (kcUD)((Object)cv.e(83424653)), (kcUD)((Object)cv.e(125695372)), (kcUD)((Object)cv.e(-1749355121)), (kcUD)((Object)cv.e(-194513522)), (kcUD)((Object)cv.e(1599337865)), (kcUD)((Object)cv.e(1193407880)), (kcUD)((Object)cv.e(1148319115)), (kcUD)((Object)cv.e(-818481782)), (kcUD)((Object)cv.e(750450037)), (kcUD)((Object)cv.e(-1626081932)), (kcUD)((Object)cv.e(1411708279)), (kcUD)((Object)cv.e(710669686)), (kcUD)((Object)cv.e(456783217)), (kcUD)((Object)cv.e(138016112)), (kcUD)((Object)cv.e(194180467)), (kcUD)((Object)cv.e(1969878386)), (kcUD)((Object)cv.e(120649085)), (kcUD)((Object)cv.e(606401916)), (kcUD)((Object)cv.e(1935734143)), (kcUD)((Object)cv.e(1084093822)), (kcUD)((Object)cv.e(1777464697)), (kcUD)((Object)cv.e(478606392)), (kcUD)((Object)cv.e(-697174981)), (kcUD)((Object)cv.e(1077212218)), (kcUD)((Object)cv.e(1382020133)), (kcUD)((Object)cv.e(785576996)), (kcUD)((Object)cv.e(-1757285337)), (kcUD)((Object)cv.e(-794627034)), (kcUD)((Object)cv.e(1621029921)), (kcUD)((Object)cv.e(-2104822752)), (kcUD)((Object)cv.e(-1868041181)), (kcUD)((Object)cv.e(1441330210)), (kcUD)((Object)cv.e(1768617005)), (kcUD)((Object)cv.e(-163646420)), (kcUD)((Object)cv.e(595325999))});
    }

    private kcUD(String string2, int n2, int n3) {
        this.IaVL = string2;
    }

    public int SKrK() {
        return (Integer)cv.b((Object)this, 1750070313);
    }

    public static int ssNb(Material material) {
        if (kcUD.TU(material) == false) {
            return 0;
        }
        try {
            return kcUD.valueOf((String)kcUD.TU(material)).SKrK();
        }
        catch (Exception exception) {
            return 0;
        }
    }

    public static kcUD[] values() {
        kcUD[] arrkcUD = (kcUD[])cv.e(257422382);
        int n = arrkcUD.length;
        kcUD[] arrkcUD2 = new kcUD[n];
        kcUD.TU(arrkcUD, false, arrkcUD2, false, n);
        return arrkcUD2;
    }

    public static kcUD valueOf(String string) {
        return (kcUD)((Object)kcUD.TU(kcUD.class, string));
    }

    private static Object TU(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

