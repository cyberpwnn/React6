/*
 * Decompiled with CFR 0_123.
 */
public interface mXMK<K, V> {
    public QyFw<V> ssNb(K var1);

    public void put(K var1, V var2);

    public void DYFV(K var1);

    public void clear();

    public boolean IWSm(K var1);

    public wfPa<K> rwyd();
}

