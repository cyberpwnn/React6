/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.ConsoleCommandSender
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import org.bukkit.command.ConsoleCommandSender;

public class rpXo {
    private static wfPa<String> Jcxo;

    static {
        cv.V(1972500141, new wfPa());
    }

    /*
     * Enabled aggressive block sorting
     */
    public static void flush() {
        while (rpXo.Mm((wfPa)cv.e(1972500141)) == false) {
            rpXo.Mm().getConsoleSender().sendMessage((String)rpXo.Mm((wfPa)cv.e(1972500141)));
        }
    }

    private static void DYFV(String string, String string2) {
        Object object = rpXo.Mm(rpXo.Mm(new StringBuilder(KUXS$dwji.S("\ucbab\u4678\ua1ec\u3c31\uc274\u7c38\u9423")), string2));
        if (rpXo.Mm() != false) {
            rpXo.Mm().getConsoleSender().sendMessage((String)object);
            return;
        }
        rpXo.Mm((wfPa)cv.e(1972500141), rpXo.Mm(rpXo.Mm(rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1071443542))), KUXS$dwji.S("\ucba2\u465c\ua1de\u3c0b\uc24e\u7c41\u945e\udf89")), (APKB)((Object)cv.e(653004664))), object)));
    }

    public static void ssNb(Object object, String string) {
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1197215955))), rgig$AWxc.r("\ua913\u5a30\ucc32\u65bc\u760f"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void DYFV(Object object, String string) {
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1489703379))), YEBy$TyVf.W("\u9866:\u5345\u47b5\u80b6"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void IWSm(Object object, String string) {
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1071443542))), KUXS$dwji.S("\u2e05\u2697\u82f0\u7b72\uafd7"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void OXeK(Object object, String string) {
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), KUXS$dwji.S("\ubc1b\u3d59\uf87d\uf940\u5f24"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1154812849))), string)));
    }

    public static void YoSa(Object object, String string) {
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), KUXS$dwji.S("\ufdf8\u56cc\u20de\u2798\ue117"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), string)));
    }

    public static void INcj(String string) {
        if (rpXo.Mm() == false) {
            rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1197215955))), YEBy$TyVf.W("\u96c4\u9075\u10df\uc429\ud424"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
            return;
        }
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1197215955))), YEBy$TyVf.W("\u96c4\u9075\u10df\uc429\ud424"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void VCgr(String string) {
        if (rpXo.Mm() == false) {
            rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1489703379))), YEBy$TyVf.W("\u88bc\ub16a\uc721\u5de7\u87cc"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
            return;
        }
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(1489703379))), YEBy$TyVf.W("\u88bc\ub16a\uc721\u5de7\u87cc"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void gEXv(String string) {
        if (rpXo.Mm() == false) {
            rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1071443542))), rgig$AWxc.r("\u5b69\ud1b6\u14f4\ud1bf\uca12"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
            return;
        }
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1071443542))), rgig$AWxc.r("\u5b69\ud1b6\u14f4\ud1bf\uca12"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(653004664))), string)));
    }

    public static void tvRU(String string) {
        if (rpXo.Mm() == false) {
            rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), YEBy$TyVf.W("\ud0f4\u9978\u3c42\u9c14\uce27"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1154812849))), string)));
            return;
        }
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), YEBy$TyVf.W("\ud0f4\u9978\u3c42\u9c14\uce27"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-1154812849))), string)));
    }

    public static void dntE(String string) {
        if (rpXo.Mm() == false) {
            rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), rgig$AWxc.r("\u6993\u2f6a\u4f1c\ue664\u54c5"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), string)));
            return;
        }
        rpXo.DYFV((String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), rgig$AWxc.r("\u6993\u2f6a\u4f1c\ue664\u54c5"))), (String)rpXo.Mm(rpXo.Mm(rpXo.Mm(new StringBuilder(), (APKB)((Object)cv.e(-314502936))), string)));
    }

    private static Object Mm(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

