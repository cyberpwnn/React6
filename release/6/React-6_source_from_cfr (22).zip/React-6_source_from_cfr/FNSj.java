/*
 * Decompiled with CFR 0_123.
 */
public class FNSj<A, B, C, D> {
    private A HemE;
    private B cAun;
    private C ssgo;
    private D wLrt;

    public FNSj(A a, B b, C c, D d) {
        this.HemE = a;
        this.cAun = b;
        this.ssgo = c;
        this.wLrt = d;
    }

    public A GkIA() {
        return (A)cv.b(this, -780470250);
    }

    public void lCdp(A a) {
        cv.e(this, -780470250, a);
    }

    public B YDfo() {
        return (B)cv.b(this, -1335756783);
    }

    public void nJLQ(B b) {
        cv.e(this, -1335756783, b);
    }

    public C JlDV() {
        return (C)cv.b(this, 1555298320);
    }

    public void TyVf(C c) {
        cv.e(this, 1555298320, c);
    }

    public D aDQd() {
        return (D)cv.b(this, 440268819);
    }

    public void LGKl(D d) {
        cv.e(this, 440268819, d);
    }
}

