/*
 * Decompiled with CFR 0_123.
 */
final class JbuU$lCdp
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public JbuU$lCdp(String string) {
        super(string);
    }
}

