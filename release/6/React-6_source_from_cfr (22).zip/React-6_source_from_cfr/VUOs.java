/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class VUOs {
    public static final String WjKv = rgig$AWxc.r("\ub833\u7f79");

    public static vslr vtFs(String string) throws TOKE {
        vslr vslr2 = new vslr();
        VCnE vCnE = new VCnE(string);
        Object object = VUOs.aV(vCnE);
        if (VUOs.aV(VUOs.aV(object), rgig$AWxc.r("\ud2fa\ua138\u8b13\u276b")) != false) {
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2fa\ua138\u8b13\u276b\u3a10\u4dbd\u00c5\u6ecc\u90d6\u9559\u4c12\uec35"), object);
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2e1\ua118\u8b26\u274f\u3a48\u4d98\u008d\u6efd\u90ca\u9554\u4c18"), VUOs.aV(vCnE));
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2e0\ua109\u8b26\u2748\u3a52\u4d85\u008d\u6eee\u90cd\u9542\u4c1c\uec28\uf371"), VUOs.aV(vCnE, false));
            VUOs.aV(vCnE);
        } else {
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2ff\ua109\u8b33\u2753\u3a52\u4d8f"), object);
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2e0\ua109\u8b36\u274e\u3a58\u4d98\u00d4\u6e93\u90f0\u9562\u4c34"), VUOs.aV(vCnE));
            VUOs.aV(vslr2, rgig$AWxc.r("\ud2fa\ua138\u8b13\u276b\u3a10\u4dbd\u00c5\u6ecc\u90d6\u9559\u4c12\uec35"), VUOs.aV(vCnE));
        }
        do {
            if (VUOs.aV(vCnE) == false) break;
            Object object2 = VUOs.aV(vCnE, 58);
            VUOs.aV(vCnE, 58);
            VUOs.aV(vslr2, object2, VUOs.aV(vCnE, false));
            VUOs.aV(vCnE);
        } while (true);
        return vslr2;
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    public static String DYFV(vslr var0) throws TOKE {
        var1_1 = VUOs.aV(var0);
        var3_2 = new StringBuilder();
        if (VUOs.aV(var0, rgig$AWxc.r("\u2ca5\u154e\u3535\u6430\ufddd\u6a2f\u52eb\ud314\u82cf\ufe1d\u2adf")) == false) ** GOTO lbl-1000
        if (VUOs.aV(var0, rgig$AWxc.r("\u2ca4\u155f\u3535\u6437\ufdc7\u6a32\u52eb\ud307\u82c8\ufe0b\u2adb\ud45b\u4343")) != false) {
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2cbe\u156e\u3500\u6414\ufd85\u6a0a\u52a3\ud325\u82d3\ufe10\u2ad5\ud446")));
            VUOs.aV(var3_2, 32);
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2ca5\u154e\u3535\u6430\ufddd\u6a2f\u52eb\ud314\u82cf\ufe1d\u2adf")));
            VUOs.aV(var3_2, 32);
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2ca4\u155f\u3535\u6437\ufdc7\u6a32\u52eb\ud307\u82c8\ufe0b\u2adb\ud45b\u4343")));
        } else lbl-1000: // 2 sources:
        {
            if (VUOs.aV(var0, rgig$AWxc.r("\u2cbb\u155f\u3520\u642c\ufdc7\u6a38")) == false) throw new TOKE(rgig$AWxc.r("\u2cb8\u1555\u3520\u6464\ufdcd\u6a32\u52a9\ud322\u82c7\ufe11\u2a9a\ud445\u4347\u2f7a\u6ba6\uf61a\u3a32\u4ff6\u9418\u3472\u5cca\u01e0\u1f39\ubbcf\u67e0\u56df\uf874\u4502\u3424\u4d62\u0ab9\ud835\u90e4\uff2d\u5106\u87be\udec2\u398f\u783f"));
            if (VUOs.aV(var0, rgig$AWxc.r("\u2ca4\u155f\u3525\u6431\ufdcd\u6a2f\u52b2\ud37a\u82f5\ufe2b\u2af3")) == false) throw new TOKE(rgig$AWxc.r("\u2cb8\u1555\u3520\u6464\ufdcd\u6a32\u52a9\ud322\u82c7\ufe11\u2a9a\ud445\u4347\u2f7a\u6ba6\uf61a\u3a32\u4ff6\u9418\u3472\u5cca\u01e0\u1f39\ubbcf\u67e0\u56df\uf874\u4502\u3424\u4d62\u0ab9\ud835\u90e4\uff2d\u5106\u87be\udec2\u398f\u783f"));
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2cbb\u155f\u3520\u642c\ufdc7\u6a38")));
            VUOs.aV(var3_2, 32);
            VUOs.aV(var3_2, 34);
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2ca4\u155f\u3525\u6431\ufdcd\u6a2f\u52b2\ud37a\u82f5\ufe2b\u2af3")));
            VUOs.aV(var3_2, 34);
            VUOs.aV(var3_2, 32);
            VUOs.aV(var3_2, VUOs.aV(var0, rgig$AWxc.r("\u2cbe\u156e\u3500\u6414\ufd85\u6a0a\u52a3\ud325\u82d3\ufe10\u2ad5\ud446")));
        }
        VUOs.aV(var3_2, rgig$AWxc.r("\u2cfb\u1530"));
        do {
            if (!var1_1.hasNext()) {
                VUOs.aV(var3_2, rgig$AWxc.r("\u2cfb\u1530"));
                return VUOs.aV(var3_2);
            }
            var2_3 = (String)var1_1.next();
            if (VUOs.aV(rgig$AWxc.r("\u2cbe\u156e\u3500\u6414\ufd85\u6a0a\u52a3\ud325\u82d3\ufe10\u2ad5\ud446"), var2_3) != false) continue;
            if (VUOs.aV(rgig$AWxc.r("\u2ca5\u154e\u3535\u6430\ufddd\u6a2f\u52eb\ud314\u82cf\ufe1d\u2adf"), var2_3) != false) continue;
            if (VUOs.aV(rgig$AWxc.r("\u2ca4\u155f\u3535\u6437\ufdc7\u6a32\u52eb\ud307\u82c8\ufe0b\u2adb\ud45b\u4343"), var2_3) != false) continue;
            if (VUOs.aV(rgig$AWxc.r("\u2cbb\u155f\u3520\u642c\ufdc7\u6a38"), var2_3) != false) continue;
            if (VUOs.aV(rgig$AWxc.r("\u2ca4\u155f\u3525\u6431\ufdcd\u6a2f\u52b2\ud37a\u82f5\ufe2b\u2af3"), var2_3) != false) continue;
            if (VUOs.aV(var0, var2_3) != false) continue;
            VUOs.aV(var3_2, var2_3);
            VUOs.aV(var3_2, rgig$AWxc.r("\u2ccc\u151a"));
            VUOs.aV(var3_2, VUOs.aV(var0, var2_3));
            VUOs.aV(var3_2, rgig$AWxc.r("\u2cfb\u1530"));
        } while (true);
    }

    private static Object aV(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

