/*
 * Decompiled with CFR 0_123.
 */
public class ETFk {
    private double LIAQ;

    public ETFk(double d) {
        this.LIAQ = d;
    }

    public int ssbd() {
        return (int)((Double)cv.b(this, 1356854886) / 2.0);
    }

    public double GHqf() {
        return (Double)cv.b(this, 1356854886) / 2.0;
    }

    public double dfwH() {
        return (Double)cv.b(this, 1356854886);
    }

    public int upwg() {
        return (int)((Double)cv.b(this, 1356854886)).doubleValue();
    }
}

