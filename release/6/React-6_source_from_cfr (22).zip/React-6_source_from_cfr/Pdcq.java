/*
 * Decompiled with CFR 0_123.
 */
public interface Pdcq {
    public void ssNb(vswA var1);

    public void KMEw();

    public void dVMt();

    public void fKRe();

    public void aLcY();

    public void ssNb(ndLE var1);

    public wfPa<ndLE> FMwy();

    public SuxL IWbc();
}

