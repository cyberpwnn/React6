/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.map.MapView
 */
import org.bukkit.map.MapView;

public interface QhEF {
    public MapView gotS();

    public YDfo QMsU();

    public void ssNb(ogMI var1);

    public void GjjA();

    public wfPa<ogMI> vbnM();

    public void DYFV(ogMI var1);

    public void destroy();
}

