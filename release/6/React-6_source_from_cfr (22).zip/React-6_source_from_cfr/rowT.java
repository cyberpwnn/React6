/*
 * Decompiled with CFR 0_123.
 */
public class rowT
extends Exception {
    private static final long serialVersionUID = 1;
}

