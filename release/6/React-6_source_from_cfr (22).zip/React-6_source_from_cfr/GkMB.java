/*
 * Decompiled with CFR 0_123.
 */
import java.util.List;

public interface GkMB<T> {
    public void Cnru(T var1);

    public void Cnru(double var1);

    public double rpXo();

    public int loHX();

    public int ssNb(KeoU var1);

    public void LWjo(T var1);

    public void IWSm(List<T> var1);

    public void ssNb(T[] var1);
}

