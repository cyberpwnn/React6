/*
 * Decompiled with CFR 0_123.
 */
public interface YEMO<T> {
    public GHiL AWxc();

    public void set(T var1);

    public T get();
}

