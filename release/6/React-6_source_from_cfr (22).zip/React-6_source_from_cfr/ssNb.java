/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 *  org.bukkit.plugin.Plugin
 */
import java.io.File;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.List;
import org.bukkit.entity.EntityType;
import org.bukkit.plugin.Plugin;

@pXtD
@QNWg
public class ssNb {
    @Cnru(value=0)
    public static final String ssNb = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f7b\u0edc\u725d\u309e\u7c76\u86f2\ueba2\uc437\ua5b3\u40b4\u57fd\u0fff\ue77f\u3eb0\u6f3a\u0112\ue237\uf79d");
    @Cnru(value=1)
    public static final String DYFV = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f7b\u0edc\u725d\u309e\u7c76\u86f2\uebb2\uc428\ua5a7\u40aa\u57bb\u0fbb\ue763\u3ea5\u6f3b\u0109\ue234\uf78f\u8792");
    @Cnru(value=2)
    public static final String IWSm;
    @Cnru(value=3)
    public static final String OXeK;
    @Cnru(value=4)
    public static final String YoSa;
    @Cnru(value=5)
    public static final String jhSt;
    @Cnru(value=6)
    public static final String BkpW;
    @Cnru(value=7)
    public static final String lCdp;
    @Cnru(value=8)
    public static final String nJLQ;
    @Cnru(value=9)
    public static final String vtFs;
    @Cnru(value=10)
    public static final String EmLA;
    @Cnru(value=11)
    public static final String WGJn;
    @Cnru(value=12)
    public static final String TyVf;
    @Cnru(value=13)
    public static final String LGKl;
    @Cnru(value=14)
    public static final String ykmX;
    @Cnru(value=15)
    public static final String rwyd;
    @Cnru(value=16)
    public static final String hHYn;
    @Cnru(value=17)
    public static final String kQcX;
    @Cnru(value=18)
    public static final String rMgK;
    @Cnru(value=19)
    public static final String cIji;
    @Cnru(value=20)
    public static final String Cnru;
    @Cnru(value=21)
    public static final String LWjo;
    @Cnru(value=22)
    public static final String PuYf;
    @Cnru(value=23)
    public static final String TNbD;
    @HKcf(value=0)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=1.0, max=7.0)
    public static int LGKN;
    @HKcf(value=1)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=2.0, max=20.0)
    @CMSR
    public static int NUdB;
    @HKcf(value=2)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=0.5, max=1.998)
    public static double OOtu;
    @HKcf(value=3)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean aLYV;
    @HKcf(value=4)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean Smci;
    @HKcf(value=5)
    @ejGG(HBqU=TNcV.SWAP)
    @CMSR
    public static boolean oVCY;
    @HKcf(value=6)
    @ejGG(HBqU=TNcV.RELOAD)
    @OOtu(min=2.0, max=8.0)
    @JkiO
    @CMSR
    public static int nImU;
    @HKcf(value=7)
    @ejGG(HBqU=TNcV.SUBSTRATE)
    @OOtu(min=1000000.0, max=5.0E7)
    @ktXk
    @CMSR
    public static long KwOT;
    @HKcf(value=8)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean KUKx;
    @HKcf(value=9)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean avmQ;
    @HKcf(value=10)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean CMSR;
    @HKcf(value=11)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean CoXE;
    @HKcf(value=12)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=2.0, max=200.0)
    public static int ftyu;
    @HKcf(value=13)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=10.0, max=200.0)
    public static int mXMK;
    @HKcf(value=14)
    @ejGG(HBqU=TNcV.SWAP)
    public static boolean HBqU;
    @HKcf(value=15)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=1.0, max=16.0)
    public static int NxGC;
    @HKcf(value=16)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=4.0, max=16.0)
    public static int GsQl;
    @HKcf(value=17)
    @ejGG(HBqU=TNcV.SWAP)
    @OOtu(min=1.0, max=2000.0)
    @CMSR
    public static int DXfX;
    @HKcf(value=18)
    @ejGG(HBqU=TNcV.SWAP)
    @CMSR
    public static boolean EmKi;
    @HKcf(value=19)
    @ejGG(HBqU=TNcV.SWAP)
    @CMSR
    public static boolean ejGG;
    @HKcf(value=20)
    @ejGG(HBqU=TNcV.SWAP)
    public static wfPa<String> TNcV;
    @HKcf(value=21)
    @ejGG(HBqU=TNcV.SWAP)
    public static wfPa<String> INcj;
    @HKcf(value=22)
    @ejGG(HBqU=TNcV.SWAP)
    public static wfPa<String> VCgr;
    @HKcf(value=23)
    @ejGG(HBqU=TNcV.SWAP)
    public static wfPa<String> gEXv;
    private static boolean tvRU;
    private static boolean dntE;
    private static boolean RbOr;
    private static /* synthetic */ int[] KCiG;

    static {
        ykmX = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6b\u0ec9\u725f\u3095\u7c78\u86b9\uebb3\uc471\ua5a3\u40b4\u57f7\u0fb0\ue761\u3eb4\u6f3a");
        rwyd = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6b\u0ec9\u725f\u3095\u7c78\u86b9\uebb3\uc471\ua5ab\u40b3\u57f8\u0fbb\ue760\u3ea4\u6f33\u0156\ue225\uf79c\u8791\uf4ca\uec40\u24b9\ua2dc\uf8ab\u9ea9\u5c89");
        hHYn = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6b\u0ec9\u725f\u3095\u7c78\u86b9\uebb3\uc471\ua5b5\u40bf\u57f7\u0fa0\ue76e\u3eb9\u6f73\u0109\ue223\uf78a\u8797\uf4ca\uec43");
        IWSm = rgig$AWxc.r("\ud862\ufea2\u2e05\u07cd\ua04f\u3da4\uac7c\u2f79\u0ede\u7255\u3093\u7c61\u86f2\uebb2\uc42b\ua5a7\u40b9\u57fd\u0fff\ue77f\u3eb0\u6f3a\u0112\ue237\uf79d");
        OXeK = rgig$AWxc.r("\ud862\ufea2\u2e05\u07cd\ua04f\u3da4\uac7c\u2f79\u0ede\u7255\u3093\u7c61\u86f2\uebb2\uc42b\ua5a7\u40b9\u57fd\u0fff\ue769\u3ea3\u6f31\u010b\ue231");
        kQcX = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6b\u0ec9\u725f\u3095\u7c78\u86b9\uebb3\uc471\ua5ab\u40bb\u57ee\u0fff\ue765\u3eb4\u6f3f\u0117\ue236\uf786");
        rMgK = rgig$AWxc.r("\ud861\ufebc\u2e0b\u07ce\ua011\u3df9\uac6c\u2f71\u0ece\u724e\u309a\u7c72\u86a5\uebec\uc43d\ua5aa\u40b5\u57f5\u0fb9\ue77e");
        cIji = rgig$AWxc.r("\ud861\ufebc\u2e0b\u07ce\ua011\u3df9\uac6c\u2f71\u0ece\u724e\u309a\u7c72\u86a5\uebec\uc42f\ua5a7\u40a8\u57e2\u0fbb\ue76e\u3ebd\u6f3b\u0108");
        YoSa = rgig$AWxc.r("\ud862\ufea2\u2e05\u07cd\ua04f\u3da4\uac7c\u2f79\u0ede\u7255\u3093\u7c61\u86f2\uebb4\uc42c\ua5a3\u40f7\u57f2\u0fb7\ue76b\u3eb0\u6f2b\u0117\ue236");
        jhSt = rgig$AWxc.r("\ud862\ufea2\u2e05\u07cd\ua04f\u3da4\uac7c\u2f79\u0ede\u7255\u3093\u7c61\u86f2\uebb2\uc432\ua5a9\u40b5\u57e2\u0fba\ue720\u3ea2\u6f2a\u011a\ue221\uf785");
        Cnru = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6c\u0ec4\u724e\u3093\u7c60\u86f2\ueba0\uc433\ua5aa\u40b5\u57e1\u0fff\ue76e\u3ea4\u6f32\u0117\ue22b\uf780\u8799");
        BkpW = rgig$AWxc.r("\ud872\ufeb8\u2e18\u07d8\ua003\u3db3\uac7b\u2f36\u0ecd\u7251\u3099\u7c7f\u86f1\uebb2\uc436\ua5bc\u40bf");
        lCdp = rgig$AWxc.r("\ud872\ufeb8\u2e18\u07d8\ua003\u3db3\uac7b\u2f36\u0ed3\u725f\u3098\u7c7c\u86f1\uebac\uc436\ua5b2\u40b3\u57f1\u0fb3\ue779\u3eb8\u6f31\u0115");
        nJLQ = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f7b\u0edc\u725d\u309e\u7c76\u86f2\ueba4\uc431\ua5a7\u40b8\u57fa\u0fb7\ue720\u3eb2\u6f3f\u0118\ue22a\uf787\u8790\uf4d8");
        LWjo = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6c\u0ec4\u724e\u3093\u7c60\u86f2\ueba0\uc433\ua5aa\u40b5\u57e1\u0fff\ue77d\u3ea4\u6f2c\u011c\ue22b\uf780\u8799");
        PuYf = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f6c\u0ec4\u724e\u3093\u7c60\u86f2\ueba0\uc433\ua5aa\u40b5\u57e1\u0fff\ue76e\u3eb0\u6f3d\u0113\ue22b\uf780\u8799");
        TNbD = rgig$AWxc.r("\ud863\ufebe\u2e1e\u07d4\ua016\u3dae\uac25\u2f7b\u0ec8\u7252\u309a\u7c76\u86ae\uebef\uc42d\ua5b3\u40b6\u57f3\u0fa1");
        vtFs = rgig$AWxc.r("\ud860\ufeb1\u2e19\u07c9\ua04f\u3dbb\uac6d\u2f79\u0edb\u7213\u3092\u7c76\u86bf\ueba0\uc426\ua5e8\u40bf\u57f8\u0fb3\ue76f\u3ebd\u6f3b\u011f");
        EmLA = rgig$AWxc.r("\ud860\ufeb1\u2e19\u07c9\ua04f\u3dbb\uac6d\u2f79\u0edb\u7213\u3092\u7c76\u86bf\ueba0\uc426\ua5e8\u40ae\u57e4\u0fbb\ue76a\u3eb6\u6f3b\u0109\ue26f\uf781\u8790\uf492\uec54\u24f1\ua2cc\uf8a3\u9eaa");
        WGJn = rgig$AWxc.r("\ud860\ufeb1\u2e19\u07c9\ua04f\u3dbb\uac6d\u2f79\u0edb\u7213\u3092\u7c76\u86bf\ueba0\uc426\ua5e8\u40b3\u57f8\u0fa1\ue779\u3eb0\u6f30\u010f\ue223\uf780\u879b\uf4d0\uec45\u24e7");
        TyVf = rgig$AWxc.r("\ud860\ufeb1\u2e19\u07c9\ua04f\u3dbb\uac6d\u2f79\u0edb\u7213\u3092\u7c76\u86bf\ueba0\uc426\ua5e8\u40be\u57f3\u0fb1\ue76c\u3ea8\u6f73\u010b\ue227\uf79c\u8797\uf4d0\uec54");
        LGKl = rgig$AWxc.r("\ud862\ufea2\u2e05\u07cd\ua04f\u3da4\uac7c\u2f79\u0ede\u7255\u3093\u7c61\u86f2\uebac\uc436\ua5a8\u40b3\u57fb\u0fa7\ue760\u3efc\u6f3f\u011c\ue227\uf7c3\u878a\uf4d6\uec53\u24ff\ua2dc");
        cv.V(-116387399, 3);
        cv.V(234623352, 2);
        cv.V(-2136927877, 1.5);
        cv.V(1163268474, true);
        cv.V(845287781, false);
        cv.V(-2114907804, false);
        cv.V(1624248679, 4);
        cv.V(-1396371098, 5000000);
        cv.V(1030754657, false);
        cv.V(114168160, true);
        cv.V(422449507, true);
        cv.V(1822167394, false);
        cv.V(728174957, 20);
        cv.V(-1506471572, 70);
        cv.V(1575358831, true);
        cv.V(367333742, 6);
        cv.V(560271721, 6);
        cv.V(1402867829, 2000);
        cv.V(-1873276568, true);
        cv.V(213913963, false);
        cv.V(2070942058, ssNb.DYFV());
        cv.V(1630343509, ssNb.IWSm());
        cv.V(-163770028, ssNb.ssNb());
        cv.V(-680062633, ssNb.OXeK());
        cv.V(-1914171050, false);
        cv.V(514593105, false);
        cv.V(-1818947248, false);
    }

    @sHhL
    public static void ssNb(Plugin plugin) {
        File file = new File(plugin.getDataFolder(), YEBy$TyVf.W("\ud129\ueacb\ub28b\uf393\u36a6\u3a69\u57e5\u7b88\ua187\u3772"));
        File file2 = new File(plugin.getDataFolder(), YEBy$TyVf.W("\ud129\ueacb\ub28b\uf393\u36a6\u3a69\u57e6\u7b94\ua192\u376e\ua12c\u4837\u3721\u2b9b\u9baf\ub8a3\u6ad9\u547c\ua5b9\ud1c5\u9fa2\uacda\ue323"));
        ssNb$1 ssNb$1 = new ssNb$1(file, file2, plugin);
        ssNb.uC(ssNb.uC(), file, ssNb$1);
        ssNb.uC(ssNb.uC(), file2, ssNb$1);
    }

    @nRmP
    public static void DYFV(Plugin plugin) {
        Exception exception;
        File file = new File(plugin.getDataFolder(), YEBy$TyVf.W("\u6518\u7483\u0a59\u44f0\ua2d5\u90c1\u68fb\u5658\u4311\u8ed8"));
        File file2 = new File(plugin.getDataFolder(), YEBy$TyVf.W("\u6518\u7483\u0a59\u44f0\ua2d5\u90c1\u68f8\u5644\u4304\u8ec4\u2329\u63cc\uade2\u447f\u710a\uda2a\ufd62\u5005\u4636\u35bc\u448c\u1bb0\u6afd"));
        try {
            ssNb.ssNb(file, false);
        }
        catch (Exception exception2) {
            exception = exception2;
            ssNb.uC(exception2);
        }
        try {
            ssNb.ssNb(file2, true);
            return;
        }
        catch (Exception exception3) {
            exception = exception3;
            ssNb.uC(exception3);
            return;
        }
    }

    private static void ssNb(File file, boolean bl) throws IllegalArgumentException, IllegalAccessException {
        if (ssNb.uC(file) == false) {
            ssNb.uC(new kkcI(), ssNb.ssNb(bl), file);
        }
        ssNb.uC(new kkcI(), ssNb.ssNb((QFEs)ssNb.uC(new YoaF(), file), bl), file);
        try {
            if (((Boolean)cv.e(-1914171050)).booleanValue()) {
                if (((Boolean)cv.e(-1818947248)).booleanValue()) {
                    ssNb.uC();
                    cv.V(-1914171050, false);
                } else if (((Boolean)cv.e(514593105)).booleanValue()) {
                    ssNb.uC();
                }
            }
        }
        catch (Exception exception) {
            // empty catch block
        }
        cv.V(-1914171050, true);
    }

    private static QFEs ssNb(QFEs qFEs, boolean bl) throws IllegalArgumentException, IllegalAccessException {
        QFEs qFEs2 = new QFEs();
        Field[] arrfield = (Field[])ssNb.uC(ssNb.class);
        int n = arrfield.length;
        int n2 = 0;
        while (n2 < n) {
            block18 : {
                Object object;
                String string;
                Field field;
                block19 : {
                    block17 : {
                        field = arrfield[n2];
                        if (ssNb.uC(field, CMSR.class) != false && bl) break block17;
                        if (ssNb.uC(field, CMSR.class) != false || bl) break block18;
                    }
                    if (ssNb.uC(field, HKcf.class) == false) break block18;
                    int n3 = ((HKcf)ssNb.uC(field, HKcf.class)).value();
                    string = null;
                    object = (Field[])ssNb.uC(ssNb.class);
                    int n4 = object.length;
                    int n5 = 0;
                    while (n5 < n4) {
                        Field field2 = object[n5];
                        if (ssNb.uC(field2, Cnru.class) != false) {
                            if (n3 == ((Cnru)ssNb.uC(field2, Cnru.class)).value()) {
                                string = (String)ssNb.uC(field2, null);
                                break;
                            }
                        }
                        ++n5;
                    }
                    if (string != null) break block19;
                    ssNb.uC(ssNb.uC(ssNb.uC(new StringBuilder(rgig$AWxc.r("\u93e7\u298e\uc636\uc0d3\u711c\ud73f\u4a1c\u2c91\uca1a\u4a3f\u250a\ub5e0\ua28d\ua2e2\u9ac3\u779c\u47f8\u8def\u95a8\ua2be\uafe6\u2f08\u4fc6\u3f3c\u3ffd\u16c5\u40af\u648a\u6010")), ssNb.uC(field))));
                    break block18;
                }
                boolean bl2 = false;
                Object object2 = ssNb.uC(ssNb.uC(qFEs));
                while (object2.hasNext()) {
                    String string2;
                    block20 : {
                        block26 : {
                            block25 : {
                                block24 : {
                                    block23 : {
                                        block22 : {
                                            block21 : {
                                                string2 = (String)object2.next();
                                                if (ssNb.uC(string2, string) == false) continue;
                                                bl2 = true;
                                                if (ssNb.uC(field, OOtu.class) == false) break block20;
                                                object = (OOtu)ssNb.uC(field, OOtu.class);
                                                if (ssNb.uC(ssNb.uC(field), Integer.class) != false) break block21;
                                                if (ssNb.uC(ssNb.uC(field), (Class)cv.e(1035866500)) == false) break block22;
                                            }
                                            ssNb.uC(field, null, ssNb.uC(ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max())));
                                            ssNb.uC(qFEs2, string, ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max()));
                                            continue;
                                        }
                                        if (ssNb.uC(ssNb.uC(field), Double.class) != false) break block23;
                                        if (ssNb.uC(ssNb.uC(field), (Class)cv.e(-452783744)) == false) break block24;
                                    }
                                    ssNb.uC(field, null, ssNb.uC(ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max())));
                                    ssNb.uC(qFEs2, string, ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max()));
                                    continue;
                                }
                                if (ssNb.uC(ssNb.uC(field), Long.class) != false) break block25;
                                if (ssNb.uC(ssNb.uC(field), (Class)cv.e(803410317)) == false) break block26;
                            }
                            ssNb.uC(field, null, ssNb.uC(ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max())));
                            ssNb.uC(qFEs2, string, ssNb.uC(ssNb.uC(qFEs, string2), object.min(), object.max()));
                            continue;
                        }
                        ssNb.uC(ssNb.uC(ssNb.uC(ssNb.uC(ssNb.uC(ssNb.uC(new StringBuilder(rgig$AWxc.r("\u93e2\u298e\uc631\uc0d1\u7116\ud72f\u4a1c\u2c86\uca19\u4a76\u251c\ub5a9")), string), rgig$AWxc.r("\u9381\u29c7")), ssNb.uC(ssNb.uC(field))), rgig$AWxc.r("\u9388"))));
                        ssNb.uC(field, null, ssNb.uC(qFEs, string2));
                        ssNb.uC(qFEs2, string, ssNb.uC(qFEs, string2));
                        continue;
                    }
                    if (ssNb.uC(qFEs, string2) instanceof List) {
                        ssNb.uC(field, null, new wfPa((List)ssNb.uC(qFEs, string2)));
                        ssNb.uC(qFEs2, string, ssNb.uC(qFEs, string2));
                        continue;
                    }
                    ssNb.uC(field, null, ssNb.uC(qFEs, string2));
                    ssNb.uC(qFEs2, string, ssNb.uC(qFEs, string2));
                }
                if (!bl2) {
                    ssNb.uC(ssNb.uC(ssNb.uC(new StringBuilder(rgig$AWxc.r("\u93e0\u298b\uc63b\uc0d6\u7117\ud73c\u4a1c\u2c8b\uca10\u4a68\u254c\ub5e2\ua286\ua2ff\u9ad9\u77d7")), string)));
                    ssNb.uC(qFEs2, string, ssNb.uC(field, null));
                }
            }
            ++n2;
        }
        if (ssNb.uC() != false) {
            ssNb.uC((cAai)cv.b((YoSa)cv.e(239341894), -865660607));
        }
        return qFEs2;
    }

    private static QFEs ssNb(boolean bl) throws IllegalArgumentException, IllegalAccessException {
        QFEs qFEs = new QFEs();
        Field[] arrfield = (Field[])ssNb.uC(ssNb.class);
        int n = arrfield.length;
        int n2 = 0;
        while (n2 < n) {
            block11 : {
                Field field;
                block10 : {
                    field = arrfield[n2];
                    if (ssNb.uC(field, CMSR.class) != false && bl) break block10;
                    if (ssNb.uC(field, CMSR.class) != false || bl) break block11;
                }
                if (ssNb.uC(field, HKcf.class) != false) {
                    int n3 = ((HKcf)ssNb.uC(field, HKcf.class)).value();
                    Object object = ssNb.uC(field, null);
                    String string = null;
                    Field[] arrfield2 = (Field[])ssNb.uC(ssNb.class);
                    int n4 = arrfield2.length;
                    int n5 = 0;
                    while (n5 < n4) {
                        Field field2 = arrfield2[n5];
                        if (ssNb.uC(field2, Cnru.class) != false) {
                            if (n3 == ((Cnru)ssNb.uC(field2, Cnru.class)).value()) {
                                string = (String)ssNb.uC(field2, null);
                                break;
                            }
                        }
                        ++n5;
                    }
                    if (string == null) {
                        ssNb.uC(ssNb.uC(ssNb.uC(new StringBuilder(rgig$AWxc.r("\u93e7\u298e\uc636\uc0d3\u711c\ud73f\u4a1c\u2c91\uca1a\u4a3f\u250a\ub5e0\ua28d\ua2e2\u9ac3\u779c\u47f8\u8def\u95a8\ua2be\uafe6\u2f08\u4fc6\u3f3c\u3ffd\u16c5\u40af\u648a\u6010")), ssNb.uC(field))));
                    } else {
                        ssNb.uC(qFEs, string, object);
                    }
                }
            }
            ++n2;
        }
        return qFEs;
    }

    private static wfPa<String> ssNb() {
        wfPa<String> wfPa2 = new wfPa<String>();
        EntityType[] arrentityType = (EntityType[])ssNb.uC();
        int n = arrentityType.length;
        int n2 = 0;
        while (n2 < n) {
            EntityType entityType = arrentityType[n2];
            switch (ssNb.YoSa()[ssNb.uC(entityType)]) {
                case 88: {
                    break;
                }
                case 3: {
                    break;
                }
                case 39: {
                    break;
                }
                case 10: {
                    break;
                }
                case 18: {
                    break;
                }
                case 89: {
                    break;
                }
                case 26: {
                    break;
                }
                case 7: {
                    break;
                }
                case 83: {
                    break;
                }
                case 19: {
                    break;
                }
                case 14: {
                    break;
                }
                case 15: {
                    break;
                }
                case 87: {
                    break;
                }
                case 91: {
                    break;
                }
                case 90: {
                    break;
                }
                case 17: {
                    break;
                }
                case 16: {
                    break;
                }
                case 24: {
                    break;
                }
                case 25: {
                    break;
                }
                case 33: {
                    break;
                }
                case 2: {
                    break;
                }
                case 11: {
                    break;
                }
                case 12: {
                    break;
                }
                case 13: {
                    break;
                }
                case 22: {
                    break;
                }
                case 20: {
                    break;
                }
                case 86: {
                    break;
                }
                case 84: {
                    break;
                }
                case 8: {
                    break;
                }
                default: {
                    ssNb.uC(wfPa2, ssNb.uC(entityType));
                }
            }
            ++n2;
        }
        return wfPa2;
    }

    private static wfPa<String> DYFV() {
        wfPa<String> wfPa2 = new wfPa<String>();
        EntityType[] arrentityType = (EntityType[])ssNb.uC();
        int n = arrentityType.length;
        int n2 = 0;
        while (n2 < n) {
            EntityType entityType = arrentityType[n2];
            switch (ssNb.YoSa()[ssNb.uC(entityType)]) {
                case 88: {
                    break;
                }
                case 3: {
                    break;
                }
                case 39: {
                    break;
                }
                case 10: {
                    break;
                }
                case 18: {
                    break;
                }
                case 89: {
                    break;
                }
                case 26: {
                    break;
                }
                case 7: {
                    break;
                }
                case 83: {
                    break;
                }
                case 19: {
                    break;
                }
                case 14: {
                    break;
                }
                case 15: {
                    break;
                }
                case 87: {
                    break;
                }
                case 91: {
                    break;
                }
                case 90: {
                    break;
                }
                case 17: {
                    break;
                }
                case 16: {
                    break;
                }
                case 24: {
                    break;
                }
                case 25: {
                    break;
                }
                case 33: {
                    break;
                }
                case 2: {
                    break;
                }
                case 11: {
                    break;
                }
                case 12: {
                    break;
                }
                case 13: {
                    break;
                }
                case 22: {
                    break;
                }
                case 20: {
                    break;
                }
                case 86: {
                    break;
                }
                case 84: {
                    break;
                }
                case 8: {
                    break;
                }
                default: {
                    ssNb.uC(wfPa2, ssNb.uC(entityType));
                }
            }
            ++n2;
        }
        return wfPa2;
    }

    private static wfPa<String> IWSm() {
        wfPa<String> wfPa2 = new wfPa<String>();
        EntityType[] arrentityType = (EntityType[])ssNb.uC();
        int n = arrentityType.length;
        int n2 = 0;
        while (n2 < n) {
            EntityType entityType = arrentityType[n2];
            switch (ssNb.YoSa()[ssNb.uC(entityType)]) {
                case 88: {
                    break;
                }
                case 18: {
                    break;
                }
                case 89: {
                    break;
                }
                case 87: {
                    break;
                }
                case 91: {
                    break;
                }
                case 2: {
                    break;
                }
                case 20: {
                    break;
                }
                case 86: {
                    break;
                }
                case 84: {
                    break;
                }
                case 8: {
                    break;
                }
                default: {
                    ssNb.uC(wfPa2, ssNb.uC(entityType));
                }
            }
            ++n2;
        }
        return wfPa2;
    }

    private static wfPa<String> OXeK() {
        wfPa<String> wfPa2 = ssNb.DYFV();
        wfPa<String> wfPa3 = new wfPa<String>();
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8876\u6d61\ue642\u01d9\ub71f\ubf4a\u12a1\u9d66\ubba2\u5e50\ufb87\ubc7e"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8860\u6d61\ue642\u01c9\ub71e\ubf0f\u12cf\u9d53\ubbae\u5e58\ufb86"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8860\u6d61\ue642\u01c9\ub71e\ubf0f\u12cd\u9d57\ubba2\u5e4e\ufb8a\ubc7f\u18c8"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8860\u6d61\ue642\u01c9\ub71e\ubf0f\u12d2\u9d46\ubba2\u5e5e\ufb89\ubc7f\u18c8"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8860\u6d61\ue642\u01c9\ub71e\ubf0f\u12d3\u9d5b\ubba7\u5e59\ufb87\ubc74"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8876\u6d61\ue657\u01d8\ub71e\ubf46\u12e2\u9d46\ubbe3\u5e6d\ufb8b\ubc7d\u1880\u80d5\uc358\ubc48\u5286\ua1d6\ua700\u2946\ue6e3\uf602\u7a2e\u9068\uebe2\u3ab0\u71a2\u6476\u32a3\u13b0\u244f\u04a2\udf59\u00e9\u7ee9"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8876\u6d61\ue657\u01d8\ub71e\ubf46\u12e2\u9d46\ubbe3\u5e67\ufb8d\ubc77\u18ce\u80ff\uc352\ubc13\u52f9\ua1f5\ua701\u2947\ue6e3\uf600\u7a2e\u9078\uebe1\u3abc\u71ad\u6478\u32b2\u13b1\u2401\u04b3\udf3a\u00aa\u7ebe\u4dd1\uced3\ub0bd\u8efe\u20b6\ube47\u79b8\u48a2\u7d35"));
        ssNb.uC(wfPa3, YEBy$TyVf.W("\ueafe\u8876\u6d61\ue657\u01d8\ub71e\ubf46\u12e2\u9d46\ubbe3\u5e6a\ufb8d\ubc76\u18ca\u80ba\uc378\ubc5c\u52cf\ua1e9\ua707\u2957\ue6aa\uf63a\u7a6d\u9059\uebf9\u3abc\u71e1\u6420\u32e6\u13e9"));
        Object object = ssNb.uC(wfPa2);
        while (object.hasNext()) {
            String string = (String)object.next();
            int n = 7;
            if (ssNb.uC(ssNb.uC(string), YEBy$TyVf.W("\ueae8\u886d\u6d48\ue668\u01ed\ub72b\ubf6a\u12d3")) != false) {
                n = 10;
            }
            if (ssNb.uC(ssNb.uC(string), YEBy$TyVf.W("\ueafa\u8876\u6d4b\ue674\u01fc\ub729\ubf6b\u12de\u9d7b\ubb97\u5e78\ufbaf")) != false) {
                n = 30;
            }
            ssNb.uC(wfPa3, ssNb.uC(ssNb.uC(ssNb.uC(ssNb.uC(new StringBuilder(YEBy$TyVf.W("\ueafe\u8876\u6d61\ue657\u01d8\ub71e\ubf46\u12e2\u9d46\ubbe3")), ssNb.uC(ssNb.uC(ssNb.uC(string), YEBy$TyVf.W("\ueae1"), YEBy$TyVf.W("\uea9e")))), YEBy$TyVf.W("\uea9e\u8819\u6d24")), n)));
        }
        return wfPa3;
    }

    static /* synthetic */ int[] YoSa() {
        int[] arrn;
        int[] arrn2 = (int[])cv.e(-81522314);
        if (arrn2 != null) {
            return arrn2;
        }
        arrn = new int[((EntityType[])ssNb.uC()).length];
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1322652101))] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1645276815))] = 30;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-919858745))] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-590278288))] = 61;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1128534387))] = 57;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)917377476))] = 39;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1025371790))] = 55;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1532948099))] = 69;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1760498113))] = 89;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1060508028))] = 68;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1337069951))] = 46;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1936387714))] = 31;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)873927104))] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-674426503))] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1043337667))] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-803729352))] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1213788101))] = 54;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1466830906))] = 63;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)297406914))] = 83;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)558567461))] = 59;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1552749004))] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-553840177))] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-80932828))] = 34;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-663154249))] = 33;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)267653558))] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-374468569))] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)282005936))] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)579735986))] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)684789798))] = 85;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-360706015))] = 52;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1438445536))] = 49;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1248268323))] = 64;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)2102399010))] = 76;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)296423469))] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)2066878508))] = 37;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1002434513))] = 75;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-792522298))] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-707391042))] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1519447620))] = 86;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1134620225))] = 84;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-157151186))] = 79;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-162262999))] = 80;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)744755240))] = 58;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)517869611))] = 40;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1858531286))] = 41;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-329445355))] = 38;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1454575636))] = 42;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-2057498601))] = 44;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1721561066))] = 45;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-247525359))] = 43;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-2008543216))] = 32;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-56946669))] = 72;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)651759634))] = 74;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-517795811))] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-333574116))] = 81;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1058017311))] = 66;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1067913246))] = 53;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-209907400))] = 88;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1248595993))] = 78;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1581706819))] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-507637672))] = 77;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)318247003))] = 67;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)825888858))] = 65;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1943998900))] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1134751675))] = 56;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1025503164))] = 47;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-86306745))] = 28;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)530452550))] = 51;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1650135475))] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-912846415))] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1544875967))] = 73;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)2096632245))] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-2003169216))] = 48;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1887759926))] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-19394493))] = 70;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)710217794))] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)952570315))] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)374673864))] = 90;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)2141262281))] = 91;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-946073523))] = 35;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)2047610956))] = 82;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1009127503))] = 36;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1317409230))] = 87;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)926486606))] = 62;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1325600841))] = 60;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)1121062984))] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1770909235))] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)299176011))] = 71;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-1972694966))] = 50;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)791416885))] = 29;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[ssNb.uC((EntityType)cv.e((int)-2102718412))] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        int[] arrn3 = arrn;
        cv.V(-81522314, arrn3);
        return arrn3;
    }

    private static Object uC(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

