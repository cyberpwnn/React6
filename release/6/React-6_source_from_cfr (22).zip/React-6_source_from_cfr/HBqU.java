/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import org.bukkit.command.CommandSender;

public interface HBqU {
    public String getCommand();

    public String[] PuYf();

    public String[] TNbD();

    public String getUsage();

    public String getDescription();

    public OikN LGKN();

    public void ssNb(CommandSender var1, String[] var2);
}

