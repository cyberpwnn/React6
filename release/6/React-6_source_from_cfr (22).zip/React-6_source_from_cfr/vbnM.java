/*
 * Decompiled with CFR 0_123.
 */
public class vbnM<T>
implements YEMO<T> {
    private GHiL TrIH;
    private T lLpl;

    protected vbnM(GHiL gHiL, T t) {
        this.TrIH = gHiL;
        this.set(t);
    }

    @Override
    public GHiL AWxc() {
        return (GHiL)((Object)cv.b(this, -1340935643));
    }

    @Override
    public void set(T t) {
        cv.e(this, 695005732, t);
    }

    @Override
    public T get() {
        return (T)cv.b(this, 695005732);
    }
}

