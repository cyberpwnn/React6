/*
 * Decompiled with CFR 0_123.
 */
final class JbuU$nJLQ$ssNb
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public JbuU$nJLQ$ssNb(String string, Throwable throwable) {
        super(string, throwable);
    }
}

