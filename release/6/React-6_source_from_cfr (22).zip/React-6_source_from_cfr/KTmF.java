/*
 * Decompiled with CFR 0_123.
 */
public class KTmF
extends Exception {
    private static final long serialVersionUID = 1534063601762229856L;

    public KTmF(String string) {
        super(string);
    }

    public KTmF() {
    }
}

