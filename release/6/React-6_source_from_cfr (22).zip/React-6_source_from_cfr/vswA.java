/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public final class vswA
extends Enum<vswA> {
    public static final /* enum */ vswA UKWi;
    public static final /* enum */ vswA gqoD;
    public static final /* enum */ vswA sBMB;
    public static final /* enum */ vswA GdRj;
    public static final /* enum */ vswA EoNX;
    public static final /* enum */ vswA BLRp;
    public static final /* enum */ vswA qfYp;
    public static final /* enum */ vswA kKWD;
    public static final /* enum */ vswA bHkv;
    public static final /* enum */ vswA ayOG;
    public static final /* enum */ vswA NWeW;
    public static final /* enum */ vswA ekjr;
    public static final /* enum */ vswA oyiT;
    public static final /* enum */ vswA SVUv;
    public static final /* enum */ vswA BLUC;
    public static final /* enum */ vswA GJcF;
    public static final /* enum */ vswA FOoo;
    public static final /* enum */ vswA ChjN;
    public static final /* enum */ vswA HMfN;
    public static final /* enum */ vswA RctL;
    public static final /* enum */ vswA plKO;
    public static final /* enum */ vswA KFNi;
    public static final /* enum */ vswA ARBY;
    public static final /* enum */ vswA cKrb;
    public static final /* enum */ vswA yUBt;
    public static final /* enum */ vswA GlfX;
    public static final /* enum */ vswA MnXJ;
    public static final /* enum */ vswA fCyt;
    public static final /* enum */ vswA twwC;
    public static final /* enum */ vswA htso;
    public static final /* enum */ vswA RdVC;
    public static final /* enum */ vswA msbe;
    public static final /* enum */ vswA Ascu;
    public static final /* enum */ vswA QOoj;
    public static final /* enum */ vswA tNCs;
    public static final /* enum */ vswA kdjc;
    public static final /* enum */ vswA NWfb;
    public static final /* enum */ vswA YhhB;
    public static final /* enum */ vswA YqYO;
    public static final /* enum */ vswA pkjB;
    public static final /* enum */ vswA RdSo;
    public static final /* enum */ vswA fCxa;
    public static final /* enum */ vswA qoNL;
    public static final /* enum */ vswA XnUa;
    public static final /* enum */ vswA whMw;
    public static final /* enum */ vswA VElA;
    public static final /* enum */ vswA YXGO;
    public static final /* enum */ vswA uGtI;
    public static final /* enum */ vswA wgmB;
    public static final /* enum */ vswA dyiL;
    public static final /* enum */ vswA jixD;
    public static final /* enum */ vswA tNBw;
    public static final /* enum */ vswA XKqs;
    public static final /* enum */ vswA HxYe;
    private int version;
    private String kTLt;
    private String GlhC;
    private boolean igXj;
    private static final /* synthetic */ vswA[] EfbD;

    static {
        cv.V(-640289277, (Object)new vswA(YEBy$TyVf.W("\u0ab4\u3e34\u3b50\u2747\ucd19\u43e8"), 0, 10000, YEBy$TyVf.W("\u0ab4\u3e14\u3b70\u2767\ucd39\u43c8")));
        cv.V(1181152770, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd78\u43e3\u9ccf"), 1, 340, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2730\ucd64\u438e"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd78\u43e3\u9caf\u01c9")));
        cv.V(455144973, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd78\u43e3\u9ccf\u01a7\u462b\u11f8\u10ee"), 2, 339, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2730\ucd64\u438e\u9cd0\u01a8\u4629\u11ef"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd78\u43e3\u9caf\u01c9")));
        cv.V(-1015155188, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd78\u43e3\u9ccc"), 3, 338, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2730\ucd64\u438d"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd78\u43e3\u9caf\u01c9")));
        cv.V(-1796803057, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd78"), 4, 335, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2730"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd78\u43e3\u9caf\u01c9")));
        cv.V(1474229774, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7b\u43e3\u9ccf"), 5, 316, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2733\ucd64\u438e"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7b\u43e3\u9caf\u01c9")));
        cv.V(1069086217, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7b\u43e3\u9ccc"), 6, 316, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2733\ucd64\u438d"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7b\u43e3\u9caf\u01c9")));
        cv.V(-732432888, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7b"), 7, 315, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2733"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7b\u43e3\u9caf\u01c9")));
        cv.V(917042699, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7a\u43e3\u9ccf"), 8, 210, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2732\ucd64\u438e"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7a\u43e3\u9caf\u01c9")));
        cv.V(-1347750390, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7a\u43e3\u9ccc"), 9, 210, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2732\ucd64\u438d"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7a\u43e3\u9caf\u01c9")));
        cv.V(-101648395, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2733\ucd7a"), 10, 210, YEBy$TyVf.W("\u0ac9\u3e5b\u3b35\u2732"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u2733\ucd7a\u43e3\u9caf\u01c9")));
        cv.V(-816187404, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273b\ucd15\u4388"), 11, 110, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3d\u272c\ucd7e"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273b\ucd15\u43ee\u9ccf")));
        cv.V(1895888887, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273b\ucd15\u438f"), 12, 110, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3d\u272c\ucd79"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273b\ucd15\u43ee\u9ccf")));
        cv.V(-39913482, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273b\ucd15\u438e"), 13, 109, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3d\u272c\ucd78"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273b\ucd15\u43ee\u9ccc")));
        cv.V(-291702799, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273b\ucd15\u438d"), 14, 108, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3d\u272c\ucd7b"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273b\ucd15\u43ee\u9ccc")));
        cv.V(1009842160, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273b"), 15, 107, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3d"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273b\ucd15\u43ee\u9ccc")));
        cv.V(-441845773, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u4385"), 16, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd73"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(-158730254, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u4384"), 17, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd72"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(1804269565, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u438b"), 18, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd7d"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(885192700, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u438a"), 19, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd7c"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(1981675519, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u4389"), 20, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd7f"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(-1483933698, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u4388"), 21, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd7e"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(841480185, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u438f"), 22, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd79"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(1923676344, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u438e"), 23, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd78"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(-489359173, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a\ucd15\u438d"), 24, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c\u272c\ucd7b"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(-1392772934, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u273a"), 25, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b3c"), YEBy$TyVf.W("\u0a8e\u3e44\u3b5b\u273a\ucd15\u43ee\u9cce")));
        cv.V(946469029, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438d\u9ccd"), 26, 5, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7b\u438c")));
        cv.V(-1602815836, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u4385"), 27, 5, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd73")));
        cv.V(-514459481, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u4384"), 28, 5, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd72")));
        cv.V(666564774, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438b"), 29, 5, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7d")));
        cv.V(1170012321, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438a"), 30, 5, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7c")));
        cv.V(-1939801952, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u4389"), 31, 4, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7f")));
        cv.V(920189091, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u4388"), 32, 4, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7e")));
        cv.V(739965090, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438f"), 33, 4, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd79")));
        cv.V(-1167132499, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438e"), 34, 4, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd78")));
        cv.V(1895233708, (Object)new vswA(YEBy$TyVf.W("\u0aaa\u3e44\u3b5b\u2735\ucd15\u438d"), 35, 4, YEBy$TyVf.W("\u0ac9\u3e5b\u3b33\u272c\ucd7b")));
        cv.V(-1479018321, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2734\ucd15\u4388"), 36, 78, YEBy$TyVf.W("\u0ac9\u3e5b\u3b32\u272c\ucd7e"), true));
        cv.V(1188427950, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2734\ucd15\u438f"), 37, 77, YEBy$TyVf.W("\u0ac9\u3e5b\u3b32\u272c\ucd79"), true));
        cv.V(1974925481, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2734\ucd15\u438e"), 38, 74, YEBy$TyVf.W("\u0ac9\u3e5b\u3b32\u272c\ucd78"), true));
        cv.V(612694184, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2734\ucd15\u438d"), 39, 73, YEBy$TyVf.W("\u0ac9\u3e5b\u3b32\u272c\ucd7b"), true));
        cv.V(787478699, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2737\ucd15\u438e"), 40, 61, YEBy$TyVf.W("\u0ac9\u3e5b\u3b31\u272c\ucd78"), true));
        cv.V(1275132074, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2737\ucd15\u438d"), 41, 60, YEBy$TyVf.W("\u0ac9\u3e5b\u3b31\u272c\ucd7b"), true));
        cv.V(1581250709, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2737"), 42, 60, YEBy$TyVf.W("\u0ac9\u3e5b\u3b31"), true));
        cv.V(190052500, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2736\ucd15\u438b"), 43, 51, YEBy$TyVf.W("\u0ac9\u3e5b\u3b30\u272c\ucd7d"), true));
        cv.V(709490839, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2736\ucd15\u438a"), 44, 51, YEBy$TyVf.W("\u0ac9\u3e5b\u3b30\u272c\ucd7c"), true));
        cv.V(1364850838, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2736\ucd15\u4389"), 45, 49, YEBy$TyVf.W("\u0ac9\u3e5b\u3b30\u272c\ucd7f"), true));
        cv.V(-997918575, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2736\ucd15\u4388"), 46, 49, YEBy$TyVf.W("\u0ac9\u3e5b\u3b30\u272c\ucd7e"), true));
        cv.V(-951388016, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2736\ucd15\u438e"), 47, 47, YEBy$TyVf.W("\u0ac9\u3e5b\u3b30\u272c\ucd78"), true));
        cv.V(-1967392621, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2731\ucd15\u438e"), 48, 39, YEBy$TyVf.W("\u0ac9\u3e5b\u3b37\u272c\ucd78"), true));
        cv.V(-162727790, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2731\ucd15\u438d"), 49, 39, YEBy$TyVf.W("\u0ac9\u3e5b\u3b37\u272c\ucd7b"), true));
        cv.V(2007562397, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2730\ucd15\u4389"), 50, 29, YEBy$TyVf.W("\u0ac9\u3e5b\u3b36\u272c\ucd7f"), true));
        cv.V(-301139812, (Object)new vswA(YEBy$TyVf.W("\u0aba\u3e44\u3b5b\u2730\ucd15\u4388"), 51, 29, YEBy$TyVf.W("\u0ac9\u3e5b\u3b36\u272c\ucd7e"), true));
        cv.V(2037840031, (Object)new vswA(YEBy$TyVf.W("\u0abd\u3e34\u3b56\u274e\ucd03\u43f9\u9cae\u01ac"), 52, 0));
        cv.V(-597362530, (Object)new vswA(YEBy$TyVf.W("\u0aad\u3e3b\u3b4f\u274c\ucd05\u43eb\u9cb3"), 53, -10000));
        cv.V(1914370201, new vswA[]{(vswA)((Object)cv.e(-640289277)), (vswA)((Object)cv.e(1181152770)), (vswA)((Object)cv.e(455144973)), (vswA)((Object)cv.e(-1015155188)), (vswA)((Object)cv.e(-1796803057)), (vswA)((Object)cv.e(1474229774)), (vswA)((Object)cv.e(1069086217)), (vswA)((Object)cv.e(-732432888)), (vswA)((Object)cv.e(917042699)), (vswA)((Object)cv.e(-1347750390)), (vswA)((Object)cv.e(-101648395)), (vswA)((Object)cv.e(-816187404)), (vswA)((Object)cv.e(1895888887)), (vswA)((Object)cv.e(-39913482)), (vswA)((Object)cv.e(-291702799)), (vswA)((Object)cv.e(1009842160)), (vswA)((Object)cv.e(-441845773)), (vswA)((Object)cv.e(-158730254)), (vswA)((Object)cv.e(1804269565)), (vswA)((Object)cv.e(885192700)), (vswA)((Object)cv.e(1981675519)), (vswA)((Object)cv.e(-1483933698)), (vswA)((Object)cv.e(841480185)), (vswA)((Object)cv.e(1923676344)), (vswA)((Object)cv.e(-489359173)), (vswA)((Object)cv.e(-1392772934)), (vswA)((Object)cv.e(946469029)), (vswA)((Object)cv.e(-1602815836)), (vswA)((Object)cv.e(-514459481)), (vswA)((Object)cv.e(666564774)), (vswA)((Object)cv.e(1170012321)), (vswA)((Object)cv.e(-1939801952)), (vswA)((Object)cv.e(920189091)), (vswA)((Object)cv.e(739965090)), (vswA)((Object)cv.e(-1167132499)), (vswA)((Object)cv.e(1895233708)), (vswA)((Object)cv.e(-1479018321)), (vswA)((Object)cv.e(1188427950)), (vswA)((Object)cv.e(1974925481)), (vswA)((Object)cv.e(612694184)), (vswA)((Object)cv.e(787478699)), (vswA)((Object)cv.e(1275132074)), (vswA)((Object)cv.e(1581250709)), (vswA)((Object)cv.e(190052500)), (vswA)((Object)cv.e(709490839)), (vswA)((Object)cv.e(1364850838)), (vswA)((Object)cv.e(-997918575)), (vswA)((Object)cv.e(-951388016)), (vswA)((Object)cv.e(-1967392621)), (vswA)((Object)cv.e(-162727790)), (vswA)((Object)cv.e(2007562397)), (vswA)((Object)cv.e(-301139812)), (vswA)((Object)cv.e(2037840031)), (vswA)((Object)cv.e(-597362530))});
    }

    private vswA(String string2, int n2, int n3, String string3, boolean bl) {
        this(string, n, (int)string2, (String)n2, rgig$AWxc.r("\ud590\u8353\u3e7c\u3a2c\u345a\u5dbf\uec34"), (boolean)n3);
    }

    private vswA(String string2, int n2, int n3) {
        this(string, n, (int)string2, YEBy$TyVf.W("\u5273\ud462\uab36\ub105\uf208\u0151\u8478"), YEBy$TyVf.W("\u5273\ud462\uab36\ub105\uf208\u0151\u8478"), false);
    }

    private vswA(String string2, int n2, int n3, String string3) {
        this(string, n, (int)string2, (String)n2, YEBy$TyVf.W("\u5273\ud462\uab36\ub105\uf208\u0151\u8478"), false);
    }

    private vswA(String string2, int n2, int n3, String string3, String string4) {
        this(string, n, (int)string2, (String)n2, (String)n3, false);
    }

    private vswA(String string2, int n2, int n3, String string3, String string4, boolean bl) {
        this.version = string2;
        this.GlhC = (String)n2;
        this.kTLt = (String)n3;
        this.igXj = string3;
        if (string3 != false) {
            var3_4 -= 1000;
        }
    }

    public boolean YgWf() {
        try {
            vswA.Cv(vswA.Cv(vswA.Cv(vswA.Cv(new StringBuilder(rgig$AWxc.r("\uca7e\ufa19\ua3eb\u1ede\uc6b0\ud810\u9b4b\u70c4\u9820\u90e6\ua963\u8ab0\u8d7c\ue26f\u549f\u25a9\u86d8\u549f\u0a1c\u9d30\uf1b5")), (String)cv.b((Object)this, -1274480424)), rgig$AWxc.r("\uca3e\ufa3e\ua3f3\u1e9f\uc6be\ud812"))));
            return true;
        }
        catch (Throwable throwable) {
            return false;
        }
    }

    public String fCIb() {
        return (String)cv.b((Object)this, -1274480424);
    }

    public String toString() {
        return (String)cv.b((Object)this, -1812530981);
    }

    public static vswA AXbM() {
        vswA[] arrvswA = vswA.values();
        int n = arrvswA.length;
        int n2 = 0;
        while (n2 < n) {
            vswA vswA2 = arrvswA[n2];
            if (vswA2.sbdE() && vswA2.piwi() && vswA2.YgWf()) {
                return vswA2;
            }
            ++n2;
        }
        return null;
    }

    public static vswA HTdw() {
        vswA[] arrvswA = vswA.values();
        int n = arrvswA.length;
        int n2 = 0;
        while (n2 < n) {
            vswA vswA2 = arrvswA[n2];
            if (vswA2.piwi()) {
                return vswA2;
            }
            ++n2;
        }
        return (vswA)((Object)cv.e(-597362530));
    }

    public yBLM DYFV(vswA vswA2) {
        return new yBLM(this, vswA2);
    }

    public boolean piwi() {
        return (boolean)vswA.Cv(vswA.Cv(), this.getVersionString());
    }

    public String getVersionString() {
        return this.toString();
    }

    public boolean JkoN() {
        if (((Boolean)cv.b((Object)this, -1470760742)).booleanValue()) {
            return false;
        }
        return true;
    }

    public boolean sbdE() {
        return (boolean)vswA.Cv(this.toString(), YEBy$TyVf.W("\uec39"));
    }

    public int getVersion() {
        if (this.sbdE() && !this.JkoN()) {
            return this.PvRY() + 1000;
        }
        return this.PvRY();
    }

    public int PvRY() {
        return (Integer)cv.b((Object)this, -1424099131);
    }

    public static vswA[] values() {
        vswA[] arrvswA = (vswA[])cv.e(1914370201);
        int n = arrvswA.length;
        vswA[] arrvswA2 = new vswA[n];
        vswA.Cv(arrvswA, false, arrvswA2, false, n);
        return arrvswA2;
    }

    public static vswA valueOf(String string) {
        return (vswA)((Object)vswA.Cv(vswA.class, string));
    }

    private static Object Cv(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

