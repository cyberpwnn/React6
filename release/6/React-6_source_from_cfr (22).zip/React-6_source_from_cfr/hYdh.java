/*
 * Decompiled with CFR 0_123.
 */
public interface hYdh<FROM, TO> {
    public TO YoSa(FROM var1);

    public TO jhSt(FROM var1);
}

