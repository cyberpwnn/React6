/*
 * Decompiled with CFR 0_123.
 */
import java.io.File;

public class ejJV
extends Lhpt<kRIL> {
    public ejJV(String string, File file) {
        super(string, file);
    }

    public kRIL DYFV(long l, String string) {
        return new kRIL(l, null, string);
    }

    @Override
    public /* synthetic */ NxGC ssNb(long l, String string) {
        return this.DYFV(l, string);
    }
}

