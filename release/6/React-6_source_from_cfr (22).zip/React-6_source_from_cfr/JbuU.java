/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.util.Vector
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public final class JbuU
extends Enum<JbuU> {
    public static final /* enum */ JbuU vueO;
    public static final /* enum */ JbuU Nyfb;
    public static final /* enum */ JbuU ayMc;
    public static final /* enum */ JbuU vKTt;
    public static final /* enum */ JbuU diDj;
    public static final /* enum */ JbuU QFyg;
    public static final /* enum */ JbuU EMIi;
    public static final /* enum */ JbuU VMyE;
    public static final /* enum */ JbuU RAlj;
    public static final /* enum */ JbuU fMHD;
    public static final /* enum */ JbuU wgis;
    public static final /* enum */ JbuU OlHu;
    public static final /* enum */ JbuU DJFr;
    public static final /* enum */ JbuU hcmt;
    public static final /* enum */ JbuU OtYj;
    public static final /* enum */ JbuU pkeq;
    public static final /* enum */ JbuU GcqI;
    public static final /* enum */ JbuU aMxd;
    public static final /* enum */ JbuU pbuE;
    public static final /* enum */ JbuU CyhI;
    public static final /* enum */ JbuU IiwR;
    public static final /* enum */ JbuU hcoB;
    public static final /* enum */ JbuU IYWD;
    public static final /* enum */ JbuU ELga;
    public static final /* enum */ JbuU wNWV;
    public static final /* enum */ JbuU BUBm;
    public static final /* enum */ JbuU oprh;
    public static final /* enum */ JbuU BKpb;
    public static final /* enum */ JbuU ELgd;
    public static final /* enum */ JbuU urdX;
    public static final /* enum */ JbuU MfAt;
    public static final /* enum */ JbuU jPas;
    public static final /* enum */ JbuU TrfV;
    public static final /* enum */ JbuU ywAX;
    public static final /* enum */ JbuU CpuW;
    public static final /* enum */ JbuU Treo;
    public static final /* enum */ JbuU bkNc;
    public static final /* enum */ JbuU VNYY;
    public static final /* enum */ JbuU GuQv;
    public static final /* enum */ JbuU IPdM;
    public static final /* enum */ JbuU jPbI;
    public static final /* enum */ JbuU fexK;
    public static final /* enum */ JbuU sBNT;
    public static final /* enum */ JbuU Enmg;
    public static final /* enum */ JbuU BUCl;
    public static final /* enum */ JbuU kvLV;
    private static final Map<String, JbuU> SERo;
    private static final Map<Integer, JbuU> pJFd;
    private final String name;
    private final int id;
    private final int aVkV;
    private final List<JbuU$vtFs> MCaU;
    private static final /* synthetic */ JbuU[] BKpx;

    static {
        cv.V(-1856768139, (Object)new JbuU(rgig$AWxc.r("\u41db\u85ec\u9e47\u595d\u6b0a\u315d\ua97d\u9df3\ub6ac\u1dc5\u103f\udc68\u5f3b\u1516\u2b34\udef0"), 0, rgig$AWxc.r("\u41fb\u85cc\u9e67\u597d\u6b2a\u316a\ua951"), 0, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(1315370868, (Object)new JbuU(rgig$AWxc.r("\u41db\u85ec\u9e47\u595d\u6b0a\u315d\ua97d\u9df3\ub6ac\u1dc5\u103d\udc66\u5f3b\u151c\u2b30"), 1, rgig$AWxc.r("\u41f2\u85d5\u9e65\u5976\u6b20\u316b\ua94c\u9dcc\ub68e\u1df5\u1015\udc42"), 1, -1, new JbuU$vtFs[0]));
        cv.V(560002935, (Object)new JbuU(rgig$AWxc.r("\u41db\u85ec\u9e47\u595d\u6b0a\u315d\ua97d\u9df3\ub6ac\u1dc5\u1039\udc72\u5f2e\u151e"), 2, rgig$AWxc.r("\u41f6\u85c1\u9e70\u5974\u6b20\u3176\ua944\u9dd0\ub68d\u1de9\u1018\udc48\u5f07"), 2, -1, new JbuU$vtFs[0]));
        cv.V(1040447350, (Object)new JbuU(rgig$AWxc.r("\u41d8\u85fd\u9e45\u5954\u6b12\u3141\ua966\u9df7\ub6b1\u1dc5\u1022\udc77\u5f28\u1509\u2b3e"), 3, rgig$AWxc.r("\u41f8\u85dd\u9e65\u5974\u6b32\u3161\ua946\u9dd7\ub691\u1dc9\u1001\udc46\u5f1b\u1530"), 3, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(832567153, (Object)new JbuU(rgig$AWxc.r("\u41c9\u85f5\u9e43\u5954\u6b17\u3151\ua976\u9de9\ub6a0\u1dd8\u103d\udc62"), 4, rgig$AWxc.r("\u41fc\u85c1\u9e75\u5973\u6b29\u316b"), 4, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360)), (JbuU$vtFs)((Object)cv.e(1466169230))}));
        cv.V(1777203056, (Object)new JbuU(rgig$AWxc.r("\u41c9\u85f5\u9e43\u5954\u6b17\u3151\ua967\u9dec\ub6ae\u1ddb\u1022\udc6f"), 5, rgig$AWxc.r("\u41ed\u85c4\u9e7b\u5970\u6b36\u3166"), 5, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(2118186867, (Object)new JbuU(rgig$AWxc.r("\u41c9\u85f5\u9e43\u5954\u6b17\u3151\ua963\u9dfd\ub6a9\u1ddf"), 6, rgig$AWxc.r("\u41e9\u85d5\u9e7c\u5974"), 6, 7, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(161544050, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e1\u9e44\u5941\u6b00\u3140\ua970\u9df9\ub6a6"), 7, rgig$AWxc.r("\u41ed\u85c1\u9e64\u5961\u6b20\u3160\ua950\u9dd9\ub686"), 7, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(1466169230))}));
        cv.V(-1348274307, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e1\u9e44\u5941\u6b00\u3140\ua970\u9df9\ub6a6\u1dc5\u1035\udc62\u5f39\u150f\u2b3d"), 8, rgig$AWxc.r("\u41fa\u85d1\u9e67\u5965\u6b2d\u315d\ua941\u9dcf\ub692\u1dff\u101f\udc43"), 8, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-65407108, (Object)new JbuU(rgig$AWxc.r("\u41dd\u85e6\u9e5e\u5945"), 9, rgig$AWxc.r("\u41fd\u85c6\u9e7e\u5965"), 9, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(959772543, (Object)new JbuU(rgig$AWxc.r("\u41dd\u85e6\u9e5e\u5945\u6b1a\u3143\ua975\u9dfb\ub6ab\u1dd9"), 10, rgig$AWxc.r("\u41f3\u85d5\u9e70\u5978\u6b26\u314d\ua946\u9dd5\ub696"), 10, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-727517314, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85f9\u9e58\u595a\u6b00\u3151\ua97a\u9df3\ub6b0\u1dd7\u1030\udc6b"), 11, rgig$AWxc.r("\u41ed\u85d9\u9e78\u597a\u6b20"), 11, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(84932473, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85f9\u9e58\u595a\u6b00\u3151\ua978\u9dfd\ub6b0\u1ddd\u1034"), 12, rgig$AWxc.r("\u41f2\u85d5\u9e65\u5976\u6b20\u317d\ua959\u9dd3\ub689\u1dff"), 12, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(66582072, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e4\u9e52\u595d\u6b09"), 13, rgig$AWxc.r("\u41ed\u85c4\u9e72\u597d\u6b29"), 13, -1, new JbuU$vtFs[0]));
        cv.V(977663547, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e4\u9e52\u595d\u6b09\u3151\ua97d\u9df2\ub6b1\u1dce\u1030\udc69\u5f3d"), 14, rgig$AWxc.r("\u41f7\u85da\u9e64\u5965\u6b24\u3160\ua940\u9def\ub692\u1dff\u101d\udc4b"), 14, -1, new JbuU$vtFs[0]));
        cv.V(27718324, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e4\u9e52\u595d\u6b09\u3151\ua979\u9df3\ub6a0"), 15, rgig$AWxc.r("\u41f3\u85db\u9e75\u5942\u6b35\u316b\ua958\u9dd0"), 15, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(206763915))}));
        cv.V(920778298, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e4\u9e52\u595d\u6b09\u3151\ua979\u9df3\ub6a0\u1dc5\u1030\udc6a\u5f2b\u1512\u2b30\udef2\u7f4b"), 16, rgig$AWxc.r("\u41f3\u85db\u9e75\u5942\u6b35\u316b\ua958\u9dd0\ub6a3\u1df7\u1013\udc4e\u5f0c\u1535\u2b01"), 16, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(206763915))}));
        cv.V(-526125531, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e4\u9e52\u595d\u6b09\u3151\ua963\u9df5\ub6b6\u1dd9\u1039"), 17, rgig$AWxc.r("\u41e9\u85dd\u9e63\u5972\u6b2d\u3143\ua955\u9ddb\ub68b\u1df9"), 17, -1, new JbuU$vtFs[0]));
        cv.V(-1416497628, (Object)new JbuU(rgig$AWxc.r("\u41da\u85e6\u9e5e\u5941\u6b1a\u3159\ua975\u9de8\ub6a7\u1dc8"), 18, rgig$AWxc.r("\u41fa\u85c6\u9e7e\u5961\u6b12\u316f\ua940\u9dd9\ub690"), 18, -1, new JbuU$vtFs[0]));
        cv.V(262272551, (Object)new JbuU(rgig$AWxc.r("\u41da\u85e6\u9e5e\u5941\u6b1a\u3142\ua975\u9dea\ub6a3"), 19, rgig$AWxc.r("\u41fa\u85c6\u9e7e\u5961\u6b09\u316f\ua942\u9ddd"), 19, -1, new JbuU$vtFs[0]));
        cv.V(-564726234, (Object)new JbuU(rgig$AWxc.r("\u41c8\u85fd\u9e5b\u595d\u6b04\u3149\ua971\u9dee\ub6bd\u1ddb\u103f\udc60\u5f3b\u1502"), 20, rgig$AWxc.r("\u41ff\u85da\u9e70\u5963\u6b3c\u3158\ua95d\u9dd0\ub68e\u1dfb\u1016\udc42\u5f1b"), 20, -1, new JbuU$vtFs[0]));
        cv.V(1340674161, (Object)new JbuU(rgig$AWxc.r("\u41c8\u85fd\u9e5b\u595d\u6b04\u3149\ua971\u9dee\ub6bd\u1dd2\u1030\udc77\u5f39\u1502"), 21, rgig$AWxc.r("\u41f6\u85d5\u9e67\u5961\u6b3c\u3158\ua95d\u9dd0\ub68e\u1dfb\u1016\udc42\u5f1b"), 21, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-868092383, (Object)new JbuU(rgig$AWxc.r("\u41ca\u85fb\u9e40\u595f\u6b1a\u314f\ua961\u9dee\ub6a3"), 22, rgig$AWxc.r("\u41ea\u85db\u9e60\u597f\u6b24\u317b\ua946\u9ddd"), 22, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(1568536096, (Object)new JbuU(rgig$AWxc.r("\u41d0\u85fb\u9e43\u5954"), 23, rgig$AWxc.r("\u41f0\u85db\u9e63\u5974"), 23, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(206763915))}));
        cv.V(-14223837, (Object)new JbuU(rgig$AWxc.r("\u41ce\u85fb\u9e45\u5945\u6b04\u3142"), 24, rgig$AWxc.r("\u41ee\u85db\u9e65\u5965\u6b24\u3162"), 24, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-337250782, (Object)new JbuU(rgig$AWxc.r("\u41db\u85fa\u9e54\u5959\u6b04\u3140\ua960\u9df1\ub6a7\u1dd4\u1025\udc78\u5f3d\u151a\u2b37\udef0\u7f5a"), 25, rgig$AWxc.r("\u41fb\u85da\u9e74\u5979\u6b24\u3160\ua940\u9dd1\ub687\u1df4\u1005\udc53\u5f08\u1539\u2b19\uded9"), 25, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-933628371, (Object)new JbuU(rgig$AWxc.r("\u41d8\u85f8\u9e56\u595c\u6b00"), 26, rgig$AWxc.r("\u41f8\u85d8\u9e76\u597c\u6b20"), 26, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-1089407444, (Object)new JbuU(rgig$AWxc.r("\u41d2\u85f5\u9e41\u5950"), 27, rgig$AWxc.r("\u41f2\u85d5\u9e61\u5970"), 27, -1, new JbuU$vtFs[0]));
        cv.V(-2028079569, (Object)new JbuU(rgig$AWxc.r("\u41d8\u85fb\u9e58\u5945\u6b16\u315a\ua971\u9dec"), 28, rgig$AWxc.r("\u41f8\u85db\u9e78\u5965\u6b36\u317a\ua951\u9dcc"), 28, -1, new JbuU$vtFs[0]));
        cv.V(2020406830, (Object)new JbuU(rgig$AWxc.r("\u41dd\u85f8\u9e58\u5944\u6b01"), 29, rgig$AWxc.r("\u41fd\u85d8\u9e78\u5964\u6b21"), 29, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-1137117329, (Object)new JbuU(rgig$AWxc.r("\u41cc\u85f1\u9e53\u5942\u6b11\u3141\ua97a\u9df9"), 30, rgig$AWxc.r("\u41ec\u85d1\u9e73\u5975\u6b30\u317d\ua940"), 30, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(206763915))}));
        cv.V(-2098596311, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85fa\u9e58\u5946\u6b07\u314f\ua978\u9df0"), 31, rgig$AWxc.r("\u41ed\u85da\u9e78\u5966\u6b27\u316f\ua958\u9dd0\ub692\u1df5\u101e\udc41"), 31, -1, new JbuU$vtFs[0]));
        cv.V(-125241816, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85fa\u9e58\u5946\u6b1a\u315d\ua97c\u9df3\ub6b4\u1ddf\u103d"), 32, rgig$AWxc.r("\u41ed\u85da\u9e78\u5966\u6b36\u3166\ua95b\u9dca\ub687\u1df6"), 32, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360))}));
        cv.V(-1872103893, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85f8\u9e5e\u595c\u6b00"), 33, rgig$AWxc.r("\u41ed\u85d8\u9e7e\u597c\u6b20"), 33, -1, new JbuU$vtFs[0]));
        cv.V(-1268058582, (Object)new JbuU(rgig$AWxc.r("\u41d6\u85f1\u9e56\u5943\u6b11"), 34, rgig$AWxc.r("\u41f6\u85d1\u9e76\u5963\u6b31"), 34, -1, new JbuU$vtFs[0]));
        cv.V(-990972395, (Object)new JbuU(rgig$AWxc.r("\u41dc\u85f5\u9e45\u5943\u6b0c\u314b\ua966"), 35, rgig$AWxc.r("\u41fc\u85d5\u9e65\u5963\u6b2c\u316b\ua946"), 35, 8, new JbuU$vtFs[0]));
        cv.V(1063843712, (Object)new JbuU(rgig$AWxc.r("\u41d7\u85e0\u9e52\u595c\u6b1a\u314d\ua966\u9dfd\ub6a1\u1dd1"), 36, rgig$AWxc.r("\u41f7\u85d7\u9e78\u597f\u6b26\u317c\ua955\u9ddf\ub689"), 36, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360)), (JbuU$vtFs)((Object)cv.e(1009973129))}));
        cv.V(269350420, (Object)new JbuU(rgig$AWxc.r("\u41dc\u85f8\u9e58\u5952\u6b0e\u3151\ua977\u9dee\ub6a3\u1dd9\u103a"), 37, rgig$AWxc.r("\u41fc\u85d8\u9e78\u5972\u6b2e\u316d\ua946\u9ddd\ub681\u1df1"), 37, -1, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(1009973129))}));
        cv.V(764671511, (Object)new JbuU(rgig$AWxc.r("\u41dc\u85f8\u9e58\u5952\u6b0e\u3151\ua970\u9de9\ub6b1\u1dce"), 38, rgig$AWxc.r("\u41fc\u85d8\u9e78\u5972\u6b2e\u316a\ua941\u9dcf\ub696"), 38, 7, new JbuU$vtFs[]{(JbuU$vtFs)((Object)cv.e(-1428490360)), (JbuU$vtFs)((Object)cv.e(1009973129))}));
        cv.V(1770845718, (Object)new JbuU(rgig$AWxc.r("\u41c9\u85f5\u9e43\u5954\u6b17\u3151\ua970\u9dee\ub6ad\u1dca"), 39, rgig$AWxc.r("\u41fa\u85c6\u9e78\u5961\u6b29\u316b\ua940"), 39, 8, new JbuU$vtFs[0]));
        cv.V(-728041967, (Object)new JbuU(rgig$AWxc.r("\u41d7\u85e0\u9e52\u595c\u6b1a\u315a\ua975\u9df7\ub6a7"), 40, rgig$AWxc.r("\u41ea\u85d5\u9e7c\u5974"), 40, 8, new JbuU$vtFs[0]));
        cv.V(-1724123632, (Object)new JbuU(rgig$AWxc.r("\u41d3\u85fb\u9e55\u594e\u6b04\u315e\ua964\u9df9\ub6a3\u1dc8\u1030\udc69\u5f2a\u151e"), 41, rgig$AWxc.r("\u41f3\u85db\u9e75\u5970\u6b35\u317e\ua951\u9ddd\ub690\u1dfb\u101f\udc44\u5f0c"), 41, 8, new JbuU$vtFs[0]));
        cv.V(-27658733, (Object)new JbuU(rgig$AWxc.r("\u41da\u85e6\u9e56\u5956\u6b0a\u3140\ua96b\u9dfe\ub6b0\u1ddf\u1030\udc73\u5f21"), 42, rgig$AWxc.r("\u41fa\u85c6\u9e76\u5976\u6b2a\u3160\ua956\u9dce\ub687\u1dfb\u1005\udc4f"), 42, 9, new JbuU$vtFs[0]));
        cv.V(1967257106, (Object)new JbuU(rgig$AWxc.r("\u41db\u85fa\u9e53\u594e\u6b17\u3141\ua970"), 43, rgig$AWxc.r("\u41fb\u85da\u9e73\u5963\u6b2a\u316a"), 43, 9, new JbuU$vtFs[0]));
        cv.V(-6621667, (Object)new JbuU(rgig$AWxc.r("\u41da\u85f5\u9e5a\u5950\u6b02\u314b\ua96b\u9df5\ub6ac\u1dde\u1038\udc64\u5f28\u150f\u2b3a\udeee"), 44, rgig$AWxc.r("\u41fa\u85d5\u9e7a\u5970\u6b22\u316b\ua95d\u9dd2\ub686\u1df3\u1012\udc46\u5f1d\u1534\u2b07"), 44, 9, new JbuU$vtFs[0]));
        cv.V(380040732, (Object)new JbuU(rgig$AWxc.r("\u41cd\u85e3\u9e52\u5954\u6b15\u3151\ua975\u9de8\ub6b6\u1ddb\u1032\udc6c"), 45, rgig$AWxc.r("\u41ed\u85c3\u9e72\u5974\u6b35\u317a\ua940\u9ddd\ub681\u1df1"), 45, 9, new JbuU$vtFs[0]));
        cv.V(1905522207, new JbuU[]{(JbuU)((Object)cv.e(-1856768139)), (JbuU)((Object)cv.e(1315370868)), (JbuU)((Object)cv.e(560002935)), (JbuU)((Object)cv.e(1040447350)), (JbuU)((Object)cv.e(832567153)), (JbuU)((Object)cv.e(1777203056)), (JbuU)((Object)cv.e(2118186867)), (JbuU)((Object)cv.e(161544050)), (JbuU)((Object)cv.e(-1348274307)), (JbuU)((Object)cv.e(-65407108)), (JbuU)((Object)cv.e(959772543)), (JbuU)((Object)cv.e(-727517314)), (JbuU)((Object)cv.e(84932473)), (JbuU)((Object)cv.e(66582072)), (JbuU)((Object)cv.e(977663547)), (JbuU)((Object)cv.e(27718324)), (JbuU)((Object)cv.e(920778298)), (JbuU)((Object)cv.e(-526125531)), (JbuU)((Object)cv.e(-1416497628)), (JbuU)((Object)cv.e(262272551)), (JbuU)((Object)cv.e(-564726234)), (JbuU)((Object)cv.e(1340674161)), (JbuU)((Object)cv.e(-868092383)), (JbuU)((Object)cv.e(1568536096)), (JbuU)((Object)cv.e(-14223837)), (JbuU)((Object)cv.e(-337250782)), (JbuU)((Object)cv.e(-933628371)), (JbuU)((Object)cv.e(-1089407444)), (JbuU)((Object)cv.e(-2028079569)), (JbuU)((Object)cv.e(2020406830)), (JbuU)((Object)cv.e(-1137117329)), (JbuU)((Object)cv.e(-2098596311)), (JbuU)((Object)cv.e(-125241816)), (JbuU)((Object)cv.e(-1872103893)), (JbuU)((Object)cv.e(-1268058582)), (JbuU)((Object)cv.e(-990972395)), (JbuU)((Object)cv.e(1063843712)), (JbuU)((Object)cv.e(269350420)), (JbuU)((Object)cv.e(764671511)), (JbuU)((Object)cv.e(1770845718)), (JbuU)((Object)cv.e(-728041967)), (JbuU)((Object)cv.e(-1724123632)), (JbuU)((Object)cv.e(-27658733)), (JbuU)((Object)cv.e(1967257106)), (JbuU)((Object)cv.e(-6621667)), (JbuU)((Object)cv.e(380040732))});
        cv.V(-60426722, new HashMap());
        cv.V(-1880951271, new HashMap());
        JbuU[] arrjbuU = JbuU.values();
        int n = arrjbuU.length;
        int n2 = 0;
        while (n2 < n) {
            JbuU jbuU = arrjbuU[n2];
            ((Map)cv.e(-60426722)).put((String)cv.b((Object)jbuU, -486148520), jbuU);
            ((Map)cv.e(-1880951271)).put(JbuU.Ne((Integer)cv.b((Object)jbuU, 606795355)), jbuU);
            ++n2;
        }
    }

    private /* varargs */ JbuU(String string2, int n2, String string3, int n3, int n4, JbuU$vtFs ... arrjbuU$vtFs) {
        this.name = string2;
        this.id = n2;
        this.aVkV = string3;
        this.MCaU = JbuU.Ne(n3);
    }

    public String getName() {
        return (String)cv.b((Object)this, -486148520);
    }

    public int getId() {
        return (Integer)cv.b((Object)this, 606795355);
    }

    public int Mcsc() {
        return (Integer)cv.b((Object)this, 1570240069);
    }

    public boolean ssNb(JbuU$vtFs jbuU$vtFs) {
        return ((List)cv.b((Object)this, -1717438908)).contains((Object)jbuU$vtFs);
    }

    public boolean isSupported() {
        if ((Integer)cv.b((Object)this, 1570240069) == -1) {
            return true;
        }
        if (JbuU.Ne() >= (Integer)cv.b((Object)this, 1570240069)) {
            return true;
        }
        return false;
    }

    public static JbuU hbNa(String string) {
        for (Map.Entry entry : ((Map)cv.e(-60426722)).entrySet()) {
            if (JbuU.Ne((String)entry.getKey(), string) == false) continue;
            return (JbuU)((Object)entry.getValue());
        }
        return null;
    }

    public static JbuU hbNa(int n) {
        for (Map.Entry entry : ((Map)cv.e(-1880951271)).entrySet()) {
            if (JbuU.Ne((Integer)entry.getKey()) != n) continue;
            return (JbuU)((Object)entry.getValue());
        }
        return null;
    }

    private static boolean EmLA(Location location) {
        Material material = JbuU.Ne(location).getType();
        if (material != (Material)cv.e(1517483590) && material != (Material)cv.e(-855509439)) {
            return false;
        }
        return true;
    }

    private static boolean ssNb(Location location, List<Player> list) {
        String string = JbuU.Ne(location).getName();
        for (Player player : list) {
            Location location2 = player.getLocation();
            if (JbuU.Ne(string, JbuU.Ne(location2).getName()) == false) continue;
            if (JbuU.Ne(location2, location) < 65536.0) continue;
            return true;
        }
        return false;
    }

    private static boolean ssNb(JbuU jbuU, JbuU$BkpW jbuU$BkpW) {
        if (!((jbuU == (JbuU)((Object)cv.e(269350420)) || jbuU == (JbuU)((Object)cv.e(764671511))) && jbuU$BkpW instanceof JbuU$ssNb || jbuU == (JbuU)((Object)cv.e(1063843712)) && jbuU$BkpW instanceof JbuU$DYFV)) {
            return false;
        }
        return true;
    }

    private static boolean ssNb(JbuU jbuU, JbuU$YoSa jbuU$YoSa) {
        if (!((jbuU == (JbuU)((Object)cv.e(27718324)) || jbuU == (JbuU)((Object)cv.e(920778298)) || jbuU == (JbuU)((Object)cv.e(-1137117329))) && jbuU$YoSa instanceof JbuU$OXeK || jbuU == (JbuU)((Object)cv.e(1568536096)) && jbuU$YoSa instanceof JbuU$IWSm)) {
            return false;
        }
        return true;
    }

    public void ssNb(float f, int n, Location location, double d) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        if (!this.isSupported()) {
            return;
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14d2\ua6b9\u6cc8\uebb5\ub07a\uf063\u43a3\u935d\u35cc\ub826\ue863\u8726\u185c\u2a8d\u51ca\u781f\ud31d\u78ca\u7471\u6471\ue139\u4864\u1802\u0e71"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1466169230))) && !JbuU.EmLA(location)) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa1c\ucacb\u9a24\uea26\u4b54\u37ad\ua227\u9015\u1494\u5e9d\u1a49\u00aa\uf3f6\u75ba\u1fc6\uc808\u88ab\uc2bd\u762a\u14d4\ua6b4\u6cdc\uebe0\ub070\uf074\u43a8\u935a\u3589\ub835\ue827\u872e\u185a\u2a9a\u51c2\u7804\ud31a\u78c4\u7473"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, 0.0f, 0.0f, 0.0f, f, n, d > 256.0, null), location, d);
    }

    public void ssNb(float f, int n, Location location, List<Player> list) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14c9\ua6af\u6c99\uebae\ub07c\uf065\u43e6\u935d\u3599\ub837\ue877\u872d\u1847\u2a8d\u51c6\u7814\ud353\u78c9\u7464\u6471\ue124\u486a\u1803\u0e62\ufccc\u25f3\u966e\ud5d3\u025e\uc9f4\u1b0e\u029e\u3ead\ub38b\u9380\u8425\u0e21\u20c6\uadbb"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14d2\ua6b9\u6cc8\uebb5\ub07a\uf063\u43a3\u935d\u35cc\ub826\ue863\u8726\u185c\u2a8d\u51ca\u781f\ud31d\u78ca\u7471\u6471\ue139\u4864\u1802\u0e71"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1466169230))) && !JbuU.EmLA(location)) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa1c\ucacb\u9a24\uea26\u4b54\u37ad\ua227\u9015\u1494\u5e9d\u1a49\u00aa\uf3f6\u75ba\u1fc6\uc808\u88ab\uc2bd\u762a\u14d4\ua6b4\u6cdc\uebe0\ub070\uf074\u43a8\u935a\u3589\ub835\ue827\u872e\u185a\u2a9a\u51c2\u7804\ud31a\u78c4\u7473"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, 0.0f, 0.0f, 0.0f, f, n, JbuU.ssNb(location, list), null), location, list);
    }

    public /* varargs */ void ssNb(float f, int n, Location location, Player ... arrplayer) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        this.ssNb(f, n, location, (List<Player>)JbuU.Ne(arrplayer));
    }

    public void ssNb(Vector vector, float f, Location location, double d) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14c9\ua6af\u6c99\uebae\ub07c\uf065\u43e6\u935d\u3599\ub837\ue877\u872d\u1847\u2a8d\u51c6\u7814\ud353\u78c9\u7464\u6471\ue124\u486a\u1803\u0e62\ufccc\u25f3\u966e\ud5d3\u025e\uc9f4\u1b0e\u029e\u3ead\ub38b\u9380\u8425\u0e21\u20c6\uadbb"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14d2\ua6b9\u6cc8\uebb5\ub07a\uf063\u43a3\u935d\u35cc\ub826\ue863\u8726\u185c\u2a8d\u51ca\u781f\ud31d\u78ca\u7471\u6471\ue139\u4864\u1802\u0e71"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(-1428490360)))) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14c9\ua6af\u6c99\uebae\ub07c\uf065\u43e6\u934a\u3585\ub835\ue862\u8721\u1841\u2a90\u51cc\u781e\ud312\u78c7"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1466169230))) && !JbuU.EmLA(location)) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa1c\ucacb\u9a24\uea26\u4b54\u37ad\ua227\u9015\u1494\u5e9d\u1a49\u00aa\uf3f6\u75ba\u1fc6\uc808\u88ab\uc2bd\u762a\u14d4\ua6b4\u6cdc\uebe0\ub070\uf074\u43a8\u935a\u3589\ub835\ue827\u872e\u185a\u2a9a\u51c2\u7804\ud31a\u78c4\u7473"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, vector, f, d > 256.0, null), location, d);
    }

    public void ssNb(Vector vector, float f, Location location, List<Player> list) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14c9\ua6af\u6c99\uebae\ub07c\uf065\u43e6\u935d\u3599\ub837\ue877\u872d\u1847\u2a8d\u51c6\u7814\ud353\u78c9\u7464\u6471\ue124\u486a\u1803\u0e62\ufccc\u25f3\u966e\ud5d3\u025e\uc9f4\u1b0e\u029e\u3ead\ub38b\u9380\u8425\u0e21\u20c6\uadbb"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14d2\ua6b9\u6cc8\uebb5\ub07a\uf063\u43a3\u935d\u35cc\ub826\ue863\u8726\u185c\u2a8d\u51ca\u781f\ud31d\u78ca\u7471\u6471\ue139\u4864\u1802\u0e71"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(-1428490360)))) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa10\ucaca\u9a61\uea76\u4b5c\u37ac\ua273\u9012\u1498\u5ed1\u1a5b\u00eb\uf3e7\u75b9\u1fd2\uc84d\u88a9\uc2bd\u762a\u14c9\ua6af\u6c99\uebae\ub07c\uf065\u43e6\u934a\u3585\ub835\ue862\u8721\u1841\u2a90\u51cc\u781e\ud312\u78c7"));
        }
        if (this.ssNb((JbuU$vtFs)((Object)cv.e(1466169230))) && !JbuU.EmLA(location)) {
            throw new IllegalArgumentException(YEBy$TyVf.W("\u382e\u4870\uaa1c\ucacb\u9a24\uea26\u4b54\u37ad\ua227\u9015\u1494\u5e9d\u1a49\u00aa\uf3f6\u75ba\u1fc6\uc808\u88ab\uc2bd\u762a\u14d4\ua6b4\u6cdc\uebe0\ub070\uf074\u43a8\u935a\u3589\ub835\ue827\u872e\u185a\u2a9a\u51c2\u7804\ud31a\u78c4\u7473"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, vector, f, JbuU.ssNb(location, list), null), location, list);
    }

    public /* varargs */ void ssNb(Vector vector, float f, Location location, Player ... arrplayer) throws JbuU$EmLA, JbuU$lCdp, IllegalArgumentException {
        this.ssNb(vector, f, location, (List<Player>)JbuU.Ne(arrplayer));
    }

    public void ssNb(JbuU$YoSa jbuU$YoSa, Location location, double d) throws JbuU$EmLA, JbuU$jhSt {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2578\uf24c\u1f18\u4b41\u67be\u1cdf\u44ef\ue08a\uf279\ua11b\ue359\u28b9\u7534\u2036\ua98d\u6519\u6752\u7101\uebe4\uf9e1\u7900\u1d54\u388e\u56fa\u5ee9\uc1c4\ucb8f\uaefb\uaaaf\ua8b9\u943a\u7c89"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(206763915)))) {
            throw new JbuU$jhSt(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2568\uf256\u1f04\u4b5e\u67a3\u1ccc\u44f9\ue083\uf278"));
        }
        if (!JbuU.ssNb(this, jbuU$YoSa)) {
            throw new JbuU$jhSt(rgig$AWxc.r("\u7627\u0aa4\u95b6\u8e1e\u2f5c\uc586\u2e06\u177f\u360c\u46f1\u3fb1\u71eb\u8da9\u4880\u14d1\u6589\u3e3f\ucefd\u8dae\u01c8\ud48c\udb28\u935d\uc8cc\u64fa\u12ea\ud8dc\ub21b\u2565\uf25a\u1f07\u4b43\u67a3\u1cc8\u44f8\ue09b"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, jbuU$YoSa, d > 256.0), location, d);
    }

    public void ssNb(JbuU$YoSa jbuU$YoSa, Location location, List<Player> list) throws JbuU$EmLA, JbuU$jhSt {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2578\uf24c\u1f18\u4b41\u67be\u1cdf\u44ef\ue08a\uf279\ua11b\ue359\u28b9\u7534\u2036\ua98d\u6519\u6752\u7101\uebe4\uf9e1\u7900\u1d54\u388e\u56fa\u5ee9\uc1c4\ucb8f\uaefb\uaaaf\ua8b9\u943a\u7c89"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(206763915)))) {
            throw new JbuU$jhSt(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2568\uf256\u1f04\u4b5e\u67a3\u1ccc\u44f9\ue083\uf278"));
        }
        if (!JbuU.ssNb(this, jbuU$YoSa)) {
            throw new JbuU$jhSt(rgig$AWxc.r("\u7627\u0aa4\u95b6\u8e1e\u2f5c\uc586\u2e06\u177f\u360c\u46f1\u3fb1\u71eb\u8da9\u4880\u14d1\u6589\u3e3f\ucefd\u8dae\u01c8\ud48c\udb28\u935d\uc8cc\u64fa\u12ea\ud8dc\ub21b\u2565\uf25a\u1f07\u4b43\u67a3\u1cc8\u44f8\ue09b"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, jbuU$YoSa, JbuU.ssNb(location, list)), location, list);
    }

    public /* varargs */ void ssNb(JbuU$YoSa jbuU$YoSa, Location location, Player ... arrplayer) throws JbuU$EmLA, JbuU$jhSt {
        this.ssNb(jbuU$YoSa, location, (List<Player>)JbuU.Ne(arrplayer));
    }

    public void ssNb(JbuU$BkpW jbuU$BkpW, float f, int n, Location location, double d) throws JbuU$EmLA, JbuU$lCdp {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2578\uf24c\u1f18\u4b41\u67be\u1cdf\u44ef\ue08a\uf279\ua11b\ue359\u28b9\u7534\u2036\ua98d\u6519\u6752\u7101\uebe4\uf9e1\u7900\u1d54\u388e\u56fa\u5ee9\uc1c4\ucb8f\uaefb\uaaaf\ua8b9\u943a\u7c89"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb3c\u9357\uc889\u64e0\u12b9\ud892\ub21d\u257f\uf219\u1f1a\u4b54\u67a0\u1cd8\u44f2\ue09d\uf278\ua11b\ue35a\u28a4\u7570\u2026\ua996\u6505\u674f\u714f\uebf6\uf9e8\u7952\u1d46\u388a\u56fc\u5ea8"));
        }
        if (!JbuU.ssNb(this, jbuU$BkpW)) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95b6\u8e1e\u2f5c\uc586\u2e06\u177f\u360c\u46f1\u3fb1\u71eb\u8da9\u4887\u14df\u6591\u3e31\uceaf\u8dfa\u01c5\ud485\udb3d\u9318\uc885\u64e0\u12b9\ud895\ub21c\u2568\uf256\u1f1a\u4b43\u67b4\u1cce\u44ef"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, 0.0f, 0.0f, 0.0f, f, n, d > 256.0, jbuU$BkpW), location, d);
    }

    public void ssNb(JbuU$BkpW jbuU$BkpW, float f, int n, Location location, List<Player> list) throws JbuU$EmLA, JbuU$lCdp {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2578\uf24c\u1f18\u4b41\u67be\u1cdf\u44ef\ue08a\uf279\ua11b\ue359\u28b9\u7534\u2036\ua98d\u6519\u6752\u7101\uebe4\uf9e1\u7900\u1d54\u388e\u56fa\u5ee9\uc1c4\ucb8f\uaefb\uaaaf\ua8b9\u943a\u7c89"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb3c\u9357\uc889\u64e0\u12b9\ud892\ub21d\u257f\uf219\u1f1a\u4b54\u67a0\u1cd8\u44f2\ue09d\uf278\ua11b\ue35a\u28a4\u7570\u2026\ua996\u6505\u674f\u714f\uebf6\uf9e8\u7952\u1d46\u388a\u56fc\u5ea8"));
        }
        if (!JbuU.ssNb(this, jbuU$BkpW)) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95b6\u8e1e\u2f5c\uc586\u2e06\u177f\u360c\u46f1\u3fb1\u71eb\u8da9\u4887\u14df\u6591\u3e31\uceaf\u8dfa\u01c5\ud485\udb3d\u9318\uc885\u64e0\u12b9\ud895\ub21c\u2568\uf256\u1f1a\u4b43\u67b4\u1cce\u44ef"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, 0.0f, 0.0f, 0.0f, f, n, JbuU.ssNb(location, list), jbuU$BkpW), location, list);
    }

    public /* varargs */ void ssNb(JbuU$BkpW jbuU$BkpW, float f, int n, Location location, Player ... arrplayer) throws JbuU$EmLA, JbuU$lCdp {
        this.ssNb(jbuU$BkpW, f, n, location, (List<Player>)JbuU.Ne(arrplayer));
    }

    public void ssNb(JbuU$BkpW jbuU$BkpW, Vector vector, float f, Location location, double d) throws JbuU$EmLA, JbuU$lCdp {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(KUXS$dwji.S("\uacdf\u7d9f\u2a25\u7686\u4efe\u1e56\ufc82\uf249\u3711\u218e\uece6\u9375\u6f56\u32a8\u8868\u9701\uc399\u4c1d\ucedb\ud11e\ucff6\u908a\u3d4f\u2954\u128b\u4769\u98c1\u4e01\u3b97\u0ebd\u88ab\u06e8\u8bb9\u494f\ud337\u1db7\ud2b0\ua18b\u0309\u6bb7\u87ae\u5069\u22f3\u16dd\u8908\u25f3\u0987\u8f20\uc8c0\ubc60\u9e43\uf957\u5f8b\ubabe\ua207\uad1f\u5e4d\u51c0\uc433\u07e7"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(KUXS$dwji.S("\uacdf\u7d9f\u2a25\u7686\u4efe\u1e56\ufc82\uf249\u3711\u218e\uece6\u9375\u6f56\u32a8\u8868\u9701\uc399\u4c1d\ucedb\ud11e\ucff6\u9087\u3d53\u2911\u1296\u4726\u98db\u4e4e\u3b90\u0ee8\u88a9\u06fd\u8ba7\u4948\ud32a\u1da0\ud2b1\ua18b\u030a\u6baa\u87ea\u5079\u22e8\u16c1\u8915\u25bd\u0995\u8f29\uc892\ubc72\u9e47\uf951\u5fca"));
        }
        if (!JbuU.ssNb(this, jbuU$BkpW)) {
            throw new JbuU$lCdp(KUXS$dwji.S("\uacdf\u7d9f\u2a29\u76d5\u4eae\u1e47\ufc91\uf24f\u370c\u2184\uece9\u937c\u6f13\u32ec\u886c\u9713\uc39e\u4c58\ucecc\ud113\ucfa6\u9086\u3d1c\u291d\u1296\u4726\u98dc\u4e4f\u3b87\u0ea7\u88a9\u06ea\u8bb3\u495e\ud337"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, vector, f, d > 256.0, jbuU$BkpW), location, d);
    }

    public void ssNb(JbuU$BkpW jbuU$BkpW, Vector vector, float f, Location location, List<Player> list) throws JbuU$EmLA, JbuU$lCdp {
        if (!this.isSupported()) {
            throw new JbuU$EmLA(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb31\u934b\uc8cc\u64fd\u12f6\ud888\ub252\u2578\uf24c\u1f18\u4b41\u67be\u1cdf\u44ef\ue08a\uf279\ua11b\ue359\u28b9\u7534\u2036\ua98d\u6519\u6752\u7101\uebe4\uf9e1\u7900\u1d54\u388e\u56fa\u5ee9\uc1c4\ucb8f\uaefb\uaaaf\ua8b9\u943a\u7c89"));
        }
        if (!this.ssNb((JbuU$vtFs)((Object)cv.e(1009973129)))) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95ba\u8e4d\u2f0c\uc597\u2e15\u1779\u3611\u46fb\u3fbe\u71e2\u8dec\u48c3\u14db\u6583\u3e36\uceea\u8ded\u01c8\ud4d5\udb3c\u9357\uc889\u64e0\u12b9\ud892\ub21d\u257f\uf219\u1f1a\u4b54\u67a0\u1cd8\u44f2\ue09d\uf278\ua11b\ue35a\u28a4\u7570\u2026\ua996\u6505\u674f\u714f\uebf6\uf9e8\u7952\u1d46\u388a\u56fc\u5ea8"));
        }
        if (!JbuU.ssNb(this, jbuU$BkpW)) {
            throw new JbuU$lCdp(rgig$AWxc.r("\u7627\u0aa4\u95b6\u8e1e\u2f5c\uc586\u2e06\u177f\u360c\u46f1\u3fb1\u71eb\u8da9\u4887\u14df\u6591\u3e31\uceaf\u8dfa\u01c5\ud485\udb3d\u9318\uc885\u64e0\u12b9\ud895\ub21c\u2568\uf256\u1f1a\u4b43\u67b4\u1cce\u44ef"));
        }
        JbuU.Ne(new JbuU$nJLQ(this, vector, f, JbuU.ssNb(location, list), jbuU$BkpW), location, list);
    }

    public /* varargs */ void ssNb(JbuU$BkpW jbuU$BkpW, Vector vector, float f, Location location, Player ... arrplayer) throws JbuU$EmLA, JbuU$lCdp {
        this.ssNb(jbuU$BkpW, vector, f, location, (List<Player>)JbuU.Ne(arrplayer));
    }

    public static JbuU[] values() {
        JbuU[] arrjbuU = (JbuU[])cv.e(1905522207);
        int n = arrjbuU.length;
        JbuU[] arrjbuU2 = new JbuU[n];
        JbuU.Ne(arrjbuU, false, arrjbuU2, false, n);
        return arrjbuU2;
    }

    public static JbuU valueOf(String string) {
        return (JbuU)((Object)JbuU.Ne(JbuU.class, string));
    }

    private static Object Ne(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

