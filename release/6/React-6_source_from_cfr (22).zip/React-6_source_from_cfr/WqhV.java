/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import org.bukkit.command.CommandSender;

public interface WqhV {
    public wfPa<fTAa> GHiL();

    public void tick();

    public void ssNb(fTAa var1);

    public wfPa<OsCE> FEfL();

    public void ssNb(OsCE var1);

    public wfPa<CommandSender> Vvwe();
}

