/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.event.Listener
 */
import org.bukkit.event.Listener;

public abstract class jqQR
implements ndLE,
Listener {
}

