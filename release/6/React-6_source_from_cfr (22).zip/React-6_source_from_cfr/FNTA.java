/*
 * Decompiled with CFR 0_123.
 */
public abstract class FNTA<FROM, TO>
implements hYdh<FROM, TO> {
    @Override
    public TO YoSa(FROM FROM) {
        return this.jhSt(FROM);
    }

    @Override
    public abstract TO jhSt(FROM var1);
}

