/*
 * Decompiled with CFR 0_123.
 */
import java.util.Collection;
import java.util.HashSet;

public class QyFw<T>
extends HashSet<T> {
    private static final long serialVersionUID = 1;

    public QyFw() {
    }

    public QyFw(Collection<? extends T> collection) {
        super(collection);
    }

    public QyFw(int n, float f) {
        super(n, f);
    }

    public QyFw(int n) {
        super(n);
    }
}

