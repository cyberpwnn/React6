/*
 * Decompiled with CFR 0_123.
 */
public class ydMI
extends Exception {
    private static final long serialVersionUID = 1;

    public ydMI(String string) {
        super(string);
    }
}

