/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

class PuYf$2
extends vIXT {
    final /* synthetic */ PuYf wevJ;

    PuYf$2(PuYf puYf) {
        this.wevJ = puYf;
    }

    @Override
    public void run() {
        PuYf$2.ui(PuYf$2.ui((PuYf)cv.b(this, -789704770)), PuYf$2.ui(PuYf$2.ui(new StringBuilder(rgig$AWxc.r("\uf2e5\u0c10\u2e65\u1ee8\ua31e\u7ef6\u0082\u5e0a\ubdad\u9593\ude62")), PuYf$2.ui((PuYf)cv.b(this, -789704770)))));
        PuYf$2.ui(PuYf$2.ui((PuYf)cv.b(this, -789704770)), PuYf$2.ui(PuYf$2.ui(PuYf$2.ui(PuYf$2.ui(new StringBuilder(rgig$AWxc.r("\uf2ea\u0c2f\u2e5f\u1ea3\ua33e\u7eb5\u0081\u5e11\ubda3\u95cc\ude62\u09f4\ue2b0\u7739\uac0f\u10ad\ue4b5\u5212")), (APKB)((Object)cv.e(653004664))), PuYf$2.ui(PuYf$2.ui((PuYf)cv.b(this, -789704770)))), rgig$AWxc.r("\uf286\u0c03\u2e60\u1e9d"))));
    }

    private static Object ui(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

