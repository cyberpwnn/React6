/*
 * Decompiled with CFR 0_123.
 */
final class vslr$ssNb {
    private vslr$ssNb() {
    }

    protected final Object clone() {
        return this;
    }

    public boolean equals(Object object) {
        if (object == null || object == this) {
            return true;
        }
        return false;
    }

    public String toString() {
        return KUXS$dwji.S("\ue0a2\u4ed2\ufecc\u3e91");
    }

    /* synthetic */ vslr$ssNb(vslr$1 vslr$1) {
        this();
    }
}

