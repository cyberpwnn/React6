/*
 * Decompiled with CFR 0_123.
 */
public class esCa
extends vbnM<String> {
    protected esCa(String string) {
        super((GHiL)((Object)cv.e(28504611)), string);
    }
}

