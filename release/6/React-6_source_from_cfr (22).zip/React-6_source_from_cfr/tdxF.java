/*
 * Decompiled with CFR 0_123.
 */
public class tdxF<T>
implements Runnable {
    private T lLpl;

    public void BkpW(T t) {
        cv.e(this, -860162009, t);
        this.run();
    }

    @Override
    public void run() {
    }

    public T get() {
        return (T)cv.b(this, -860162009);
    }
}

