/*
 * Decompiled with CFR 0_123.
 */
final class JbuU$jhSt
extends RuntimeException {
    private static final long serialVersionUID = 3203085387160737484L;

    public JbuU$jhSt(String string) {
        super(string);
    }
}

