/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class Smci
implements ftyu {
    @Override
    public void DYFV(String string) {
        Smci.Mn(Smci.Mn(), string);
    }

    @Override
    public void IWSm(String string) {
        Smci.Mn(Smci.Mn(), string);
    }

    @Override
    public void OXeK(String string) {
        Smci.Mn(Smci.Mn(), string);
    }

    @Override
    public void YoSa(String string) {
        Smci.Mn(Smci.Mn(), string);
    }

    private static Object Mn(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

