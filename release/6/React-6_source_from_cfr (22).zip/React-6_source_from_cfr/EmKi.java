/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.command.CommandSender
 */
import org.bukkit.command.CommandSender;

public interface EmKi {
    public GHaL CoXE();

    public Class<?> getType();

    public boolean OXeK(Object var1);

    public QyFw<Object> ftyu();

    public QyFw<Object> mXMK();

    public int jhSt(CommandSender var1, String var2) throws kYwm;

    public String getName();
}

