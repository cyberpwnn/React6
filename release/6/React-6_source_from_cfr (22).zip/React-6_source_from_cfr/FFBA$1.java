/*
 * Decompiled with CFR 0_123.
 */
class FFBA$1
implements Runnable {
    final /* synthetic */ FFBA Vfch;

    FFBA$1(FFBA fFBA) {
        this.Vfch = fFBA;
    }

    @Override
    public void run() {
    }
}

