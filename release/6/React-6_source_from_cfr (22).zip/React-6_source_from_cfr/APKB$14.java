/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  net.md_5.bungee.api.ChatColor
 */
import net.md_5.bungee.api.ChatColor;

class APKB$14
extends APKB {
    APKB$14(String string2, int n2, char c, int n3, boolean bl) {
    }

    @Override
    public ChatColor asBungee() {
        return (ChatColor)cv.e(-1434651623);
    }
}

