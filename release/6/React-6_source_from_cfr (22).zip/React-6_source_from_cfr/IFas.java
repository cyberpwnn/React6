/*
 * Decompiled with CFR 0_123.
 */
interface IFas {
}

