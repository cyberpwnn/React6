/*
 * Decompiled with CFR 0_123.
 */
public interface ftyu {
    public void DYFV(String var1);

    public void IWSm(String var1);

    public void OXeK(String var1);

    public void YoSa(String var1);
}

