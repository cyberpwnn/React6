/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 */
import org.bukkit.entity.EntityType;

public class KUKx {
    private QyFw<EntityType> MBKs = new QyFw();

    public QyFw<EntityType> rMgK() {
        return (QyFw)cv.b(this, -89190525);
    }
}

