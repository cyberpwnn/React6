/*
 * Decompiled with CFR 0_123.
 */
public class ccgJ {
    private long cmKY;

    public ccgJ(long l) {
        this.cmKY = l;
    }

    public long get() {
        return (Long)cv.b(this, 1717041187);
    }

    public void set(long l) {
        cv.e(this, 1717041187, l);
    }

    public void add(long l) {
        ccgJ ccgJ2 = this;
        cv.e(ccgJ2, 1717041187, (Long)cv.b(ccgJ2, 1717041187) + l);
    }

    public void WGJn(long l) {
        ccgJ ccgJ2 = this;
        cv.e(ccgJ2, 1717041187, (Long)cv.b(ccgJ2, 1717041187) - l);
    }
}

