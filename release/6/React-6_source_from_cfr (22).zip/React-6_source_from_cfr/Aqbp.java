/*
 * Decompiled with CFR 0_123.
 */
public abstract class Aqbp
implements HBqU {
    protected String command;
    protected String[] aliases;
    protected String[] VoJs;
    protected String ktXM;
    protected String description;
    protected OikN IFas;

    @Override
    public String getCommand() {
        return (String)cv.b(this, 1780354621);
    }

    @Override
    public String[] PuYf() {
        return (String[])cv.b(this, -146862532);
    }

    @Override
    public String[] TNbD() {
        return (String[])cv.b(this, 1588334143);
    }

    @Override
    public String getUsage() {
        return (String)cv.b(this, 1842679358);
    }

    @Override
    public String getDescription() {
        return (String)cv.b(this, 418975289);
    }

    @Override
    public OikN LGKN() {
        return (OikN)((Object)cv.b(this, -1172500488));
    }
}

