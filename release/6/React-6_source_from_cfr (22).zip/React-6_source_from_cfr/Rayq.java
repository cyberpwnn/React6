/*
 * Decompiled with CFR 0_123.
 */
public class Rayq
extends vbnM<Long> {
    protected Rayq(Long l) {
        super((GHiL)((Object)cv.e(-694685152)), l);
    }
}

