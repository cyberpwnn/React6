/*
 * Decompiled with CFR 0_123.
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;

public class nBHO {
    private static boolean jqgp;
    protected static int version;
    public static Class<?> BddX;
    public static Class<?> JAgx;
    public static Class<?> lgMk;
    public static Class<?> lwoC;
    public static Class<?> DHgv;
    protected static Class<?> tDPa;
    public static Class<?> tCpA;
    public static Class<?> MBah;
    public static Class<?> pPvA;
    public static Class<?> Bdeb;

    static {
        cv.V(-1910050301, false);
        cv.V(-2021395966, 170);
        if (!((Boolean)cv.e(-1910050301)).booleanValue()) {
            if (nBHO.ti(nBHO.ti(), rgig$AWxc.r("\uce79\u56ba\ub58f")) != false) {
                cv.V(-2021395966, 170);
            }
            if (nBHO.ti(nBHO.ti(), rgig$AWxc.r("\uce79\u56ba\ub580")) != false) {
                cv.V(-2021395966, 180);
            }
            if (nBHO.ti(nBHO.ti(), rgig$AWxc.r("\uce79\u56ba\ub580\u547f\ucda4\u55bf")) != false) {
                cv.V(-2021395966, 181);
            }
            if (nBHO.ti(nBHO.ti(), rgig$AWxc.r("\uce79\u56ba\ub580\u547f\ucda4\u55bc")) != false) {
                cv.V(-2021395966, 182);
            }
            if (nBHO.ti(nBHO.ti(), rgig$AWxc.r("\uce79\u56ba\ub580\u547f\ucda4\u55bd")) != false) {
                cv.V(-2021395966, 183);
            }
            if ((Integer)cv.e(-2021395966) >= 180) {
                cv.V(-1108217329, nBHO.ti(rgig$AWxc.r("\uce18\u5684\ub5db\u544b\ucd93\u55fa\ua15e\ud96a\ue716\u08b8\uefbb\ucadc\ub7b8\ue1f6\ud870\u8ee8\uc460\uefb2\ue7c0\ucc7e\ua361\u9c73\ub573\u5d90\u383e\u1c4e\u2df1\ub801\uc6b6\u4820\ufe60\u2edf\u3c31\u6989\u3c73")));
            }
            cv.V(1090581001, nBHO.ti(rgig$AWxc.r("\uce01\u56a6\ub5d0\u5441\ucd82\u55cc\ua16f\ud975\ue712\u0882\uef9b\ucac4\ub7bc\ue1c9\ud872\u8eec\uc477\uefa3")));
            if ((Integer)cv.e(-2021395966) < 181) {
                cv.V(-1691815416, nBHO.ti(rgig$AWxc.r("\uce0b\u568d\ub5d9\u5454\ucda5\u55eb\ua17c\ud96f\ue716\u08ad\uef9d\ucad3\ub7a9\ue1d4")));
            } else {
                cv.V(-1691815416, nBHO.ti(rgig$AWxc.r("\uce01\u56a6\ub5d0\u5441\ucd82\u55cc\ua16f\ud975\ue712\u0882\uef9b\ucac4\ub7bc\ue1c9\ud872\u8eec\uc477\uefa3\ue796\ucc71\ua360\u9c61\ub573\u5d8b\u383e\u1c5d\u2dfc\ub805\uc6a8\u480f\ufe75\u2ed5\u3c37")));
            }
            cv.V(-1471221237, nBHO.ti(rgig$AWxc.r("\uce18\u5684\ub5db\u544b\ucd93\u55fa\ua15e\ud96a\ue716\u08b8\uefbb\ucadc\ub7b8\ue1f6\ud870\u8ee8\uc460\uefb2\ue7c0\ucc7b\ua366\u9c66\ub568")));
            if ((Integer)cv.e(-2021395966) >= 180) {
                cv.V(589230602, nBHO.ti(rgig$AWxc.r("\uce18\u5684\ub5db\u544b\ucd93\u55fa\ua15e\ud96a\ue716\u08b8\uefbb\ucadc\ub7b8\ue1f6\ud870\u8ee8\uc460\uefb2\ue7c0\ucc7b\ua366\u9c66\ub568\u5dfc\u380b\u1c43\u2df4\ub81d\uc6a1\u4814\ufe46\u2ede\u3c23\u6983\u3c45\uec15\u4599\u1e68")));
            }
            if ((Integer)cv.e(-2021395966) <= 181) {
                cv.V(-188681227, nBHO.ti(rgig$AWxc.r("\uce0d\u568b\ub5cd\u544d\ucda6\u55e2\ua16f\ud97f\ue712\u08b3\uefbd\ucac7\ub7aa\ue1c9\ud85d\u8eea\uc46d\uefbe\ue7dd\ucc5c")));
            } else {
                cv.V(-188681227, nBHO.ti(rgig$AWxc.r("\uce18\u5684\ub5db\u544b\ucd93\u55fa\ua15e\ud96a\ue716\u08b8\uefbb\ucadc\ub7b8\ue1f6\ud870\u8ee8\uc460\uefb2\ue7c0\ucc7b\ua366\u9c66\ub568\u5dfc\u381e\u1c41\u2de0\ub809\uc694\u480a\ufe6e\u2ec9\u3c20\u699e\u3c48\uec1a\u458b\u1e66\u4e86\ucab1\u061a\u16c0\u483d\u49f7")));
            }
            try {
                if ((Integer)cv.e(-2021395966) < 180) {
                    cv.V(290976756, nBHO.ti(rgig$AWxc.r("\uce26\u5680\ub5cc\u540e\ucd9b\u55e7\ua160\ud963\ue714\u08b3\uef95\ucacf\ub7b8\ue188\ud869\u8efd\uc470\uefbb\ue79c\ucc51\ua367\u9c6d\ub529\u5db5\u3834\u1c45\u2df4\ub80a\uc6a3\u4848\ufe6e\u2ec5\u3c31\u6984\u3c6d\uec1d\u458f\u1e27\u4e80\ucab3\u0603\u16cc\u4802\u49eb\u6fb3\ub2b6\udb89\uc770\uce41")));
                } else {
                    cv.V(290976756, nBHO.ti(rgig$AWxc.r("\uce2b\u568a\ub5d5\u540e\ucd9b\u55e1\ua164\ud967\ue719\u08a6\uefda\ucac8\ub7b9\ue1d2\ud874\u8ee5\uc470\uefb5\ue79c\ucc75\ua369\u9c6d\ub562\u5d88\u3829\u1c40\u2df3\ub80d\uc6a8\u4803")));
                }
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
            if ((Integer)cv.e(-2021395966) < 182) {
                cv.V(-1927744521, nBHO.ti(rgig$AWxc.r("\uce0d\u568b\ub5cd\u544d\ucdb1\u55ef\ua163\ud963\ue71a\u08ae\uef90\ucacc")));
            } else {
                cv.V(-1927744521, nBHO.ti(rgig$AWxc.r("\uce1f\u568a\ub5ca\u544c\ucd92\u55dd\ua16b\ud972\ue703\u08a8\uef9a\ucace\ub7bf\ue182\ud859\u8ee7\uc46c\uefba\ue7f5\ucc53\ua365\u9c65\ub56a\u5db7\u383f\u1c4a")));
            }
            cv.V(-1045957642, nBHO.ti(rgig$AWxc.r("\uce1c\u568c\ub5d4\u5445\ucdb3\u55e0\ua17a\ud96f\ue703\u08b8\uefa7\ucac2\ub7b9\ue1ca\ud870")));
            try {
                if ((Integer)cv.e(-2021395966) < 180) {
                    cv.V(-1253182479, nBHO.ti(rgig$AWxc.r("\uce26\u5680\ub5cc\u540e\ucd9b\u55e7\ua160\ud963\ue714\u08b3\uef95\ucacf\ub7b8\ue188\ud869\u8efd\uc470\uefbb\ue79c\ucc51\ua367\u9c6d\ub529\u5dbf\u3834\u1c40\u2df2\ub808\uc6a1\u4848\ufe6c\u2edf\u3c28\u6981\u3c6e\uec1a\u45c3\u1e6a\u4ea6\ucab1\u0606\u16cc\u487c\u49d5\u6fb3\ub2b1\udb84\uc775\uce4a\uad05\udb84\u6d36\u2b8b\u5471\uee46")));
                } else {
                    cv.V(-1253182479, nBHO.ti(rgig$AWxc.r("\uce2b\u568a\ub5d5\u540e\ucd91\u55e1\ua161\ud961\ue71b\u08a4\uefda\ucaca\ub7a3\ue1cb\ud871\u8ee6\uc477\ueff9\ue7d1\ucc53\ua36b\u9c68\ub562\u5df6\u3817\u1c40\u2df4\ub800\uc6ad\u4808\ufe68\u2ef3\u3c24\u698f\u3c69\uec11")));
                }
            }
            catch (ClassNotFoundException classNotFoundException) {
                // empty catch block
            }
            cv.V(-1910050301, true);
        }
    }

    private static Object ti(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

