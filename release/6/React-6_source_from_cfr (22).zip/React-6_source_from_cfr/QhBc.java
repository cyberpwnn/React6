/*
 * Decompiled with CFR 0_123.
 */
public class QhBc {
    public static long fLAr;
    public static long EeUm;

    static {
        cv.V(871764466, 0);
        cv.V(1212676456, 0);
    }
}

