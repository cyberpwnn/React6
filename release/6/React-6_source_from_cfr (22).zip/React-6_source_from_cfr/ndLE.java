/*
 * Decompiled with CFR 0_123.
 */
public interface ndLE {
    public void start();

    public void stop();

    public void tick();
}

