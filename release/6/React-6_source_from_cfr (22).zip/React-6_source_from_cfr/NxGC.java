/*
 * Decompiled with CFR 0_123.
 */
public interface NxGC<T> {
    public String NUdB();

    public long OOtu();

    public vslr aLYV();

    public T Smci();

    public void ssNb(vslr var1);
}

