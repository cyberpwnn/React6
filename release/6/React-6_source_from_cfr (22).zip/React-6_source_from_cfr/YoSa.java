/*
 * Decompiled with CFR 0_123.
 */
@roui
@vJEF
public class YoSa {
    @IXBO
    public static YoSa gFBb;
    public static String Yfkw;
    @fKRe
    public uOFv sPsW;
    @fKRe
    public YDey tLFo;
    @fKRe
    public GIDW eHME;
    @fKRe
    public wDLU mXSo;
    @fKRe
    public yuFb rxda;
    @fKRe
    public tCRu gotS;
    @fKRe
    public EvBS QMsU;
    @fKRe
    public WFpH GjjA;
    @fKRe
    public JRMO vbnM;
    @fKRe
    public tKcS JbqW;
    @fKRe
    public cAai YUkF;
    @fKRe
    public BuHU fvCa;
    @fKRe
    public FFBA Rayq;
    @fKRe
    public TOJM esCa;
    @fKRe
    public XthG VCsR;
    @fKRe
    public YUgh GHiL;
    @fKRe
    public kQhu FEfL;
    @fKRe
    public tLCm Vvwe;

    static {
        cv.V(-1768819866, rgig$AWxc.r("\u68da\uac77\uddbe\uf725\u56ed\u7cb9\ueb85\ua6fe\u5031\u014b"));
    }

    @wLbX
    public void enable() {
    }

    @Whxy
    public void disable() {
    }
}

