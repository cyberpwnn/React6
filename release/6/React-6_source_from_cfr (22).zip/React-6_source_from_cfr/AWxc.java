/*
 * Decompiled with CFR 0_123.
 */
public class AWxc {
    private double VpAh = 0.0;
    private double xXnu = 0.0;
    private double dEdk;

    public double maJO() {
        return (Double)cv.b(this, -1251937185);
    }

    public void LWjo(double d) {
        cv.e(this, -1251937185, d);
    }

    public double QNWg() {
        return (Double)cv.b(this, 884339806);
    }

    public void PuYf(double d) {
        cv.e(this, 884339806, d);
    }

    public double vJAb() {
        return (Double)cv.b(this, -146082727);
    }

    public void TNbD(double d) {
        cv.e(this, -146082727, d);
    }
}

