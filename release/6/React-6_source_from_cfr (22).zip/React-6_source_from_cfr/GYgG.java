/*
 * Decompiled with CFR 0_123.
 */
public class GYgG {
    private String string;

    public GYgG(String string) {
        this.string = string;
    }

    public String get() {
        return (String)cv.b(this, -2059012062);
    }

    public void set(String string) {
        cv.e(this, -2059012062, string);
    }
}

