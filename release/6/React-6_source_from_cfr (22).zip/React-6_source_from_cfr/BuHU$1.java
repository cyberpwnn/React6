/*
 * Decompiled with CFR 0_123.
 */
class BuHU$1
extends gyID {
    final /* synthetic */ BuHU TiNq;

    BuHU$1(BuHU buHU, String string) {
        this.TiNq = buHU;
        super(string);
    }

    @Override
    public void run() {
        new BuHU$1$1(this);
    }
}

