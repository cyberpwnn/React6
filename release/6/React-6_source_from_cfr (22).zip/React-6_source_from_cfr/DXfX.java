/*
 * Decompiled with CFR 0_123.
 */
public interface DXfX {
    public String getID();

    public String getName();

    public String getDescription();

    public void setID(String var1);

    public void setName(String var1);

    public void setDescription(String var1);

    public APKB KwOT();

    public APKB KUKx();

    public void ssNb(APKB var1, APKB var2);

    public int getInterval();

    public void DYFV(int var1);

    public void avmQ();

    public String get();

    public void CMSR();

    public void setValue(double var1);

    public double getValue();
}

