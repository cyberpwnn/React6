/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.EntityType
 */
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import org.bukkit.entity.EntityType;

class ssNb$2 {
    static final /* synthetic */ int[] gEYM;

    static {
        cv.V(902828506, new int[((EntityType[])ssNb$2.Nj()).length]);
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-209907400))] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1322652101))] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)917377476))] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-919858745))] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-792522298))] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1760498113))] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)873927104))] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1043337667))] = 8;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)297406914))] = 9;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-1770909235))] = 10;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1552749004))] = 11;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-553840177))] = 12;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1317409230))] = 13;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)2141262281))] = 14;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)374673864))] = 15;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)952570315))] = 16;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-1887759926))] = 17;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)2096632245))] = 18;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1943998900))] = 19;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-663154249))] = 20;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)267653558))] = 21;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-912846415))] = 22;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)282005936))] = 23;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)1650135475))] = 24;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)579735986))] = 25;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-1581706819))] = 26;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-1519447620))] = 27;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-1134620225))] = 28;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            // empty catch block
        }
        try {
            ((int[])cv.e((int)902828506))[ssNb$2.Nj((EntityType)cv.e((int)-707391042))] = 29;
            return;
        }
        catch (NoSuchFieldError noSuchFieldError) {
            return;
        }
    }

    private static Object Nj(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

