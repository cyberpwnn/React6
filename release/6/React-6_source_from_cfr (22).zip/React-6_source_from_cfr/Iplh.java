/*
 * Decompiled with CFR 0_123.
 */
import java.io.Serializable;

public class Iplh<A, B, C>
implements Serializable {
    private static final long serialVersionUID = 1912465707826963942L;
    private A HemE;
    private B cAun;
    private C ssgo;

    public Iplh(A a, B b, C c) {
        this.HemE = a;
        this.cAun = b;
        this.ssgo = c;
    }

    public A GkIA() {
        return (A)cv.b(this, 1742600210);
    }

    public void lCdp(A a) {
        cv.e(this, 1742600210, a);
    }

    public B YDfo() {
        return (B)cv.b(this, 1557788701);
    }

    public void nJLQ(B b) {
        cv.e(this, 1557788701, b);
    }

    public C JlDV() {
        return (C)cv.b(this, -984418276);
    }

    public void TyVf(C c) {
        cv.e(this, -984418276, c);
    }
}

