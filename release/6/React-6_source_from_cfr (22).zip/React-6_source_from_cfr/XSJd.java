/*
 * Decompiled with CFR 0_123.
 */
public interface XSJd {
    public void FFBA();

    public String BuHU();
}

