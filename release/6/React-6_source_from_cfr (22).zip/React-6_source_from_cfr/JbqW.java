/*
 * Decompiled with CFR 0_123.
 */
public class JbqW
extends vbnM<Boolean> {
    protected JbqW(Boolean bl) {
        super((GHiL)((Object)cv.e(-1670712793)), bl);
    }
}

