/*
 * Decompiled with CFR 0_123.
 */
public class cRaV
extends KTmF {
    private static final long serialVersionUID = -6778105688310325503L;

    public cRaV(String string) {
        super(string);
    }
}

