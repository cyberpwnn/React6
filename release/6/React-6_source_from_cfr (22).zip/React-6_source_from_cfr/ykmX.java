/*
 * Decompiled with CFR 0_123.
 */
public class ykmX
extends KTmF {
    private static final long serialVersionUID = -6342933414119063980L;
}

