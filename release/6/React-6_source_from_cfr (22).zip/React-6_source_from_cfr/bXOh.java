/*
 * Decompiled with CFR 0_123.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 */
import java.io.File;
import java.lang.invoke.ConstantCallSite;
import java.lang.invoke.MethodHandle;
import java.lang.invoke.MethodHandles;
import java.lang.invoke.MethodType;
import java.lang.reflect.Method;
import java.util.UUID;
import org.bukkit.entity.Player;

public class bXOh
implements BAjC {
    @aLcY
    public static ktOu<Integer, String> qBdN;
    @FyLC(value=-175)
    public boolean monitoring = false;
    @FyLC(value=164)
    public boolean mrMJ = false;
    @FyLC(value=234)
    public boolean bPKY = false;
    @FyLC(value=-885)
    public int CpFK = -1;
    @FyLC(value=343)
    public int imom = 0;
    @FyLC(value=765)
    public boolean DrhM = false;
    @FyLC(value=-112)
    public int PKWY = 0;
    @FyLC(value=-694)
    public int GtBM = 0;
    @FyLC(value=492)
    public int nuPQ = 0;
    @FyLC(value=117)
    public boolean OGsT = false;
    @FyLC(value=-592)
    public int wevr = 0;
    @FyLC(value=841)
    public double DQFV = 0.0;
    @FyLC(value=-413)
    public boolean WFya = false;
    private Player JIdp;

    public bXOh(Player player) {
        this.JIdp = player;
        this.load();
    }

    public void save() {
        try {
            bXOh.XY(new Vvwe(), this, new File((File)bXOh.XY((String)cv.e(-1850142725)), (String)bXOh.XY(bXOh.XY(bXOh.XY(new StringBuilder(), bXOh.XY(((Player)cv.b(this, -625209371)).getUniqueId())), (String)cv.e(-1198452761)))));
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            bXOh.XY(exception);
            return;
        }
    }

    public void load() {
        try {
            bXOh.XY(new FEfL(), this, new File((File)bXOh.XY((String)cv.e(-1850142725)), (String)bXOh.XY(bXOh.XY(bXOh.XY(new StringBuilder(), bXOh.XY(((Player)cv.b(this, -625209371)).getUniqueId())), (String)cv.e(-1198452761)))));
            return;
        }
        catch (Exception exception) {
            Exception exception2 = exception;
            bXOh.XY(exception);
            return;
        }
    }

    public boolean gEXv() {
        return (Boolean)cv.b(this, 1960316899);
    }

    public boolean tvRU() {
        return (Boolean)cv.b(this, -1853026334);
    }

    public Player dntE() {
        return (Player)cv.b(this, -625209371);
    }

    public void DYFV(boolean bl) {
        cv.e(this, 1960316899, bl);
    }

    public void IWSm(boolean bl) {
        cv.e(this, -1853026334, bl);
    }

    public int RbOr() {
        return (Integer)cv.b(this, 183504877);
    }

    public void IWSm(int n) {
        cv.e(this, 183504877, n);
    }

    public int KCiG() {
        return (Integer)cv.b(this, 1164709868);
    }

    public void OXeK(int n) {
        cv.e(this, 1164709868, n);
    }

    public boolean tdpC() {
        return (Boolean)cv.b(this, -2006577169);
    }

    public void OXeK(boolean bl) {
        cv.e(this, -2006577169, bl);
    }

    public boolean PBWX() {
        return (Boolean)cv.b(this, -2006577169);
    }

    public void YoSa(boolean bl) {
        cv.e(this, -2006577169, bl);
    }

    public int hbNa() {
        return (Integer)cv.b(this, 1597378542);
    }

    public void YoSa(int n) {
        cv.e(this, 1597378542, n);
    }

    public int gEYM() {
        return (Integer)cv.b(this, -37416983);
    }

    public void jhSt(int n) {
        cv.e(this, -37416983, n);
    }

    public void ssNb(Player player) {
        cv.e(this, -625209371, (Object)player);
    }

    public double Aqbp() {
        return (Double)cv.b(this, -1538125848);
    }

    public void ssNb(double d) {
        cv.e(this, -1538125848, d);
    }

    public boolean KTmF() {
        return (Boolean)cv.b(this, -901246997);
    }

    public void jhSt(boolean bl) {
        cv.e(this, -901246997, bl);
    }

    public int bXOh() {
        return (Integer)cv.b(this, -1074524182);
    }

    public void BkpW(int n) {
        cv.e(this, -1074524182, n);
    }

    public boolean LGOT() {
        return (Boolean)cv.b(this, -1661726763);
    }

    public void BkpW(boolean bl) {
        cv.e(this, -1661726763, bl);
    }

    public int Lhpt() {
        return (Integer)cv.b(this, -1306652716);
    }

    public void lCdp(int n) {
        cv.e(this, -1306652716, n);
    }

    public boolean uxwg() {
        return (Boolean)cv.b(this, 761401303);
    }

    public void lCdp(boolean bl) {
        cv.e(this, 761401303, bl);
    }

    static {
        ktOu ktOu2 = new ktOu();
        cv.V(160436182, ktOu2);
        bXOh.XY(ktOu2, bXOh.XY(-175), (String)cv.e(23269329));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(234), (String)cv.e(-511111216));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(-885), (String)cv.e(-1177022509));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(343), (String)cv.e(-450228270));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(765), (String)cv.e(-1252519971));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(-112), (String)cv.e(1452085212));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(-694), (String)cv.e(-2106585121));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(492), (String)cv.e(-572059682));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(117), (String)cv.e(399445977));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(-592), (String)cv.e(-2143154664));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(841), (String)cv.e(-143127013));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(-413), (String)cv.e(-1664545254));
        bXOh.XY((ktOu)cv.e(160436182), bXOh.XY(164), (String)cv.e(-543093243));
    }

    private static Object XY(Object object, Object object2, Object object3) {
        try {
            return new ConstantCallSite(((MethodHandles.Lookup)object).unreflect(cv.L(Integer.valueOf((String)object2, 32))).asType((MethodType)object3));
        }
        catch (ClassNotFoundException | IllegalAccessException reflectiveOperationException) {
            throw new BootstrapMethodError(reflectiveOperationException);
        }
    }
}

