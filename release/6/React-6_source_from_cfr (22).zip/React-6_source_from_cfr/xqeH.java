/*
 * Decompiled with CFR 0_123.
 */
public interface xqeH<V> {
    public V get();
}

