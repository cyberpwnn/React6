/*
 * Decompiled with CFR 0_123.
 */
public interface ogMI {
    public void DYFV(YDfo var1);
}

